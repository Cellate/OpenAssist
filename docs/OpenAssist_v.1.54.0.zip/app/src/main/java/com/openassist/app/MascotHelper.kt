package com.openassist.app

data class MascotData(
    val id: String,
    val name: String,         // Short mascot name: Ozzy, Pip, Echo, Nova, etc.
    val fullName: String,     // Descriptive name for picker
    val drawableRes: Int
)

object MascotHelper {
    val ALL_MASCOTS = listOf(
        MascotData("owl-orbital", "Ozzy", "Ozzy Orbital", R.drawable.ic_mascot_owl_orbital),
        MascotData("owl", "Ozzy", "Ozzy Classic", R.drawable.ic_mascot_owl),
        MascotData("owl-cosmic", "Ozzy", "Ozzy Cosmic", R.drawable.ic_mascot_owl_cosmic),
        MascotData("owl-talons", "Ozzy", "Ozzy Perch", R.drawable.ic_mascot_owl_talons),
        MascotData("owl-radar", "Ozzy", "Ozzy Radar", R.drawable.ic_mascot_owl_radar),
        MascotData("owl-wings", "Ozzy", "Ozzy Shield", R.drawable.ic_mascot_owl_wings),
        MascotData("owl-monocle", "Ozzy", "Ozzy Scholar", R.drawable.ic_mascot_owl_monocle),
        MascotData("owl-minimal", "Ozzy", "Ozzy Minimal", R.drawable.ic_mascot_owl_minimal),
        MascotData("fox", "Pip", "Pip Nexus", R.drawable.ic_mascot_fox),
        MascotData("fox-orbital", "Pip", "Pip Orbit", R.drawable.ic_mascot_fox_orbital),
        MascotData("fox-cyber", "Pip", "Pip Cyber", R.drawable.ic_mascot_fox_cyber),
        MascotData("fox-paws", "Pip", "Pip Paws", R.drawable.ic_mascot_fox_paws),
        MascotData("fox-firefly", "Pip", "Pip Radar", R.drawable.ic_mascot_fox_firefly),
        MascotData("fox-halo", "Pip", "Pip Halo", R.drawable.ic_mascot_fox_halo),
        MascotData("fox-headset", "Pip", "Pip Voice", R.drawable.ic_mascot_fox_headset),
        MascotData("fox-monocle", "Pip", "Pip Loupe", R.drawable.ic_mascot_fox_monocle),
        MascotData("fox-minimal", "Pip", "Pip Minimal", R.drawable.ic_mascot_fox_minimal),
        MascotData("bat", "Echo", "Echo Bat", R.drawable.ic_mascot_bat),
        MascotData("otter", "Nova", "Nova Otter", R.drawable.ic_mascot_otter),
        MascotData("chameleon", "Pico", "Pico Chameleon", R.drawable.ic_mascot_chameleon),
        MascotData("tanuki", "Taro", "Taro Tanuki", R.drawable.ic_mascot_tanuki),
        MascotData("sprite", "Ollie", "Ollie Sprite", R.drawable.ic_mascot_sprite),
        MascotData("kitten", "Byte", "Byte Kitten", R.drawable.ic_mascot_kitten),
        MascotData("firefly", "Lumi", "Lumi Firefly", R.drawable.ic_mascot_firefly),
        MascotData("axolotl", "Kiko", "Kiko Axolotl", R.drawable.ic_mascot_axolotl),
        MascotData("orbital", "Iris", "Iris Loop", R.drawable.ic_mascot_orbital),
        MascotData("whale", "Moby", "Moby-Ray", R.drawable.ic_mascot_whale)
    )

    fun getMascot(style: String?): MascotData {
        val s = (style ?: "owl-orbital").lowercase().trim()
        val exact = ALL_MASCOTS.firstOrNull { it.id == s }
        if (exact != null) return exact

        return when {
            s in listOf("default", "ozzy", "") -> ALL_MASCOTS[0]
            s in listOf("pip", "fennec") -> getMascot("fox")
            s in listOf("cat", "byte", "luna") -> getMascot("kitten")
            s in listOf("echo") -> getMascot("bat")
            s in listOf("nova") -> getMascot("otter")
            s in listOf("pico") -> getMascot("chameleon")
            s in listOf("taro", "momo") -> getMascot("tanuki")
            s in listOf("ollie", "bolt", "spark") -> getMascot("sprite")
            s in listOf("lumi") -> getMascot("firefly")
            s in listOf("kiko") -> getMascot("axolotl")
            s in listOf("iris") -> getMascot("orbital")
            s in listOf("moby") -> getMascot("whale")
            s.startsWith("owl") -> ALL_MASCOTS[0]
            s.startsWith("fox") -> getMascot("fox")
            else -> ALL_MASCOTS[0]
        }
    }
}
