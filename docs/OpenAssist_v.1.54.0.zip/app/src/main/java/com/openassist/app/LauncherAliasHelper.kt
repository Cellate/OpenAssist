package com.openassist.app

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

object LauncherAliasHelper {
    private val ALIAS_MAP = mapOf(
        // Owl variants
        "owl-orbital" to "LauncherOwl",
        "owl" to "LauncherOwl",
        "owl-cosmic" to "LauncherOwl",
        "owl-talons" to "LauncherOwl",
        "owl-radar" to "LauncherOwl",
        "owl-wings" to "LauncherOwl",
        "owl-monocle" to "LauncherOwl",
        "owl-minimal" to "LauncherOwl",
        "ozzy" to "LauncherOwl",

        // Fox variants
        "fox" to "LauncherFox",
        "fox-orbital" to "LauncherFox",
        "fox-cyber" to "LauncherFox",
        "fox-paws" to "LauncherFox",
        "fox-firefly" to "LauncherFox",
        "fox-halo" to "LauncherFox",
        "fox-headset" to "LauncherFox",
        "fox-monocle" to "LauncherFox",
        "fox-minimal" to "LauncherFox",
        "pip" to "LauncherFox",
        "fennec" to "LauncherFox",

        // Other mascots
        "bat" to "LauncherBat",
        "echo" to "LauncherBat",
        "otter" to "LauncherOtter",
        "nova" to "LauncherOtter",
        "chameleon" to "LauncherChameleon",
        "pico" to "LauncherChameleon",
        "tanuki" to "LauncherTanuki",
        "taro" to "LauncherTanuki",
        "momo" to "LauncherTanuki",
        "cat" to "LauncherKitten",
        "kitten" to "LauncherKitten",
        "byte" to "LauncherKitten",
        "luna" to "LauncherKitten",
        "sprite" to "LauncherSprite",
        "ollie" to "LauncherSprite",
        "bolt" to "LauncherSprite",
        "axolotl" to "LauncherAxolotl",
        "kiko" to "LauncherAxolotl",
        "firefly" to "LauncherFirefly",
        "lumi" to "LauncherFirefly",
        "whale" to "LauncherWhale",
        "moby" to "LauncherWhale",
        "orbital" to "LauncherOrbital",
        "iris" to "LauncherOrbital"
    )

    fun getTargetAlias(mascotStyle: String): String {
        val s = mascotStyle.lowercase().trim()
        return ALIAS_MAP[s] ?: when {
            s.startsWith("owl") -> "LauncherOwl"
            s.startsWith("fox") -> "LauncherFox"
            else -> "LauncherOwl"
        }
    }

    fun updateLauncherIcon(context: Context, mascotStyle: String) {
        try {
            val pm = context.packageManager
            val pkg = context.packageName
            val targetAlias = getTargetAlias(mascotStyle)
            val allAliases = setOf(
                "LauncherOwl",
                "LauncherFox",
                "LauncherBat",
                "LauncherOtter",
                "LauncherChameleon",
                "LauncherTanuki",
                "LauncherKitten",
                "LauncherSprite",
                "LauncherAxolotl",
                "LauncherFirefly",
                "LauncherWhale",
                "LauncherOrbital"
            )

            for (alias in allAliases) {
                val comp = ComponentName(pkg, "$pkg.$alias")
                val isTarget = (alias == targetAlias)
                val newState = if (isTarget) {
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                } else {
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                }
                val curState = pm.getComponentEnabledSetting(comp)
                if (curState != newState) {
                    pm.setComponentEnabledSetting(comp, newState, PackageManager.DONT_KILL_APP)
                }
            }
        } catch (t: Throwable) {
            android.util.Log.e("LauncherAliasHelper", "Could not switch launcher alias", t)
        }
    }
}
