package com.openassist.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

data class LanguageInfo(
    val code: String,
    val name: String,
    val isBuiltIn: Boolean = false
)

class TranslationStore(private val context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("openassist_translations", Context.MODE_PRIVATE)

    companion object {
        const val KEY_APP_LANG = "app_lang"
        const val KEY_SETTINGS_LANG = "settings_lang"
        const val KEY_OVERLAY_LANG = "overlay_lang"
        const val KEY_WEB_LANG = "web_lang"
        const val KEY_MASCOT_LANG = "mascot_lang"
        const val KEY_CUSTOM_LANGS_JSON = "custom_languages_json"
        const val PREFIX_TRANSLATION_MAP = "trans_map_"

        // Canonical English Master Strings used throughout OpenAssist
        val DEFAULT_STRINGS = listOf(
            "Digital assistant" to "Main system voice and circle-to-search service",
            "Choose default assistant" to "Open Android system settings to set OpenAssist as default",
            "Open Web Assistant (Gemini / AI Chat)" to "Launch multi-modal web assistant with camera & clipboard",
            "Open Setup Wizard (First-Run Guide)" to "Interactive walkthrough for mascots, models, and gestures",
            "Local Offline Whisper Models" to "Offline voice transcription models on device",
            "Import Model (.bin)" to "Load a Whisper GGML or GGUF binary file from storage",
            "Whisper Processing Mode" to "Transcription execution pipeline",
            "Post-Processing (Default)" to "Transcribe complete audio segment after speech ends",
            "Real-Time Streaming" to "Transcribe speech chunks continuously as you speak",
            "Per-Language Model Binding" to "Assign specific Whisper models to individual languages",
            "Test Voice Dictation & Transcription" to "Verify microphone recognition and model inference",
            "Tap to Speak / Test" to "Start test audio recording",
            "Stop Recording" to "Stop active speech recording and run model",
            "Active Speech Input Engine" to "Selected voice transcription provider",
            "Google Speech Recognition & Synthesis" to "Official Google engine for ColorOS / Oppo & Android",
            "Local Whisper Mode (Offline GGUF)" to "100% private offline transcription",
            "FUTO Voice Input / Keyboard" to "Fast neural offline voice typing",
            "System Default Speech Recognizer" to "Android platform speech service",
            "AI Web Assistant & Custom AI Services" to "Web conversational LLM configurations",
            "Switch AI" to "Select active AI provider",
            "+ Add Custom AI" to "Connect Ollama, Open WebUI, Grok, or custom endpoint",
            "Mascot Companion Selection" to "Choose your friendly desktop assistant",
            "Mascot Speech Bubbles & Petting" to "Show floating dialogue pills and affectionate responses",
            "Haptic Petting Feedback" to "Vibration pulse when petting mascot",
            "Show Mascot Beside Top Chips" to "Display companion avatar in overlay action bar",
            "Show Mascot in Prompt Search Bar" to "Display companion avatar in web prompt input",
            "Toast Notifications" to "Floating mascot pill notifications",
            "About OpenAssist" to "Open-source digital assistant information",
            "All systems green! Ask me anything!" to "Default cheerful mascot status greeting",
            "Circle or box any element on screen" to "Instruction hint for screen capture selection",
            "Ready to help! Tap to pet me" to "Interactive pet mascot pill invitation",
            "Language & Community Translations" to "Customize languages and import community language packs",
            "Mascot Speech & Dialogue Studio" to "Customize and translate what mascots say across menus"
        )

        // Built-in Hinglish translations
        val HINGLISH_MAP = mapOf(
            "Digital assistant" to "Digital Sahayak",
            "Choose default assistant" to "Default Sahayak chuniye",
            "Open Web Assistant (Gemini / AI Chat)" to "Web Assistant kholein (Gemini / AI Chat)",
            "Open Setup Wizard (First-Run Guide)" to "Setup Wizard kholein",
            "Local Offline Whisper Models" to "Local Offline Whisper Models",
            "Import Model (.bin)" to "Model (.bin) import karein",
            "Whisper Processing Mode" to "Whisper Processing Mode",
            "Post-Processing (Default)" to "Post-Processing (Default)",
            "Real-Time Streaming" to "Real-Time Streaming",
            "Per-Language Model Binding" to "Bhasha ke anusaar Model Binding",
            "Test Voice Dictation & Transcription" to "Voice Dictation test karein",
            "Tap to Speak / Test" to "Bolne ke liye tap karein",
            "Stop Recording" to "Recording rokein",
            "Active Speech Input Engine" to "Active Speech Input Engine",
            "Local Whisper Mode (Offline GGUF)" to "Local Whisper Mode (100% Offline)",
            "Mascot Companion Selection" to "Mascot Companion chuniye",
            "Mascot Speech Bubbles & Petting" to "Mascot Speech Bubbles & Petting",
            "All systems green! Ask me anything!" to "Sab theek hai! Kuch bhi poochhiye! ✨",
            "Circle or box any element on screen" to "Screen par kisi bhi cheez ko circle karein",
            "Ready to help! Tap to pet me" to "Madad ke liye taiyaar! Tap karke pet karein",
            "Language & Community Translations" to "Bhasha aur Community Translations",
            "Mascot Speech & Dialogue Studio" to "Mascot Baatcheet Studio"
        )

        // Built-in Hindi translations
        val HINDI_MAP = mapOf(
            "Digital assistant" to "डिजिटल सहायक",
            "Choose default assistant" to "डिफ़ॉल्ट सहायक चुनें",
            "Open Web Assistant (Gemini / AI Chat)" to "वेब सहायक खोलें",
            "Open Setup Wizard (First-Run Guide)" to "सेटअप विज़ार्ड खोलें",
            "Local Offline Whisper Models" to "ऑफ़लाइन व्हिस्पर मॉडल्स",
            "Import Model (.bin)" to "मॉडल (.bin) जोड़ें",
            "Whisper Processing Mode" to "व्हिस्पर प्रोसेसिंग मोड",
            "Per-Language Model Binding" to "भाषा अनुसार मॉडल बाइंडिंग",
            "Test Voice Dictation & Transcription" to "आवाज़ परीक्षण",
            "Tap to Speak / Test" to "बोलने के लिए टैप करें",
            "Stop Recording" to "रिकॉर्डिंग रोकें",
            "All systems green! Ask me anything!" to "सब कुछ तैयार है! कुछ भी पूछें! ✨",
            "Circle or box any element on screen" to "स्क्रीन पर किसी भी हिस्से पर घेरा बनाएं",
            "Ready to help! Tap to pet me" to "मदद के लिए तैयार! प्यार से सहलाएं",
            "Language & Community Translations" to "भाषा और अनुवाद",
            "Mascot Speech & Dialogue Studio" to "शुभंकर संवाद स्टूडियो"
        )
    }

    var appLanguage: String
        get() = sp.getString(KEY_APP_LANG, "en") ?: "en"
        set(v) { sp.edit().putString(KEY_APP_LANG, v).apply() }

    var settingsLanguage: String
        get() = sp.getString(KEY_SETTINGS_LANG, "") ?: ""
        set(v) { sp.edit().putString(KEY_SETTINGS_LANG, v).apply() }

    var overlayLanguage: String
        get() = sp.getString(KEY_OVERLAY_LANG, "") ?: ""
        set(v) { sp.edit().putString(KEY_OVERLAY_LANG, v).apply() }

    var webUiLanguage: String
        get() = sp.getString(KEY_WEB_LANG, "") ?: ""
        set(v) { sp.edit().putString(KEY_WEB_LANG, v).apply() }

    var mascotLanguage: String
        get() = sp.getString(KEY_MASCOT_LANG, "") ?: ""
        set(v) { sp.edit().putString(KEY_MASCOT_LANG, v).apply() }

    fun getEffectiveLanguage(menuContext: String): String {
        val specific = when (menuContext.lowercase()) {
            "settings" -> settingsLanguage
            "overlay" -> overlayLanguage
            "web", "webui" -> webUiLanguage
            "mascot", "dialogue" -> mascotLanguage
            else -> ""
        }
        return if (specific.isNotBlank()) specific else appLanguage
    }

    fun getAvailableLanguages(): List<LanguageInfo> {
        val list = mutableListOf(
            LanguageInfo("en", "English", isBuiltIn = true),
            LanguageInfo("hinglish", "Hinglish (Hindi in English)", isBuiltIn = true),
            LanguageInfo("hi", "हिन्दी (Hindi)", isBuiltIn = true)
        )
        val raw = sp.getString(KEY_CUSTOM_LANGS_JSON, null) ?: return list
        try {
            val obj = JSONObject(raw)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val code = keys.next()
                val name = obj.optString(code, code)
                if (list.none { it.code == code }) {
                    list.add(LanguageInfo(code, name, isBuiltIn = false))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun addCustomLanguage(code: String, name: String) {
        val cleanCode = code.lowercase().trim().replace(Regex("[^a-z0-9_-]"), "_")
        val cleanName = name.trim().ifBlank { cleanCode }
        val raw = sp.getString(KEY_CUSTOM_LANGS_JSON, "{}") ?: "{}"
        try {
            val obj = JSONObject(raw)
            obj.put(cleanCode, cleanName)
            sp.edit().putString(KEY_CUSTOM_LANGS_JSON, obj.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun removeCustomLanguage(code: String) {
        val raw = sp.getString(KEY_CUSTOM_LANGS_JSON, "{}") ?: "{}"
        try {
            val obj = JSONObject(raw)
            obj.remove(code)
            sp.edit().putString(KEY_CUSTOM_LANGS_JSON, obj.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        // Also remove translations map
        sp.edit().remove(PREFIX_TRANSLATION_MAP + code).apply()
        if (appLanguage == code) appLanguage = "en"
        if (settingsLanguage == code) settingsLanguage = ""
        if (overlayLanguage == code) overlayLanguage = ""
        if (webUiLanguage == code) webUiLanguage = ""
        if (mascotLanguage == code) mascotLanguage = ""
    }

    fun getTranslationMap(langCode: String): Map<String, String> {
        if (langCode == "en") return emptyMap()
        if (langCode == "hinglish") {
            val custom = loadStoredMap(langCode)
            return HINGLISH_MAP + custom
        }
        if (langCode == "hi") {
            val custom = loadStoredMap(langCode)
            return HINDI_MAP + custom
        }
        return loadStoredMap(langCode)
    }

    private fun loadStoredMap(langCode: String): Map<String, String> {
        val raw = sp.getString(PREFIX_TRANSLATION_MAP + langCode, null) ?: return emptyMap()
        return try {
            val obj = JSONObject(raw)
            val map = mutableMapOf<String, String>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = obj.getString(k)
                if (v.isNotBlank()) map[k] = v
            }
            map
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun saveStringOverride(langCode: String, englishKey: String, translatedValue: String) {
        val current = loadStoredMap(langCode).toMutableMap()
        if (translatedValue.isBlank()) {
            current.remove(englishKey)
        } else {
            current[englishKey] = translatedValue.trim()
        }
        saveStoredMap(langCode, current)
    }

    private fun saveStoredMap(langCode: String, map: Map<String, String>) {
        val obj = JSONObject()
        for ((k, v) in map) {
            obj.put(k, v)
        }
        sp.edit().putString(PREFIX_TRANSLATION_MAP + langCode, obj.toString()).apply()
    }

    fun translate(englishText: String, menuContext: String = "general"): String {
        val targetLang = getEffectiveLanguage(menuContext)
        if (targetLang == "en" || targetLang.isBlank()) return englishText
        val map = getTranslationMap(targetLang)
        return map[englishText]?.ifBlank { englishText } ?: englishText
    }

    /**
     * Community Extensible Translation File Format:
     * Line 1: English source string
     * Line 2: Translated string (leave empty to fallback to English)
     * Line 3: Empty line separator
     */
    fun exportTemplateText(targetLangCode: String = "custom"): String {
        val existing = getTranslationMap(targetLangCode)
        val sb = StringBuilder()
        sb.append("# ====================================================================\n")
        sb.append("# OPENASSIST EXTENSIBLE COMMUNITY TRANSLATION FILE\n")
        sb.append("# Target Language: $targetLangCode\n")
        sb.append("# ====================================================================\n")
        sb.append("# INSTRUCTIONS FOR TRANSLATORS:\n")
        sb.append("# 1. Line 1 contains the English source phrase used in the app.\n")
        sb.append("# 2. Line 2 below it is where you write your translated phrase.\n")
        sb.append("# 3. Keep 1 blank line between phrases for readability.\n")
        sb.append("# 4. If a translated line is left empty, the app defaults to English!\n")
        sb.append("# TIP FROM OZZY: You can paste this entire file into Gemini / ChatGPT\n")
        sb.append("# and ask it to fill in the translation lines, then import it back!\n")
        sb.append("# ====================================================================\n\n")

        for ((english, _) in DEFAULT_STRINGS) {
            sb.append(english).append("\n")
            val trans = existing[english] ?: ""
            sb.append(trans).append("\n\n")
        }
        return sb.toString()
    }

    fun importTranslationText(content: String, targetLangCode: String): Int {
        val cleanLang = targetLangCode.lowercase().trim().replace(Regex("[^a-z0-9_-]"), "_")
        val lines = content.lines()
        val parsed = mutableMapOf<String, String>()
        var i = 0
        while (i < lines.size) {
            val line = lines[i].trim()
            if (line.startsWith("#") || line.isBlank()) {
                i++
                continue
            }
            // English key
            val englishKey = line
            // Translated value on next line if available
            val transLine = if (i + 1 < lines.size) lines[i + 1].trim() else ""
            if (transLine.isNotBlank() && !transLine.startsWith("#")) {
                parsed[englishKey] = transLine
                i += 2
            } else {
                i += 1
            }
            // Skip trailing empty lines
            while (i < lines.size && lines[i].trim().isBlank()) {
                i++
            }
        }
        val current = loadStoredMap(cleanLang).toMutableMap()
        current.putAll(parsed)
        saveStoredMap(cleanLang, current)
        return parsed.size
    }
}
