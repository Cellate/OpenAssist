package com.openassist.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class MascotDialogueStore(private val context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("openassist_mascot_dialogue", Context.MODE_PRIVATE)

    companion object {
        const val KEY_CUSTOM_GENERAL_PHRASES = "custom_general_phrases"
        const val KEY_REMOVED_DEFAULT_PHRASES = "removed_default_phrases"
        const val PREFIX_CUSTOM_MASCOT_PHRASES = "custom_mascot_phrases_"
        const val PREFIX_TRANSLATED_PHRASES = "mascot_trans_"

        // Preloaded default phrases spoken by all mascots
        val DEFAULT_GENERAL_PHRASES = listOf(
            "All systems green! Ask me anything! ✨",
            "Ready to help! Tap to pet me 💖",
            "Circle or box any element on screen to analyze 🔍",
            "Offline Whisper transcription is ready and private 🎙️",
            "Your data stays 100% on your device, always 🛡️",
            "Long-press anywhere or draw a loop on any screen 💫",
            "Tap my avatar anytime for cheerful energy! 🌟",
            "I'm right by your side whenever curiosity strikes! 🚀",
            "Need a quick translation or summary? Just ask! 📖",
            "Everything is running smoothly! You're doing great! 🌈"
        )

        // Preloaded mascot-specific unique personality phrases
        val DEFAULT_MASCOT_SPECIFIC = mapOf(
            "owl-orbital" to listOf(
                "Whoo! Ozzy here, watching over your screen! 🦉",
                "Orbital vision active! Ready for deep discoveries! 🪐",
                "Wide-awake wisdom at your fingertips! ✨"
            ),
            "owl" to listOf(
                "Welcome home, friend! Ready to explore together? 🦉",
                "Curiosity is the beginning of all wisdom! 📜"
            ),
            "fox" to listOf(
                "Nexus synthesis online! What are we discovering today? 🦊",
                "Sharp ears and quick reflexes ready to assist! ⚡",
                "No question is too cunning for us to solve! 🐾"
            ),
            "fox-orbital" to listOf(
                "Astro-lasso ready! Catching thoughts across space! 🦊✨",
                "Pip in orbit! Let's explore the cosmos of ideas! 🚀"
            ),
            "bat" to listOf(
                "Sonic radar locked on! Tuned to your wavelength! 🦇",
                "I can hear the quietest whisper with crystal clarity! 🔊",
                "Navigating through the night with acoustic precision! 🌙"
            ),
            "otter" to listOf(
                "Splashing into the sea of knowledge! Let's dive deep! 🦦",
                "Floating by with fresh ideas and friendly vibes! 🌊",
                "Paws ready to craft something truly amazing! 🐚"
            ),
            "chameleon" to listOf(
                "Rainbow chameleon mode! Adapting to whatever you need! 🦎",
                "Multi-modal chameleon vision locked onto your screen! 🎨",
                "Zero friction, total adaptability! 🌿"
            ),
            "tanuki" to listOf(
                "Offline, loyal, and ready to roll! 🦝",
                "100% local tanuki magic—no big-tech clouds needed! 🍃",
                "Keep calm and let Taro handle the heavy lifting! 🌰"
            ),
            "kitten" to listOf(
                "Purr-fect day to learn together! Meow! 🐱",
                "Curled up in your pocket, ready for action! 🧶",
                "Gentle paws and smart answers for your questions! 🐾"
            ),
            "firefly" to listOf(
                "Illuminating your ideas like a tiny cyber-firefly! 🏮",
                "A little spark of insight can light up the whole screen! 💡",
                "Glowing with enthusiasm to assist you! ✨"
            ),
            "axolotl" to listOf(
                "Glowing with joy to see you, best friend! 🌸",
                "Regenerating good vibes with every search! 🫧",
                "Water you thinking about today? Let's find out! 💖"
            ),
            "orbital" to listOf(
                "Iris orbital loop synchronized and locked! 🪐",
                "Geometric harmony achieved across all interfaces! 💠",
                "Ready to scan and synthesize any visual input! 📡"
            ),
            "whale" to listOf(
                "Navigating the boundless ocean of ideas together! 🐋",
                "Deep-sea acoustic assist at full power! 🌊",
                "Singing a cheerful melody of discovery! 🎵"
            ),
            "sprite" to listOf(
                "Cosmic spark charged up! Bringing high spirits! 💫",
                "Zipping across screens to bring you instant answers! ⚡",
                "Every tap is full of magic! Let's go! ✨"
            )
        )
    }

    private fun getRemovedDefaults(): Set<String> {
        val raw = sp.getString(KEY_REMOVED_DEFAULT_PHRASES, null) ?: return emptySet()
        return try {
            val arr = JSONArray(raw)
            val set = mutableSetOf<String>()
            for (i in 0 until arr.length()) set.add(arr.getString(i))
            set
        } catch (e: Exception) {
            emptySet()
        }
    }

    private fun saveRemovedDefaults(set: Set<String>) {
        val arr = JSONArray()
        for (s in set) arr.put(s)
        sp.edit().putString(KEY_REMOVED_DEFAULT_PHRASES, arr.toString()).apply()
    }

    fun getGeneralPhrases(): List<String> {
        val removed = getRemovedDefaults()
        val defaults = DEFAULT_GENERAL_PHRASES.filter { !removed.contains(it) }
        val raw = sp.getString(KEY_CUSTOM_GENERAL_PHRASES, null) ?: return defaults
        return try {
            val arr = JSONArray(raw)
            val custom = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val s = arr.getString(i)
                if (s.isNotBlank() && !custom.contains(s) && !defaults.contains(s)) {
                    custom.add(s)
                }
            }
            defaults + custom
        } catch (e: Exception) {
            defaults
        }
    }

    fun addGeneralPhrase(phrase: String) {
        val clean = phrase.trim()
        if (clean.isBlank()) return
        val current = getGeneralPhrases().toMutableList()
        if (!current.contains(clean)) {
            val customList = getCustomGeneralOnly().toMutableList()
            customList.add(clean)
            saveCustomGeneral(customList)
        }
    }

    fun removeGeneralPhrase(phrase: String) {
        if (DEFAULT_GENERAL_PHRASES.contains(phrase)) {
            val removed = getRemovedDefaults().toMutableSet()
            removed.add(phrase)
            saveRemovedDefaults(removed)
        }
        val custom = getCustomGeneralOnly().filter { it != phrase }
        saveCustomGeneral(custom)
    }

    private fun getCustomGeneralOnly(): List<String> {
        val raw = sp.getString(KEY_CUSTOM_GENERAL_PHRASES, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<String>()
            for (i in 0 until arr.length()) list.add(arr.getString(i))
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveCustomGeneral(list: List<String>) {
        val arr = JSONArray()
        for (s in list) arr.put(s)
        sp.edit().putString(KEY_CUSTOM_GENERAL_PHRASES, arr.toString()).apply()
    }

    fun getSpecificMascotPhrases(mascotId: String): List<String> {
        val baseId = mascotId.lowercase().trim()
        val defaults = DEFAULT_MASCOT_SPECIFIC[baseId]
            ?: DEFAULT_MASCOT_SPECIFIC.entries.firstOrNull { baseId.startsWith(it.key.split("-")[0]) }?.value
            ?: emptyList()

        val raw = sp.getString(PREFIX_CUSTOM_MASCOT_PHRASES + baseId, null) ?: return defaults
        return try {
            val arr = JSONArray(raw)
            val custom = mutableListOf<String>()
            for (i in 0 until arr.length()) custom.add(arr.getString(i))
            (defaults + custom).distinct()
        } catch (e: Exception) {
            defaults
        }
    }

    fun addSpecificMascotPhrase(mascotId: String, phrase: String) {
        val clean = phrase.trim()
        if (clean.isBlank()) return
        val baseId = mascotId.lowercase().trim()
        val raw = sp.getString(PREFIX_CUSTOM_MASCOT_PHRASES + baseId, null)
        val list = mutableListOf<String>()
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) list.add(arr.getString(i))
            } catch (e: Exception) {}
        }
        if (!list.contains(clean)) {
            list.add(clean)
            val arr = JSONArray()
            for (s in list) arr.put(s)
            sp.edit().putString(PREFIX_CUSTOM_MASCOT_PHRASES + baseId, arr.toString()).apply()
        }
    }

    fun removeSpecificMascotPhrase(mascotId: String, phrase: String) {
        val baseId = mascotId.lowercase().trim()
        val raw = sp.getString(PREFIX_CUSTOM_MASCOT_PHRASES + baseId, null) ?: return
        try {
            val arr = JSONArray(raw)
            val list = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val s = arr.getString(i)
                if (s != phrase) list.add(s)
            }
            val newArr = JSONArray()
            for (s in list) newArr.put(s)
            sp.edit().putString(PREFIX_CUSTOM_MASCOT_PHRASES + baseId, newArr.toString()).apply()
        } catch (e: Exception) {}
    }

    fun getPhraseTranslation(englishPhrase: String, langCode: String): String {
        if (langCode == "en" || langCode.isBlank()) return englishPhrase
        val raw = sp.getString(PREFIX_TRANSLATED_PHRASES + langCode, null) ?: return englishPhrase
        return try {
            val obj = JSONObject(raw)
            obj.optString(englishPhrase, englishPhrase).ifBlank { englishPhrase }
        } catch (e: Exception) {
            englishPhrase
        }
    }

    fun setPhraseTranslation(englishPhrase: String, langCode: String, translation: String) {
        if (langCode == "en" || langCode.isBlank()) return
        val raw = sp.getString(PREFIX_TRANSLATED_PHRASES + langCode, "{}") ?: "{}"
        try {
            val obj = JSONObject(raw)
            if (translation.isBlank()) obj.remove(englishPhrase)
            else obj.put(englishPhrase, translation.trim())
            sp.edit().putString(PREFIX_TRANSLATED_PHRASES + langCode, obj.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getRandomPhrase(mascotId: String?, langCode: String = "en"): String {
        val mid = mascotId ?: "owl-orbital"
        val specific = getSpecificMascotPhrases(mid)
        val general = getGeneralPhrases()
        val combined = if (specific.isNotEmpty() && (0..1).random() == 0) specific else general
        val chosen = combined.randomOrNull() ?: DEFAULT_GENERAL_PHRASES[0]
        return getPhraseTranslation(chosen, langCode)
    }

    fun exportPhrasesTemplate(langCode: String = "custom"): String {
        val sb = StringBuilder()
        sb.append("# ====================================================================\n")
        sb.append("# OPENASSIST MASCOT DIALOGUE & SPEECH TRANSLATION FILE\n")
        sb.append("# Language: $langCode\n")
        sb.append("# ====================================================================\n")
        sb.append("# Format: Line 1 = English Phrase, Line 2 = Translated Phrase, Line 3 = Blank\n")
        sb.append("# Leave line 2 blank to fallback to English.\n")
        sb.append("# ====================================================================\n\n")

        sb.append("# --- GENERAL MASCOT PHRASES (Spoken by all mascots) ---\n\n")
        for (phrase in getGeneralPhrases()) {
            sb.append(phrase).append("\n")
            sb.append(getPhraseTranslation(phrase, langCode).let { if (it == phrase) "" else it }).append("\n\n")
        }

        sb.append("# --- MASCOT SPECIFIC PHRASES ---\n\n")
        for ((mid, phrases) in DEFAULT_MASCOT_SPECIFIC) {
            sb.append("# Mascot: $mid\n")
            for (p in phrases) {
                sb.append(p).append("\n")
                sb.append(getPhraseTranslation(p, langCode).let { if (it == p) "" else it }).append("\n\n")
            }
        }
        return sb.toString()
    }
}
