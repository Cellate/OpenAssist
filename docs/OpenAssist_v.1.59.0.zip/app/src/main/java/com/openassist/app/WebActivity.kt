package com.openassist.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.util.TypedValue
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.Gravity
import android.widget.ScrollView
import android.app.AlertDialog
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

class WebActivity : Activity(), Speech.Callback {
    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var topBar: LinearLayout
    private lateinit var btnMascotChip: LinearLayout
    private lateinit var btnMascot: ImageView
    private lateinit var textMascotName: TextView
    private lateinit var btnModelSwitcher: LinearLayout
    private lateinit var textModelName: TextView
    private var btnPaste: ImageView? = null
    private var btnNewChat: ImageView? = null
    private lateinit var btnLangSwitcher: LinearLayout
    private lateinit var textLangName: TextView
    private lateinit var btnEngineSwitcher: LinearLayout
    private lateinit var textEngineName: TextView
    private lateinit var btnMic: ImageView
    private var btnBrowser: ImageView? = null
    private lateinit var btnSettings: ImageView
    private lateinit var btnMenu: ImageView

    private lateinit var prefs: Prefs
    private lateinit var theme: Ui.Theme
    private var speech: Speech? = null
    private var isDictating = false
    private var currentUrl: String = ""

    // Pending data from Overlay (Circle to Search / Dictation)
    private var pendingText: String? = null
    private var pendingFiles: Array<String>? = null
    private var pendingSubmit: Boolean = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = Prefs(this)
        if (prefs.isDarkMode) {
            setTheme(R.style.Theme_OpenAssist_Dark)
        } else {
            setTheme(R.style.Theme_OpenAssist_Light)
        }
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web)

        theme = Ui.theme(this)
        speech = Speech(this, prefs, this)

        val defaultUrl = AiServices.current(prefs).url
        currentUrl = intent.getStringExtra(EXTRA_URL) ?: defaultUrl

        pendingText = intent.getStringExtra(EXTRA_TEXT)
        pendingFiles = intent.getStringArrayExtra(EXTRA_FILES)
        pendingSubmit = intent.getBooleanExtra(EXTRA_SUBMIT, false)

        webView = findViewById(R.id.web_view)
        progressBar = findViewById(R.id.progress_bar)
        topBar = findViewById(R.id.web_top_bar)
        btnMascotChip = findViewById(R.id.btn_web_mascot_chip)
        btnMascot = findViewById(R.id.btn_web_mascot)
        textMascotName = findViewById(R.id.text_mascot_name)
        btnModelSwitcher = findViewById(R.id.btn_model_switcher)
        textModelName = findViewById(R.id.text_model_name)
        btnLangSwitcher = findViewById(R.id.btn_lang_switcher)
        textLangName = findViewById(R.id.text_lang_name)
        btnEngineSwitcher = findViewById(R.id.btn_engine_switcher)
        textEngineName = findViewById(R.id.text_engine_name)
        btnMic = findViewById(R.id.btn_web_mic)
        btnSettings = findViewById(R.id.btn_web_settings)
        btnMenu = findViewById(R.id.btn_web_menu)

        val queryExtra = intent.getStringExtra("EXTRA_QUERY")
        if (!queryExtra.isNullOrBlank()) {
            pendingText = queryExtra
            pendingSubmit = true
        }

        applyTheming()
        setupTopBarControls()
        setupWebView()

        webView.loadUrl(currentUrl)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent != null) {
            val newUrl = intent.getStringExtra(EXTRA_URL)
            val newText = intent.getStringExtra(EXTRA_TEXT) ?: intent.getStringExtra("EXTRA_QUERY")
            val newFiles = intent.getStringArrayExtra(EXTRA_FILES)
            val newSubmit = intent.getBooleanExtra(EXTRA_SUBMIT, false) || intent.hasExtra("EXTRA_QUERY")

            pendingText = newText
            pendingFiles = newFiles
            pendingSubmit = newSubmit

            if (!newUrl.isNullOrBlank() && newUrl != currentUrl) {
                currentUrl = newUrl
                webView.loadUrl(currentUrl)
            } else if (!pendingText.isNullOrBlank() || !pendingFiles.isNullOrEmpty()) {
                injectPendingAssistData()
            }
        }
    }

    private fun applyTheming() {
        val root = findViewById<View>(R.id.web_root)
        root.setBackgroundColor(theme.BG)
        topBar.setBackgroundColor(theme.SURFACE)

        val padChipH = Ui.dp(this, 10)
        val padChipV = Ui.dp(this, 4)
        btnMascotChip.clipToPadding = false
        btnMascotChip.clipChildren = false
        btnMascotChip.background = Ui.rounded(theme.SURFACE_HI, Ui.dp(this, 16).toFloat())
        btnMascotChip.setPadding(padChipH, padChipV, padChipH, padChipV)

        val padPillH = Ui.dp(this, 8)
        val padPillV = Ui.dp(this, 5)
        btnModelSwitcher.background = Ui.rounded(theme.SURFACE_HI, Ui.dp(this, 18).toFloat())
        btnModelSwitcher.setPadding(padPillH, padPillV, padPillH, padPillV)
        btnLangSwitcher.background = Ui.rounded(theme.SURFACE_HI, Ui.dp(this, 18).toFloat())
        btnLangSwitcher.setPadding(padPillH, padPillV, padPillH, padPillV)
        btnEngineSwitcher.background = Ui.rounded(theme.SURFACE_HI, Ui.dp(this, 18).toFloat())
        btnEngineSwitcher.setPadding(padPillH, padPillV, padPillH, padPillV)

        textMascotName.setTextColor(theme.TEXT)
        textModelName.setTextColor(theme.TEXT)
        textLangName.setTextColor(theme.TEXT)
        textEngineName.setTextColor(theme.TEXT)

        val iconTint = ColorStateList.valueOf(theme.TEXT)
        btnMic.imageTintList = iconTint
        btnSettings.imageTintList = iconTint
        btnMenu.imageTintList = iconTint

        val (mascotDrawable, mascotName) = getMascotInfo(prefs.mascotStyle)
        btnMascot.setImageResource(mascotDrawable)
        textMascotName.text = mascotName

        refreshPills()
        Ui.applySystemBars(this, theme)
    }

    override fun onResume() {
        super.onResume()
        val mascot = MascotHelper.getMascot(prefs.mascotStyle)
        btnMascot.setImageResource(mascot.drawableRes)
        textMascotName.text = mascot.name
        refreshPills()
    }

    private fun refreshPills() {
        val active = AiServices.current(prefs)
        textModelName.text = "${active.name} ▾"
        textLangName.text = prefs.voiceLang.chip
        textEngineName.text = when (prefs.recognizer) {
            Prefs.ENGINE_LOCAL_MODEL -> "Whisper"
            Prefs.ENGINE_GOOGLE_TTS -> "Google"
            Prefs.ENGINE_FUTO_VOICE_INPUT -> "FUTO"
            else -> "Default"
        }
        val (_, mascotName) = getMascotInfo(prefs.mascotStyle)
        textMascotName.text = mascotName
    }

    private fun setupTopBarControls() {
        // 1. Mascot Chip (Leftmost, Adaptive Border & Wholesome Phrases)
        btnMascotChip.setOnClickListener {
            val mascotLang = prefs.translationStore.getEffectiveLanguage("mascot")
            val phrase = prefs.mascotDialogueStore.getRandomPhrase(prefs.mascotStyle, mascotLang)
            Ui.showMascotToast(this, phrase, prefs.mascotStyle, duration = Toast.LENGTH_LONG, type = ToastType.GENERAL)
        }

        // 2. AI Model Switcher Pill
        btnModelSwitcher.setOnClickListener {
            showModelSwitcherDialog()
        }

        // 3. Language Switcher Pill
        btnLangSwitcher.setOnClickListener {
            prefs.voiceLang = prefs.voiceLang.next()
            refreshPills()
            Ui.showMascotToast(this, "Language: ${prefs.voiceLang.label}", prefs.mascotStyle, type = ToastType.SPEECH)
        }

        // 4. Voice Engine Switcher Pill
        btnEngineSwitcher.setOnClickListener {
            showEngineSwitcherDialog()
        }

        // 5. Voice Dictation Mic Button
        btnMic.setOnClickListener {
            toggleDictation()
        }

        // 6. Settings Button
        btnSettings.setOnClickListener {
            openSettings()
        }

        // 7. Hamburger Menu Button (Rightmost: Options + Query History)
        btnMenu.setOnClickListener {
            showWebOptionsMenu()
        }
    }

    private fun startNewChat() {
        val cleanUrl = AiServices.current(prefs).url
        currentUrl = cleanUrl
        webView.loadUrl(cleanUrl)
        Ui.showMascotToast(this, "Started new chat", prefs.mascotStyle, type = ToastType.ASSISTANT)
    }

    private fun openInBrowser() {
        val urlToOpen = webView.url ?: currentUrl
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(urlToOpen)))
        } catch (e: Exception) {
            Ui.showMascotToast(this, "Could not open browser: ${e.message}", prefs.mascotStyle, type = ToastType.ASSISTANT)
        }
    }

    private fun openSettings() {
        try {
            startActivity(Intent(this, SettingsActivity::class.java))
        } catch (e: Exception) {
            Ui.showMascotToast(this, "Could not open Settings", prefs.mascotStyle, type = ToastType.GENERAL)
        }
    }

    private fun showWebOptionsMenu() {
        var dialog: android.app.AlertDialog? = null
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.card(this@WebActivity, theme)
            val pad = Ui.dp(this@WebActivity, 16)
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Assistant Actions"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(theme.TEXT)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Quick actions and conversation history"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTextColor(theme.MUTED)
            setPadding(0, Ui.dp(this@WebActivity, 2), 0, Ui.dp(this@WebActivity, 10))
        })

        fun actionRow(title: String, desc: String, iconRes: Int, onClick: () -> Unit) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val padH = Ui.dp(this@WebActivity, 12)
                val padV = Ui.dp(this@WebActivity, 10)
                setPadding(padH, padV, padH, padV)
                background = Ui.rounded(theme.SURFACE_HI, Ui.dp(this@WebActivity, 8).toFloat())
                isClickable = true
                isFocusable = true
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = Ui.dp(this@WebActivity, 6)
                }
                layoutParams = lp
                setOnClickListener {
                    dialog?.dismiss()
                    onClick()
                }
            }

            val icon = ImageView(this).apply {
                setImageResource(iconRes)
                imageTintList = ColorStateList.valueOf(theme.ACCENT)
                val s = Ui.dp(this@WebActivity, 22)
                layoutParams = LinearLayout.LayoutParams(s, s).apply {
                    rightMargin = Ui.dp(this@WebActivity, 10)
                }
            }
            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            textCol.addView(TextView(this).apply {
                text = title
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(theme.TEXT)
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            })
            textCol.addView(TextView(this).apply {
                text = desc
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setTextColor(theme.MUTED)
            })
            row.addView(icon)
            row.addView(textCol)
            root.addView(row)
        }

        actionRow("Attach Selection", "Paste circled screenshot or clipboard text", R.drawable.ic_paste) {
            attachStagedFilesOrClipboard()
        }
        actionRow("Start New Chat", "Reset to a clean conversational session", R.drawable.ic_chat_new) {
            startNewChat()
        }
        actionRow("Query History", "View past questions & tap to re-ask", R.drawable.ic_sparkle) {
            showFullHistoryDialog()
        }
        actionRow("Open in Browser", "Launch current AI chat in Chrome/browser", R.drawable.ic_browser) {
            openInBrowser()
        }
        actionRow("Settings", "Open OpenAssist companion settings", R.drawable.ic_settings) {
            openSettings()
        }

        val closeBtn = android.widget.Button(this).apply {
            text = "Cancel"
            textSize = 12f
            background = Ui.rounded(android.graphics.Color.TRANSPARENT, Ui.dp(this@WebActivity, 8).toFloat())
            setTextColor(theme.MUTED)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = Ui.dp(this@WebActivity, 6)
            }
            layoutParams = lp
            setOnClickListener { dialog?.dismiss() }
        }
        root.addView(closeBtn)

        val builder = themedBuilder().setView(root)
        dialog = showThemedDialog(builder)
    }

    private fun showFullHistoryDialog() {
        val history = prefs.getAssistantHistory()
        var dialog: android.app.AlertDialog? = null
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.card(this@WebActivity, theme)
            val pad = Ui.dp(this@WebActivity, 16)
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "AI Query History"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(theme.TEXT)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Past questions sent to web assistants • Tap to re-ask"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTextColor(theme.MUTED)
            setPadding(0, Ui.dp(this@WebActivity, 2), 0, Ui.dp(this@WebActivity, 12))
        })

        if (history.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "No questions in history yet. Dictate or send any question to save it here!"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(theme.MUTED)
                setPadding(0, Ui.dp(this@WebActivity, 16), 0, Ui.dp(this@WebActivity, 16))
                gravity = Gravity.CENTER
            }
            root.addView(emptyTv)
        } else {
            val listLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
            }
            for (item in history) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    val padH = Ui.dp(this@WebActivity, 12)
                    val padV = Ui.dp(this@WebActivity, 10)
                    setPadding(padH, padV, padH, padV)
                    background = Ui.rounded(theme.SURFACE_HI, Ui.dp(this@WebActivity, 8).toFloat())
                    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = Ui.dp(this@WebActivity, 6)
                    }
                    layoutParams = lp
                }

                val textCol = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    layoutParams = lp
                    isClickable = true
                    isFocusable = true
                    setOnClickListener {
                        injectTextIntoWeb(item.query, true)
                        Ui.showMascotToast(this@WebActivity, "Asking: " + item.query.take(25) + "...", prefs.mascotStyle, type = ToastType.ASSISTANT)
                        dialog?.dismiss()
                    }
                }

                textCol.addView(TextView(this).apply {
                    text = item.query
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    setTextColor(theme.TEXT)
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                })

                val timeStr = java.text.SimpleDateFormat("MMM d, h:mm a", java.util.Locale.getDefault()).format(java.util.Date(item.timestamp))
                textCol.addView(TextView(this).apply {
                    text = "${item.serviceName} • $timeStr"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                    setTextColor(theme.MUTED)
                    setPadding(0, Ui.dp(this@WebActivity, 2), 0, 0)
                })

                val delBtn = ImageView(this).apply {
                    setImageResource(R.drawable.ic_close)
                    imageTintList = ColorStateList.valueOf(theme.MUTED)
                    val s = Ui.dp(this@WebActivity, 24)
                    val p = Ui.dp(this@WebActivity, 4)
                    layoutParams = LinearLayout.LayoutParams(s, s)
                    setPadding(p, p, p, p)
                    setOnClickListener {
                        prefs.removeAssistantHistory(item.id)
                        dialog?.dismiss()
                        showFullHistoryDialog()
                    }
                }

                row.addView(textCol)
                row.addView(delBtn)
                listLayout.addView(row)
            }

            val scroll = ScrollView(this).apply {
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
                layoutParams = lp
                addView(listLayout)
            }
            root.addView(scroll)
        }

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = Ui.dp(this@WebActivity, 12)
            }
            layoutParams = lp
        }

        if (history.isNotEmpty()) {
            val clearBtn = android.widget.Button(this).apply {
                text = "Clear All"
                textSize = 12f
                background = Ui.rounded(android.graphics.Color.parseColor("#EF4444"), Ui.dp(this@WebActivity, 8).toFloat())
                setTextColor(android.graphics.Color.WHITE)
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    rightMargin = Ui.dp(this@WebActivity, 8)
                }
                layoutParams = lp
                setOnClickListener {
                    prefs.clearAssistantHistory()
                    dialog?.dismiss()
                    Ui.showMascotToast(this@WebActivity, "History cleared", prefs.mascotStyle, type = ToastType.ASSISTANT)
                }
            }
            btnRow.addView(clearBtn)
        }

        val closeBtn = android.widget.Button(this).apply {
            text = "Close"
            textSize = 12f
            background = Ui.rounded(theme.SURFACE_HI, Ui.dp(this@WebActivity, 8).toFloat())
            setTextColor(theme.TEXT)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = lp
            setOnClickListener { dialog?.dismiss() }
        }
        btnRow.addView(closeBtn)
        root.addView(btnRow)

        val builder = themedBuilder().setView(root)
        dialog = showThemedDialog(builder)
    }

    private fun showModelSwitcherDialog() {
        val allServices = AiServices.all(prefs)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.card(this@WebActivity, theme)
            val pad = Ui.dp(this@WebActivity, 16)
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Select AI Web Assistant"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(theme.TEXT)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Switch active model or add custom self-hosted AI endpoints"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTextColor(theme.MUTED)
            setPadding(0, Ui.dp(this@WebActivity, 2), 0, Ui.dp(this@WebActivity, 12))
        })

        var dialog: android.app.AlertDialog? = null
        val listLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        for (srv in allServices) {
            val isCurrent = srv.id == prefs.serviceId
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                val padH = Ui.dp(this@WebActivity, 12)
                val padV = Ui.dp(this@WebActivity, 10)
                setPadding(padH, padV, padH, padV)
                background = Ui.rounded(if (isCurrent) theme.SURFACE_HI else Color.TRANSPARENT, Ui.dp(this@WebActivity, 8).toFloat())
                isClickable = true
                isFocusable = true
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = Ui.dp(this@WebActivity, 4)
                }
                layoutParams = lp
                setOnClickListener {
                    prefs.serviceId = srv.id
                    currentUrl = srv.url
                    refreshPills()
                    webView.loadUrl(currentUrl)
                    Ui.showMascotToast(this@WebActivity, "Loaded ${srv.name}", prefs.mascotStyle, type = ToastType.ASSISTANT)
                    dialog?.dismiss()
                }
            }
            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                layoutParams = lp
            }
            val title = TextView(this).apply {
                text = srv.name
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(if (isCurrent) theme.ACCENT else theme.TEXT)
                if (isCurrent) typeface = android.graphics.Typeface.DEFAULT_BOLD
            }
            val sub = TextView(this).apply {
                text = srv.url
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                setTextColor(theme.MUTED)
                isSingleLine = true
            }
            textCol.addView(title)
            textCol.addView(sub)
            row.addView(textCol)

            if (isCurrent) {
                val check = TextView(this).apply {
                    text = "✓"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                    setTextColor(theme.ACCENT)
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                }
                row.addView(check)
            }
            listLayout.addView(row)
        }
        val scroll = android.widget.ScrollView(this).apply {
            addView(listLayout)
            isFillViewport = true
            val dm = resources.displayMetrics
            val maxH = (dm.heightPixels * 0.40).toInt()
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, maxH)
        }
        root.addView(scroll)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = Ui.dp(this@WebActivity, 12)
            }
            layoutParams = lp
        }
        val addBtn = android.widget.Button(this).apply {
            text = "+ Add Custom AI"
            textSize = 12f
            background = Ui.rounded(theme.ACCENT, Ui.dp(this@WebActivity, 8).toFloat())
            setTextColor(theme.ON_ACCENT)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = Ui.dp(this@WebActivity, 8)
            }
            layoutParams = lp
            setOnClickListener {
                dialog?.dismiss()
                showAddCustomAiDialog()
            }
        }
        val cancelBtn = android.widget.Button(this).apply {
            text = "Cancel"
            textSize = 12f
            background = Ui.rounded(theme.SURFACE_HI, Ui.dp(this@WebActivity, 8).toFloat())
            setTextColor(theme.MUTED)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = lp
            setOnClickListener { dialog?.dismiss() }
        }
        btnRow.addView(addBtn)
        btnRow.addView(cancelBtn)
        root.addView(btnRow)

        dialog = android.app.AlertDialog.Builder(this)
            .setView(root)
            .create()
        dialog.show()
        dialog.window?.let { win ->
            win.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            win.decorView.setBackgroundColor(Color.TRANSPARENT)
            val dm = resources.displayMetrics
            win.setLayout(
                (dm.widthPixels * 0.92).toInt().coerceAtMost(Ui.dp(this, 440)),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
    }

    private fun showAddCustomAiDialog() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.card(this@WebActivity, theme)
            val pad = Ui.dp(this@WebActivity, 16)
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Add Custom AI Web Assistant"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(theme.TEXT)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Enter the name and full web URL (e.g. self-hosted Ollama or WebUI)"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTextColor(theme.MUTED)
            setPadding(0, Ui.dp(this@WebActivity, 2), 0, Ui.dp(this@WebActivity, 12))
        })

        val nameInput = android.widget.EditText(this).apply {
            hint = "AI Name (e.g. Open WebUI, Ollama)"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(theme.TEXT)
            setHintTextColor(theme.MUTED)
            background = Ui.rounded(theme.SURFACE_HI, Ui.dp(this@WebActivity, 8).toFloat())
            val p = Ui.dp(this@WebActivity, 10)
            setPadding(p, p, p, p)
        }
        val urlInput = android.widget.EditText(this).apply {
            hint = "Web URL (e.g. https://... or http://192.168.1.x:3000)"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(theme.TEXT)
            setHintTextColor(theme.MUTED)
            background = Ui.rounded(theme.SURFACE_HI, Ui.dp(this@WebActivity, 8).toFloat())
            val p = Ui.dp(this@WebActivity, 10)
            setPadding(p, p, p, p)
        }
        root.addView(nameInput)
        val sp = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, Ui.dp(this@WebActivity, 8)) }
        root.addView(sp)
        root.addView(urlInput)

        var dialog: android.app.AlertDialog? = null
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = Ui.dp(this@WebActivity, 14)
            }
            layoutParams = lp
        }
        val addBtn = android.widget.Button(this).apply {
            text = "Add & Select"
            textSize = 12f
            background = Ui.rounded(theme.ACCENT, Ui.dp(this@WebActivity, 8).toFloat())
            setTextColor(theme.ON_ACCENT)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = Ui.dp(this@WebActivity, 8)
            }
            layoutParams = lp
            setOnClickListener {
                val name = nameInput.text.toString().trim()
                val url = urlInput.text.toString().trim()
                if (url.isNotBlank()) {
                    val newService = prefs.addCustomService(name, url)
                    prefs.serviceId = newService.id
                    currentUrl = newService.url
                    refreshPills()
                    webView.loadUrl(currentUrl)
                    Ui.showMascotToast(this@WebActivity, "Added and selected ${newService.name}", prefs.mascotStyle, type = ToastType.ASSISTANT)
                    dialog?.dismiss()
                } else {
                    Ui.showMascotToast(this@WebActivity, "Please enter a valid URL", prefs.mascotStyle, type = ToastType.ASSISTANT)
                }
            }
        }
        val cancelBtn = android.widget.Button(this).apply {
            text = "Cancel"
            textSize = 12f
            background = Ui.rounded(theme.SURFACE_HI, Ui.dp(this@WebActivity, 8).toFloat())
            setTextColor(theme.MUTED)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = lp
            setOnClickListener { dialog?.dismiss() }
        }
        btnRow.addView(addBtn)
        btnRow.addView(cancelBtn)
        root.addView(btnRow)

        dialog = android.app.AlertDialog.Builder(this)
            .setView(root)
            .create()
        dialog.show()
        dialog.window?.let { win ->
            win.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            win.decorView.setBackgroundColor(Color.TRANSPARENT)
            val dm = resources.displayMetrics
            win.setLayout(
                (dm.widthPixels * 0.92).toInt().coerceAtMost(Ui.dp(this, 440)),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
    }

    private fun showEngineSwitcherDialog() {
        val engines = listOf(
            Triple(Prefs.ENGINE_DEFAULT, "System Default Speech Recognizer", "Android standard framework speech pipeline"),
            Triple(Prefs.ENGINE_LOCAL_MODEL, "Local Model Mode (Whisper)", "100% offline & private multi-model Whisper"),
            Triple(Prefs.ENGINE_GOOGLE_TTS, "Google Speech Recognition", "Native Google cloud typing for Android / ColorOS"),
            Triple(Prefs.ENGINE_FUTO_VOICE_INPUT, "FUTO Voice Input / Keyboard", "Fast on-device neural offline Whisper")
        )

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.card(this@WebActivity, theme)
            val pad = Ui.dp(this@WebActivity, 16)
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Select Voice Input Source"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(theme.TEXT)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Choose your speech recognition engine for voice dictation"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTextColor(theme.MUTED)
            setPadding(0, Ui.dp(this@WebActivity, 2), 0, Ui.dp(this@WebActivity, 12))
        })

        var dialog: android.app.AlertDialog? = null
        val listLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        for ((engineKey, engineName, engineDesc) in engines) {
            val isCurrent = prefs.recognizer == engineKey
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val padH = Ui.dp(this@WebActivity, 12)
                val padV = Ui.dp(this@WebActivity, 10)
                setPadding(padH, padV, padH, padV)
                background = Ui.rounded(if (isCurrent) theme.SURFACE_HI else Color.TRANSPARENT, Ui.dp(this@WebActivity, 8).toFloat())
                isClickable = true
                isFocusable = true
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = Ui.dp(this@WebActivity, 4)
                }
                layoutParams = lp
                setOnClickListener {
                    prefs.recognizer = engineKey
                    refreshPills()
                    Ui.showMascotToast(this@WebActivity, "Voice Engine: $engineName", prefs.mascotStyle, type = ToastType.SPEECH)
                    dialog?.dismiss()
                }
            }
            val titleRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            val title = TextView(this).apply {
                text = engineName
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(if (isCurrent) theme.ACCENT else theme.TEXT)
                if (isCurrent) typeface = android.graphics.Typeface.DEFAULT_BOLD
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                layoutParams = lp
            }
            titleRow.addView(title)
            if (isCurrent) {
                val check = TextView(this).apply {
                    text = "✓"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                    setTextColor(theme.ACCENT)
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                }
                titleRow.addView(check)
            }
            row.addView(titleRow)
            val desc = TextView(this).apply {
                text = engineDesc
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                setTextColor(theme.MUTED)
                setPadding(0, Ui.dp(this@WebActivity, 2), 0, 0)
            }
            row.addView(desc)
            listLayout.addView(row)
        }
        root.addView(listLayout)

        val cancelBtn = android.widget.Button(this).apply {
            text = "Cancel"
            textSize = 12f
            background = Ui.rounded(theme.SURFACE_HI, Ui.dp(this@WebActivity, 8).toFloat())
            setTextColor(theme.MUTED)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = Ui.dp(this@WebActivity, 10)
            }
            layoutParams = lp
            setOnClickListener { dialog?.dismiss() }
        }
        root.addView(cancelBtn)

        dialog = android.app.AlertDialog.Builder(this)
            .setView(root)
            .create()
        dialog.show()
        dialog.window?.let { win ->
            win.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            win.decorView.setBackgroundColor(Color.TRANSPARENT)
            val dm = resources.displayMetrics
            win.setLayout(
                (dm.widthPixels * 0.92).toInt().coerceAtMost(Ui.dp(this, 440)),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true
            loadWithOverviewMode = true

            if (Build.VERSION.SDK_INT >= 29) {
                @Suppress("DEPRECATION")
                forceDark = if (prefs.isDarkMode) WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_OFF
            }
            if (Build.VERSION.SDK_INT >= 33) {
                isAlgorithmicDarkeningAllowed = prefs.isDarkMode
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress < 100) {
                    progressBar.visibility = View.VISIBLE
                    progressBar.progress = newProgress
                } else {
                    progressBar.visibility = View.GONE
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, startUrl: String?, favicon: Bitmap?) {
                applyWebsiteTheme()
            }

            override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                applyWebsiteTheme()
                injectPendingAssistData()
                if (!finishedUrl.isNullOrBlank() && !finishedUrl.equals("about:blank", ignoreCase = true)) {
                    currentUrl = finishedUrl
                    prefs.updateLatestAssistantHistoryUrl(finishedUrl)
                }
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                if (!url.isNullOrBlank() && !url.equals("about:blank", ignoreCase = true)) {
                    currentUrl = url
                    prefs.updateLatestAssistantHistoryUrl(url)
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val reqUrl = request?.url ?: return false
                val scheme = reqUrl.scheme ?: ""
                if (scheme == "http" || scheme == "https") {
                    return false
                }
                return try {
                    val intent = Intent(Intent.ACTION_VIEW, reqUrl)
                    startActivity(intent)
                    true
                } catch (e: Exception) {
                    true
                }
            }
        }
    }

    private fun applyWebsiteTheme() {
        val isDark = prefs.isDarkMode

        if (Build.VERSION.SDK_INT >= 29) {
            @Suppress("DEPRECATION")
            webView.settings.forceDark = if (isDark) WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_OFF
        }
        if (Build.VERSION.SDK_INT >= 33) {
            webView.settings.isAlgorithmicDarkeningAllowed = isDark
        }

        val themeJs = """
            (function() {
                try {
                    const isDark = $isDark;
                    
                    // 1. Meta color-scheme
                    let meta = document.querySelector('meta[name="color-scheme"]');
                    if (!meta) {
                        meta = document.createElement('meta');
                        meta.name = 'color-scheme';
                        document.head.appendChild(meta);
                    }
                    meta.content = isDark ? 'dark' : 'light';
                    
                    // 2. HTML & Body attributes & classes (Gemini, ChatGPT, Claude, Perplexity)
                    if (isDark) {
                        document.documentElement.classList.add('dark', 'dark-theme', 'theme-dark');
                        document.documentElement.classList.remove('light', 'light-theme', 'theme-light');
                        document.documentElement.setAttribute('data-theme', 'dark');
                        document.documentElement.setAttribute('color-scheme', 'dark');
                        document.documentElement.style.colorScheme = 'dark';
                        if (document.body) {
                            document.body.classList.add('dark', 'dark-theme', 'theme-dark');
                            document.body.classList.remove('light', 'light-theme', 'theme-light');
                            document.body.setAttribute('data-theme', 'dark');
                            document.body.style.colorScheme = 'dark';
                        }
                    } else {
                        document.documentElement.classList.remove('dark', 'dark-theme', 'theme-dark');
                        document.documentElement.classList.add('light', 'light-theme', 'theme-light');
                        document.documentElement.setAttribute('data-theme', 'light');
                        document.documentElement.setAttribute('color-scheme', 'light');
                        document.documentElement.style.colorScheme = 'light';
                        if (document.body) {
                            document.body.classList.remove('dark', 'dark-theme', 'theme-dark');
                            document.body.classList.add('light', 'light-theme', 'theme-light');
                            document.body.setAttribute('data-theme', 'light');
                            document.body.style.colorScheme = 'light';
                        }
                    }

                    // 3. LocalStorage persistence
                    try { localStorage.setItem('theme', isDark ? 'dark' : 'light'); } catch(e){}
                    try { localStorage.setItem('color-theme', isDark ? 'dark' : 'light'); } catch(e){}
                    try { localStorage.setItem('selectedTheme', isDark ? 'dark' : 'light'); } catch(e){}
                } catch(e) {}
            })();
        """.trimIndent()
        webView.evaluateJavascript(themeJs, null)
    }

    private fun injectPendingAssistData() {
        val textToInject = pendingText
        val filesToInject = pendingFiles
        val shouldSubmit = pendingSubmit

        val hasImage = !filesToInject.isNullOrEmpty() || (StagedFiles.lastSelection != null && StagedFiles.lastSelection?.file?.exists() == true && intent?.getStringExtra(EXTRA_MODE) == MODE_IMAGE)
        val firstFilePath = filesToInject?.firstOrNull() ?: if (intent?.getStringExtra(EXTRA_MODE) == MODE_IMAGE) StagedFiles.lastSelection?.file?.absolutePath else null

        if (textToInject.isNullOrBlank() && !hasImage) {
            return
        }

        // 1. Inject image if present
        if (hasImage && firstFilePath != null) {
            val file = File(firstFilePath)
            if (file.exists()) {
                val bm = BitmapFactory.decodeFile(file.absolutePath)
                if (bm != null) {
                    ClipboardHelper.copyImage(this, bm)
                }
                val b64 = encodeFileToBase64(file)
                if (b64 != null) {
                    injectBase64ImageIntoWeb(b64, "image/png")
                }
            }
        }

        // 2. Inject text if present (sequenced after image attachment to avoid wiping draft image chips)
        if (!textToInject.isNullOrBlank()) {
            if (hasImage) {
                webView.postDelayed({
                    injectTextIntoWeb(textToInject, shouldSubmit)
                }, 550)
            } else {
                injectTextIntoWeb(textToInject, shouldSubmit)
            }
        }

        // Clear consumed pending values
        pendingText = null
        pendingFiles = null
        pendingSubmit = false
    }

    private fun encodeFileToBase64(file: File): String? {
        return try {
            val bytes = file.readBytes()
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    private fun injectTextIntoWeb(text: String, submit: Boolean) {
        val activeService = AiServices.current(prefs)
        prefs.addAssistantHistory(text, activeService.id, activeService.name, currentUrl)

        val escaped = text.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "")
        val js = """
            (function() {
                let attempts = 0;
                function tryInject() {
                    attempts++;
                    const el = document.querySelector('rich-textarea [contenteditable="true"]') ||
                               document.querySelector('div.ql-editor') ||
                               document.querySelector('#prompt-textarea') ||
                               document.querySelector('div[contenteditable="true"][role="textbox"]') ||
                               document.querySelector('div[contenteditable="true"]') ||
                               document.querySelector('textarea#chat-input') ||
                               document.querySelector('textarea') ||
                               document.querySelector('input[type="text"]');
                    if (el) {
                        el.focus();
                        try {
                            document.execCommand('selectAll', false, null);
                            document.execCommand('insertText', false, "$escaped");
                        } catch(e) {}
                        
                        if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
                            if (!el.value || !el.value.includes("$escaped")) {
                                el.value = (el.value ? el.value + ' ' : '') + "$escaped";
                            }
                            el.dispatchEvent(new Event('input', { bubbles: true }));
                            el.dispatchEvent(new Event('change', { bubbles: true }));
                        } else if (el.isContentEditable) {
                            if (!el.textContent || !el.textContent.includes("$escaped")) {
                                el.innerHTML = '<p>' + "$escaped" + '</p>';
                            }
                            el.dispatchEvent(new Event('input', { bubbles: true }));
                        }
                        
                        if ($submit) {
                            setTimeout(() => {
                                const btn = document.querySelector('button[aria-label*="Send"], button[aria-label*="Submit"], [data-testid="send-button"], button.send-button, button.send-button-container, button[aria-label*="prompt"]');
                                if (btn && !btn.disabled) btn.click();
                            }, 500);
                        }
                        return true;
                    }
                    if (attempts < 25) {
                        setTimeout(tryInject, 350);
                    }
                    return false;
                }
                tryInject();
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun injectBase64ImageIntoWeb(b64: String, mimeType: String) {
        val js = """
            (function() {
                let attempts = 0;
                function tryInjectImage() {
                    attempts++;
                    try {
                        const byteCharacters = atob("$b64");
                        const byteNumbers = new Uint8Array(byteCharacters.length);
                        for (let i = 0; i < byteCharacters.length; i++) {
                            byteNumbers[i] = byteCharacters.charCodeAt(i);
                        }
                        const file = new File([byteNumbers], "circled_screenshot.png", { type: "$mimeType" });
                        
                        const dt = new DataTransfer();
                        dt.items.add(file);
                        
                        let handled = false;
                        const fileInput = document.querySelector('input[type="file"]');
                        if (fileInput) {
                            try {
                                fileInput.files = dt.files;
                                fileInput.dispatchEvent(new Event('change', { bubbles: true }));
                                fileInput.dispatchEvent(new Event('input', { bubbles: true }));
                                handled = true;
                            } catch(e) {}
                        }

                        const target = document.querySelector('rich-textarea [contenteditable="true"]') ||
                                       document.querySelector('div.ql-editor') ||
                                       document.querySelector('#prompt-textarea') ||
                                       document.querySelector('div[contenteditable="true"][role="textbox"]') ||
                                       document.querySelector('div[contenteditable="true"]') ||
                                       document.querySelector('textarea') ||
                                       document.querySelector('body');
                        if (target) {
                            target.focus();
                            const pasteEvent = new ClipboardEvent('paste', {
                                bubbles: true,
                                cancelable: true,
                                clipboardData: dt
                            });
                            target.dispatchEvent(pasteEvent);
                            
                            const dropEvent = new DragEvent('drop', {
                                bubbles: true,
                                cancelable: true,
                                dataTransfer: dt
                            });
                            target.dispatchEvent(dropEvent);
                            handled = true;
                        }
                        if (handled) return true;
                    } catch(e) {}
                    
                    if (attempts < 25) {
                        setTimeout(tryInjectImage, 350);
                    }
                    return false;
                }
                tryInjectImage();
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun attachStagedFilesOrClipboard() {
        try {
            val last = StagedFiles.lastSelection
            if (last != null && last.file.exists()) {
                val bm = BitmapFactory.decodeFile(last.file.absolutePath)
                if (bm != null) {
                    ClipboardHelper.copyImage(this, bm)
                }
                val b64 = encodeFileToBase64(last.file)
                if (b64 != null) {
                    injectBase64ImageIntoWeb(b64, "image/png")
                }
                Ui.showMascotToast(this, "Circled screenshot attached & copied to clipboard!", prefs.mascotStyle, duration = Toast.LENGTH_LONG, type = ToastType.CIRCLE)
                return
            }

            // Fallback to text on clipboard
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clipText = cm?.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!clipText.isNullOrBlank()) {
                injectTextIntoWeb(clipText, false)
                Ui.showMascotToast(this, "Pasted clipboard text into chat", prefs.mascotStyle, type = ToastType.CIRCLE)
                return
            }

            Ui.showMascotToast(this, "No circled screenshot or clipboard content to attach", prefs.mascotStyle, type = ToastType.CIRCLE)
        } catch (e: Exception) {
            Ui.showMascotToast(this, "Could not attach selection: ${e.message}", prefs.mascotStyle, type = ToastType.CIRCLE)
        }
    }

    private fun toggleDictation() {
        if (isDictating) {
            speech?.stop()
            isDictating = false
            btnMic.imageTintList = ColorStateList.valueOf(theme.TEXT)
        } else {
            isDictating = true
            btnMic.imageTintList = ColorStateList.valueOf(Color.parseColor("#EF4444"))
            Ui.showMascotToast(this, "Listening...", prefs.mascotStyle, type = ToastType.SPEECH)
            speech?.start()
        }
    }

    override fun onStarting(engineName: String) {
        runOnUiThread {
            Ui.showMascotToast(this, "Listening via $engineName...", prefs.mascotStyle, type = ToastType.SPEECH)
        }
    }

    override fun onPartial(text: String) {}

    override fun onFinal(text: String) {
        runOnUiThread {
            isDictating = false
            btnMic.imageTintList = ColorStateList.valueOf(theme.TEXT)
            if (text.isNotBlank()) {
                val outText = if (prefs.voiceLang == VoiceLang.HINGLISH) Translit.toHinglish(text) else text
                injectTextIntoWeb(outText, prefs.autoSubmit)
                Ui.showMascotToast(this, "Dictated: $outText", prefs.mascotStyle, type = ToastType.SPEECH)
            }
        }
    }

    override fun onError(message: String) {
        runOnUiThread {
            isDictating = false
            btnMic.imageTintList = ColorStateList.valueOf(theme.TEXT)
            Ui.showMascotToast(this, message, prefs.mascotStyle, type = ToastType.SPEECH)
        }
    }

    override fun onStateChanged(listening: Boolean, engineName: String) {
        runOnUiThread {
            isDictating = listening
            btnMic.imageTintList = if (listening) {
                ColorStateList.valueOf(Color.parseColor("#EF4444"))
            } else {
                ColorStateList.valueOf(theme.TEXT)
            }
        }
    }

    private fun getMascotInfo(style: String): Pair<Int, String> {
        val m = MascotHelper.getMascot(style)
        return Pair(m.drawableRes, m.name)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speech?.destroy()
        speech = null
    }

    
    private fun themedBuilder(): AlertDialog.Builder {
        val themeRes = if (theme.isDark) R.style.Theme_OpenAssist_Dark else R.style.Theme_OpenAssist_Light
        return AlertDialog.Builder(this, themeRes)
    }

    private fun showThemedDialog(builder: AlertDialog.Builder): AlertDialog {
        val dialog = builder.create()
        dialog.show()
        dialog.window?.let { win ->
            win.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            win.decorView.setBackgroundColor(Color.TRANSPARENT)
            val dm = resources.displayMetrics
            win.setLayout(
                (dm.widthPixels * 0.92).toInt().coerceAtMost(Ui.dp(this, 440)),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        Ui.styleDialog(dialog, theme)
        return dialog
    }

    companion object {
        const val EXTRA_URL = "extra_url"
        const val EXTRA_QUERY_TEXT = "extra_query"
        const val EXTRA_SERVICE_ID = "extra_service_id"
        const val EXTRA_TITLE = "extra_title"
        const val ACTION_ASSIST = "com.openassist.app.ACTION_ASSIST"
        const val EXTRA_MODE = "extra_mode"
        const val EXTRA_TEXT = "extra_text"
        const val EXTRA_SUBMIT = "extra_submit"
        const val EXTRA_FILES = "extra_files"
        const val MODE_TEXT = "mode_text"
        const val MODE_IMAGE = "mode_image"
    }
}
