export type ServiceCategory = 'all' | 'ai' | 'search' | 'social' | 'productivity' | 'custom';

export interface AssistService {
  id: string;
  name: string;
  url: string;
  category: 'ai' | 'search' | 'social' | 'productivity' | 'custom';
  color?: string;
  isCustom?: boolean;
  isEnabled: boolean;
  openInApp: boolean;
  packageName?: string;
  deepLinkTemplate?: string;
  searchUrlTemplate?: string;
}

export const CATEGORY_LABELS: Record<ServiceCategory, string> = {
  all: 'All Services',
  ai: 'AI Models',
  search: 'Search & Knowledge',
  social: 'Social & Media',
  productivity: 'Productivity & Shopping',
  custom: 'Custom'
};

export const BUILT_IN_SERVICES: AssistService[] = [
  // 1. AI Models
  {
    id: 'gemini',
    name: 'Gemini',
    url: 'https://gemini.google.com/app',
    category: 'ai',
    color: '#1A73E8',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.google.android.apps.bard'
  },
  {
    id: 'chatgpt',
    name: 'ChatGPT',
    url: 'https://chatgpt.com/',
    category: 'ai',
    color: '#10A37F',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.openai.chatgpt'
  },
  {
    id: 'claude',
    name: 'Claude',
    url: 'https://claude.ai/new',
    category: 'ai',
    color: '#D97706',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.anthropic.claude'
  },
  {
    id: 'perplexity',
    name: 'Perplexity',
    url: 'https://www.perplexity.ai/search?q={q}',
    category: 'ai',
    color: '#20B2AA',
    isEnabled: true,
    openInApp: false,
    searchUrlTemplate: 'https://www.perplexity.ai/search?q={q}',
    packageName: 'ai.perplexity.app.android'
  },
  {
    id: 'deepseek',
    name: 'DeepSeek',
    url: 'https://chat.deepseek.com/',
    category: 'ai',
    color: '#4F46E5',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.deepseek.chat'
  },
  {
    id: 'grok',
    name: 'Grok',
    url: 'https://grok.com/',
    category: 'ai',
    color: '#6366F1',
    isEnabled: true,
    openInApp: false
  },
  {
    id: 'mistral',
    name: 'Le Chat',
    url: 'https://chat.mistral.ai/chat',
    category: 'ai',
    color: '#FF7000',
    isEnabled: true,
    openInApp: false
  },
  {
    id: 'copilot',
    name: 'Copilot',
    url: 'https://copilot.microsoft.com/',
    category: 'ai',
    color: '#0078D4',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.microsoft.copilot'
  },
  {
    id: 'qwen',
    name: 'Qwen',
    url: 'https://chat.qwen.ai/',
    category: 'ai',
    color: '#6A1B9A',
    isEnabled: true,
    openInApp: false
  },
  {
    id: 'ollama',
    name: 'Ollama (Local)',
    url: 'http://localhost:11434/',
    category: 'ai',
    color: '#10B981',
    isEnabled: true,
    openInApp: false
  },
  {
    id: 'huggingchat',
    name: 'HuggingChat',
    url: 'https://huggingface.co/chat/',
    category: 'ai',
    color: '#FBBF24',
    isEnabled: true,
    openInApp: false
  },
  {
    id: 'poe',
    name: 'Poe',
    url: 'https://poe.com/',
    category: 'ai',
    color: '#8B5CF6',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.poe.android'
  },

  // 2. Search & Knowledge
  {
    id: 'google',
    name: 'Google',
    url: 'https://www.google.com/search?q={q}',
    category: 'search',
    color: '#4285F4',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.google.android.googlequicksearchbox',
    deepLinkTemplate: 'https://www.google.com/search?q={q}',
    searchUrlTemplate: 'https://www.google.com/search?q={q}'
  },
  {
    id: 'youtube',
    name: 'YouTube',
    url: 'https://www.youtube.com/results?search_query={q}',
    category: 'search',
    color: '#FF0000',
    isEnabled: true,
    openInApp: true,
    packageName: 'com.google.android.youtube',
    deepLinkTemplate: 'vnd.youtube://results?search_query={q}',
    searchUrlTemplate: 'https://www.youtube.com/results?search_query={q}'
  },
  {
    id: 'reddit',
    name: 'Reddit',
    url: 'https://www.reddit.com/search/?q={q}',
    category: 'search',
    color: '#FF4500',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.reddit.frontpage',
    deepLinkTemplate: 'https://www.reddit.com/search/?q={q}',
    searchUrlTemplate: 'https://www.reddit.com/search/?q={q}'
  },
  {
    id: 'x',
    name: 'X (Twitter)',
    url: 'https://x.com/search?q={q}',
    category: 'search',
    color: '#000000',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.twitter.android',
    deepLinkTemplate: 'twitter://search?query={q}',
    searchUrlTemplate: 'https://x.com/search?q={q}'
  },
  {
    id: 'wikipedia',
    name: 'Wikipedia',
    url: 'https://en.wikipedia.org/w/index.php?search={q}',
    category: 'search',
    color: '#636466',
    isEnabled: true,
    openInApp: false,
    packageName: 'org.wikipedia',
    searchUrlTemplate: 'https://en.wikipedia.org/w/index.php?search={q}'
  },
  {
    id: 'github',
    name: 'GitHub',
    url: 'https://github.com/search?q={q}',
    category: 'search',
    color: '#24292E',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.github.android',
    searchUrlTemplate: 'https://github.com/search?q={q}'
  },
  {
    id: 'duckduckgo',
    name: 'DuckDuckGo',
    url: 'https://duckduckgo.com/?q={q}',
    category: 'search',
    color: '#DE5833',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.duckduckgo.mobile.android',
    searchUrlTemplate: 'https://duckduckgo.com/?q={q}'
  },
  {
    id: 'stackoverflow',
    name: 'StackOverflow',
    url: 'https://stackoverflow.com/search?q={q}',
    category: 'search',
    color: '#F48024',
    isEnabled: true,
    openInApp: false,
    searchUrlTemplate: 'https://stackoverflow.com/search?q={q}'
  },
  {
    id: 'arxiv',
    name: 'ArXiv',
    url: 'https://arxiv.org/search/?query={q}&searchtype=all',
    category: 'search',
    color: '#B31B1B',
    isEnabled: true,
    openInApp: false,
    searchUrlTemplate: 'https://arxiv.org/search/?query={q}&searchtype=all'
  },
  {
    id: 'quora',
    name: 'Quora',
    url: 'https://www.quora.com/search?q={q}',
    category: 'search',
    color: '#A82400',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.quora.android',
    searchUrlTemplate: 'https://www.quora.com/search?q={q}'
  },

  // 3. Social & Media
  {
    id: 'instagram',
    name: 'Instagram',
    url: 'https://www.instagram.com/explore/search/permalink/?query={q}',
    category: 'social',
    color: '#E4405F',
    isEnabled: true,
    openInApp: true,
    packageName: 'com.instagram.android',
    deepLinkTemplate: 'instagram://search?query={q}',
    searchUrlTemplate: 'https://www.instagram.com/explore/search/permalink/?query={q}'
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    url: 'https://www.tiktok.com/search?q={q}',
    category: 'social',
    color: '#000000',
    isEnabled: true,
    openInApp: true,
    packageName: 'com.zhiliaoapp.musically',
    deepLinkTemplate: 'snssdk1128://search?keyword={q}',
    searchUrlTemplate: 'https://www.tiktok.com/search?q={q}'
  },
  {
    id: 'facebook',
    name: 'Facebook',
    url: 'https://www.facebook.com/search/top/?q={q}',
    category: 'social',
    color: '#1877F2',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.facebook.katana',
    deepLinkTemplate: 'fb://search/top?q={q}',
    searchUrlTemplate: 'https://www.facebook.com/search/top/?q={q}'
  },
  {
    id: 'pinterest',
    name: 'Pinterest',
    url: 'https://www.pinterest.com/search/pins/?q={q}',
    category: 'social',
    color: '#E60023',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.pinterest',
    deepLinkTemplate: 'pinterest://search/pins/?q={q}',
    searchUrlTemplate: 'https://www.pinterest.com/search/pins/?q={q}'
  },
  {
    id: 'spotify',
    name: 'Spotify',
    url: 'https://open.spotify.com/search/{q}',
    category: 'social',
    color: '#1DB954',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.spotify.music',
    deepLinkTemplate: 'spotify:search:{q}',
    searchUrlTemplate: 'https://open.spotify.com/search/{q}'
  },
  {
    id: 'twitch',
    name: 'Twitch',
    url: 'https://www.twitch.tv/search?term={q}',
    category: 'social',
    color: '#9146FF',
    isEnabled: true,
    openInApp: false,
    packageName: 'tv.twitch.android.app',
    searchUrlTemplate: 'https://www.twitch.tv/search?term={q}'
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    url: 'https://www.linkedin.com/search/results/all/?keywords={q}',
    category: 'social',
    color: '#0A66C2',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.linkedin.android',
    searchUrlTemplate: 'https://www.linkedin.com/search/results/all/?keywords={q}'
  },
  {
    id: 'threads',
    name: 'Threads',
    url: 'https://www.threads.net/search?q={q}',
    category: 'social',
    color: '#000000',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.instagram.barcelona',
    searchUrlTemplate: 'https://www.threads.net/search?q={q}'
  },

  // 4. Productivity & Shopping
  {
    id: 'amazon',
    name: 'Amazon',
    url: 'https://www.amazon.com/s?k={q}',
    category: 'productivity',
    color: '#FF9900',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.amazon.mShop.android.shopping',
    searchUrlTemplate: 'https://www.amazon.com/s?k={q}'
  },
  {
    id: 'googlemaps',
    name: 'Google Maps',
    url: 'https://www.google.com/maps/search/{q}',
    category: 'productivity',
    color: '#34A853',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.google.android.apps.maps',
    deepLinkTemplate: 'geo:0,0?q={q}',
    searchUrlTemplate: 'https://www.google.com/maps/search/{q}'
  },
  {
    id: 'ebay',
    name: 'eBay',
    url: 'https://www.ebay.com/sch/i.html?_nkw={q}',
    category: 'productivity',
    color: '#E53238',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.ebay.mobile',
    searchUrlTemplate: 'https://www.ebay.com/sch/i.html?_nkw={q}'
  },
  {
    id: 'wolframalpha',
    name: 'WolframAlpha',
    url: 'https://www.wolframalpha.com/input?i={q}',
    category: 'productivity',
    color: '#DD1100',
    isEnabled: true,
    openInApp: false,
    searchUrlTemplate: 'https://www.wolframalpha.com/input?i={q}'
  },
  {
    id: 'translate',
    name: 'Google Translate',
    url: 'https://translate.google.com/?sl=auto&tl=en&text={q}&op=translate',
    category: 'productivity',
    color: '#4285F4',
    isEnabled: true,
    openInApp: false,
    packageName: 'com.google.android.apps.translate',
    searchUrlTemplate: 'https://translate.google.com/?sl=auto&tl=en&text={q}&op=translate'
  }
];

export function getSearchUrl(service: AssistService, rawQuery: string): string {
  const trimmed = rawQuery.trim();
  const template = service.searchUrlTemplate || (service.url.includes('{q}') ? service.url : null);
  if (template) {
    const encoded = encodeURIComponent(trimmed);
    return template.replace('{q}', encoded);
  }
  if (trimmed && service.category !== 'ai') {
    const sep = service.url.includes('?') ? '&' : '?';
    return `${service.url}${sep}q=${encodeURIComponent(trimmed)}`;
  }
  return service.url;
}

export function getAppDeepLinkUri(service: AssistService, rawQuery: string): string | null {
  if (!service.deepLinkTemplate) return null;
  return service.deepLinkTemplate.replace('{q}', encodeURIComponent(rawQuery.trim()));
}

export const SERVICES_STORAGE_KEY = 'openassist_services_v162';
export const HISTORY_ENABLED_KEY = 'openassist_history_enabled';
export const AUTOSPEAK_ENABLED_KEY = 'openassist_autospeak_enabled';
export const SPEECH_RATE_KEY = 'openassist_speech_rate';
export const AUDIO_MINIMIZED_KEY = 'openassist_audio_minimized';

export function getStoredServices(): AssistService[] {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(SERVICES_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    }
  } catch (e) {
    // ignore
  }
  return BUILT_IN_SERVICES;
}

export function saveStoredServices(services: AssistService[]): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(SERVICES_STORAGE_KEY, JSON.stringify(services));
    }
  } catch (e) {
    // ignore
  }
}

export function getStoredHistoryEnabled(): boolean {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(HISTORY_ENABLED_KEY);
      if (raw !== null) return raw === 'true';
    }
  } catch (e) {
    // ignore
  }
  return true;
}

export function saveStoredHistoryEnabled(enabled: boolean): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(HISTORY_ENABLED_KEY, String(enabled));
    }
  } catch (e) {
    // ignore
  }
}

export function getStoredAutoSpeakEnabled(): boolean {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(AUTOSPEAK_ENABLED_KEY);
      if (raw !== null) return raw === 'true';
    }
  } catch (e) {
    // ignore
  }
  return true;
}

export function saveStoredAutoSpeakEnabled(enabled: boolean): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(AUTOSPEAK_ENABLED_KEY, String(enabled));
    }
  } catch (e) {
    // ignore
  }
}

export function getStoredSpeechRate(): number {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(SPEECH_RATE_KEY);
      if (raw !== null) {
        const parsed = parseFloat(raw);
        if (!isNaN(parsed) && parsed > 0) return parsed;
      }
    }
  } catch (e) {
    // ignore
  }
  return 1.0;
}

export function saveStoredSpeechRate(rate: number): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(SPEECH_RATE_KEY, String(rate));
    }
  } catch (e) {
    // ignore
  }
}

export function getStoredAudioMinimized(): boolean {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(AUDIO_MINIMIZED_KEY);
      if (raw !== null) return raw === 'true';
    }
  } catch (e) {
    // ignore
  }
  return false;
}

export function saveStoredAudioMinimized(minimized: boolean): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(AUDIO_MINIMIZED_KEY, String(minimized));
    }
  } catch (e) {
    // ignore
  }
}


