// Dynamically load all project files from the repository using Vite's glob import
const androidFiles = import.meta.glob<string>(
  [
    '/settings.gradle.kts',
    '/build.gradle.kts',
    '/gradle.properties',
    '/gradlew',
    '/gradlew.bat',
    '/LICENSE',
    '/README.md',
    '/.github/workflows/*.yml',
    '/gradle/wrapper/gradle-wrapper.properties',
    '/app/build.gradle.kts',
    '/app/proguard-rules.pro',
    '/app/src/main/AndroidManifest.xml',
    '/app/src/main/java/com/openassist/app/*.kt',
    '/app/src/main/res/**/*.xml',
    '/app/src/main/cpp/*',
    '/assets/mascots/*.svg',
  ],
  { query: '?raw', import: 'default', eager: true }
);

export const PROJECT_FILES: Record<string, string> = {};

for (const [key, value] of Object.entries(androidFiles)) {
  const normalizedKey = key.startsWith('/') ? key.slice(1) : key;
  PROJECT_FILES[normalizedKey] = value;

  // For mascot SVGs, also index by multiple convenience aliases
  if (normalizedKey.startsWith('assets/mascots/') && normalizedKey.endsWith('.svg')) {
    const filename = normalizedKey.replace('assets/mascots/', '');
    const basename = filename.replace('.svg', '');
    PROJECT_FILES[`/${normalizedKey}`] = value;
    PROJECT_FILES[filename] = value;
    PROJECT_FILES[basename] = value;
  }
}
