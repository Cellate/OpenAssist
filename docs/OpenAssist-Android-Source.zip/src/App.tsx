import { useState, useEffect } from 'react';
import {
  Smartphone,
  Palette,
  Layout,
  BookOpen,
  FileCode,
  Download,
  Sparkles,
  Sliders,
  Volume2,
  VolumeX,
  Star,
  Shield,
  Wrench,
  CheckCircle2,
  ArrowRight,
  Eye,
} from 'lucide-react';
import { OpenAssistLogo, LogoStyle, CustomIconItem } from './components/LogoVariations';
import { PhoneSimulator } from './components/PhoneSimulator';
import { BrandStudio } from './components/BrandStudio';
import { MascotPlacementLab, MascotPlacementConfig, MascotEmotion, DEFAULT_PLACEMENT_CONFIG } from './components/MascotPlacementLab';
import { ReadmeViewer } from './components/ReadmeViewer';
import { CodeExplorer } from './components/CodeExplorer';
import { DownloadSection } from './components/DownloadSection';
import { LandingHeroShowcase } from './components/LandingHeroShowcase';
import { LogoSwitcherModal } from './components/LogoSwitcherModal';
import { SetupWizardModal } from './components/SetupWizardModal';
import {
  getStoredActiveLogo,
  setStoredActiveLogo,
  getStoredCustomIcons,
  saveCustomIcon,
  deleteStoredCustomIcon
} from './utils/customIcons';
import { mascotAudio } from './utils/mascotAudio';
import { APP_VERSION } from './utils/version';

type AppTab = 'showcase' | 'simulator' | 'studio' | 'placement' | 'readme' | 'code' | 'download';

export default function App() {
  const [activeTab, setActiveTab] = useState<AppTab>('showcase');
  const [isDevMode, setIsDevMode] = useState<boolean>(() => {
    try {
      return localStorage.getItem('openassist_dev_mode') === 'true';
    } catch {
      return false;
    }
  });
  const [currentLogo, setCurrentLogo] = useState<LogoStyle>(getStoredActiveLogo());
  const [customIcons, setCustomIcons] = useState<CustomIconItem[]>(getStoredCustomIcons());
  const [isLogoSwitcherOpen, setIsLogoSwitcherOpen] = useState(false);
  const [isSetupWizardOpen, setIsSetupWizardOpen] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(true);

  // Settings for wizard and simulator
  const [defaultAgent, setDefaultAgent] = useState('gemini');
  const [speechEngine, setSpeechEngine] = useState('system');
  const [isDefaultAssist, setIsDefaultAssist] = useState(true);
  const [enableSpeechBubble, setEnableSpeechBubble] = useState(true);
  const [enableTranslit, setEnableTranslit] = useState(true);

  // Placement Lab State
  const [placementConfig, setPlacementConfig] = useState<MascotPlacementConfig>(DEFAULT_PLACEMENT_CONFIG);
  const [activeEmotion, setActiveEmotion] = useState<MascotEmotion>('idle');

  useEffect(() => {
    mascotAudio.enabled = audioEnabled;
  }, [audioEnabled]);

  const handleSelectLogo = (style: LogoStyle) => {
    setCurrentLogo(style);
    setStoredActiveLogo(style);
    mascotAudio.playChirp();
  };

  const handleAddCustomIcon = (icon: CustomIconItem) => {
    const updated = saveCustomIcon(icon);
    setCustomIcons(updated);
    handleSelectLogo(`custom:${icon.id}` as LogoStyle);
  };

  const handleDeleteCustomIcon = (id: string) => {
    const updated = deleteStoredCustomIcon(id);
    setCustomIcons(updated);
    if (currentLogo === `custom:${id}`) {
      handleSelectLogo('owl-orbital');
    }
  };

  const toggleAudio = () => {
    const next = !audioEnabled;
    setAudioEnabled(next);
    mascotAudio.enabled = next;
    if (next) mascotAudio.playBoop();
  };

  const toggleDevMode = () => {
    const next = !isDevMode;
    setIsDevMode(next);
    try {
      localStorage.setItem('openassist_dev_mode', String(next));
    } catch {}
    if (next) mascotAudio.playSuccess();
    else mascotAudio.playBoop();
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Developer Mode Active Notice Strip */}
      {isDevMode && (
        <div className="bg-amber-950/70 border-b border-amber-500/30 py-1.5 px-4 text-xs text-amber-200/90 flex flex-wrap items-center justify-between gap-2 z-50">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span className="font-semibold text-amber-300">Developer Engineering Lab Active</span>
            <span className="text-amber-400/60 hidden sm:inline">•</span>
            <span className="text-amber-200/80 hidden sm:inline">Internal APK development, Brand Studio (27 mascots), Placement Lab &amp; Code Explorer</span>
          </div>
          <button
            type="button"
            onClick={toggleDevMode}
            className="flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/30 text-[11px] font-bold cursor-pointer transition-colors"
          >
            <Eye className="w-3 h-3" />
            <span>Switch to Public Visitor View</span>
          </button>
        </div>
      )}

      {/* Top App Navigation Bar */}
      <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Brand Logo & Title */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  mascotAudio.playTap();
                  setIsLogoSwitcherOpen(true);
                }}
                className="group relative flex items-center justify-center p-1 rounded-xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/30 hover:border-indigo-400/60 hover:scale-105 transition-all cursor-pointer shadow-lg shadow-indigo-950/50"
                title="Click to Switch OpenAssist Mascot"
              >
                <OpenAssistLogo
                  style={currentLogo}
                  size={36}
                  customIcons={customIcons}
                  className="transition-transform group-hover:scale-110"
                />
                <span className="absolute -bottom-1 -right-1 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
              </button>

              <div>
                <div className="flex items-center gap-2">
                  <h1 className="font-bold text-lg text-white tracking-tight flex items-center gap-1.5">
                    OpenAssist
                    <span className="text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                      {APP_VERSION.displayName} Native
                    </span>
                  </h1>
                </div>
                <p className="text-xs text-slate-400 hidden sm:block">
                  Circle to Search &amp; Sovereign Voice AI for Any Android
                </p>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Mascot Switcher Pill */}
              <button
                type="button"
                onClick={() => {
                  mascotAudio.playTap();
                  setIsLogoSwitcherOpen(true);
                }}
                className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-slate-700 hover:border-indigo-500/50 transition-all cursor-pointer shadow-sm"
                title="Choose Active Mascot Avatar"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span className="hidden md:inline">Mascot:</span>
                <span className="text-indigo-300 font-semibold truncate max-w-[90px]">
                  {currentLogo.replace('custom:', 'Custom ')}
                </span>
              </button>

              {/* Sound Toggle */}
              <button
                type="button"
                onClick={toggleAudio}
                className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-all cursor-pointer"
                title={audioEnabled ? 'Mute Mascot Audio' : 'Enable Mascot Audio'}
              >
                {audioEnabled ? (
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                ) : (
                  <VolumeX className="w-4 h-4 text-slate-500" />
                )}
              </button>

              {/* Primary Direct Download Button (Always Visible) */}
              <a
                href="https://github.com/Cellate/OpenAssist/releases/latest"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 text-xs font-bold rounded-lg bg-gradient-to-r from-emerald-500 via-emerald-400 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 shadow-md shadow-emerald-500/25 hover:shadow-emerald-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 stroke-[2.5]" />
                <span className="hidden sm:inline">Download APK</span>
                <span className="sm:hidden">APK</span>
                <span className="text-[10px] px-1.5 py-0.2 bg-slate-950/20 text-slate-950 rounded-full font-mono font-black">5.6 MB</span>
              </a>

              {/* Developer Mode Switch */}
              <button
                type="button"
                onClick={toggleDevMode}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-lg border transition-all cursor-pointer ${
                  isDevMode
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-sm'
                    : 'bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border-slate-700/60'
                }`}
                title={isDevMode ? 'Exit Dev Mode (Return to Public Landing View)' : 'Open Developer Tools (Brand Studio, Placement Lab, Code Explorer)'}
              >
                <Wrench className="w-3.5 h-3.5" />
                <span className="hidden md:inline">{isDevMode ? 'Dev Mode' : 'Dev Lab'}</span>
              </button>
            </div>
          </div>

          {/* Public Visitor Quick Navigation vs Developer Tabs */}
          {isDevMode ? (
            /* Developer Tabs Bar */
            <div className="flex items-center space-x-1 sm:space-x-2 border-t border-slate-800/80 overflow-x-auto py-1 scrollbar-none">
              <button
                type="button"
                onClick={() => {
                  mascotAudio.playTap();
                  setActiveTab('showcase');
                }}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'showcase'
                    ? 'bg-gradient-to-r from-emerald-500/20 to-teal-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Star className="w-3.5 h-3.5 text-emerald-400" />
                <span>Showcase &amp; APK</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  mascotAudio.playTap();
                  setActiveTab('simulator');
                }}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'simulator'
                    ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
                <span>Interactive Phone</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  mascotAudio.playTap();
                  setActiveTab('studio');
                }}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'studio'
                    ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Palette className="w-3.5 h-3.5 text-pink-400" />
                <span>Brand Studio (27 Mascots)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  mascotAudio.playTap();
                  setActiveTab('placement');
                }}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'placement'
                    ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Layout className="w-3.5 h-3.5 text-amber-400" />
                <span>Placement Lab (9 Roles)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  mascotAudio.playTap();
                  setActiveTab('readme');
                }}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'readme'
                    ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
                <span>Documentation</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  mascotAudio.playTap();
                  setActiveTab('code');
                }}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'code'
                    ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <FileCode className="w-3.5 h-3.5 text-emerald-400" />
                <span>Code &amp; Fixes</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  mascotAudio.playTap();
                  setActiveTab('download');
                }}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'download'
                    ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Download className="w-3.5 h-3.5 text-purple-400" />
                <span>Download &amp; Build</span>
              </button>
            </div>
          ) : (
            /* Public Conversion Fast-Links Bar */
            <div className="flex items-center space-x-1 sm:space-x-3 border-t border-slate-800/80 overflow-x-auto py-1 scrollbar-none text-xs">
              <a
                href="#hero-showcase"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/60 transition-all font-medium whitespace-nowrap"
              >
                <Star className="w-3.5 h-3.5 text-emerald-400" />
                <span>Overview</span>
              </a>
              <a
                href="#interactive-phone"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/60 transition-all font-medium whitespace-nowrap"
              >
                <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
                <span>Try Live Phone Sandbox</span>
              </a>
              <a
                href="#mascots-gallery"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/60 transition-all font-medium whitespace-nowrap"
              >
                <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                <span>12 Mascots</span>
              </a>
              <a
                href="#security-layers"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/60 transition-all font-medium whitespace-nowrap"
              >
                <Shield className="w-3.5 h-3.5 text-cyan-400" />
                <span>100% Private (0% Telemetry)</span>
              </a>
              <a
                href="#setup-guide"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/60 transition-all font-medium whitespace-nowrap"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                <span>60-Sec Setup</span>
              </a>
              <a
                href="#download-hub"
                className="ml-auto hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-md text-emerald-400 hover:text-emerald-300 font-bold whitespace-nowrap"
              >
                <span>Latest APK (5.6 MB)</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>
          )}
        </div>
      </header>

      {/* Main Viewport Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {(!isDevMode || activeTab === 'showcase') && (
          <LandingHeroShowcase
            currentLogo={currentLogo}
            customIcons={customIcons}
            onSelectLogo={handleSelectLogo}
            onNavigateToTab={(tab) => {
              mascotAudio.playTap();
              setIsDevMode(true);
              setActiveTab(tab);
            }}
            onOpenSetupWizard={() => {
              mascotAudio.playTap();
              setIsSetupWizardOpen(true);
            }}
            onOpenLogoSwitcher={() => {
              mascotAudio.playTap();
              setIsLogoSwitcherOpen(true);
            }}
          />
        )}

        {isDevMode && activeTab === 'simulator' && (
          <div className="space-y-6">
            <div className="bg-slate-900/60 rounded-2xl border border-slate-800/80 p-4 sm:p-6 shadow-xl">
              <PhoneSimulator
                logoStyle={currentLogo}
                customIcons={customIcons}
                onOpenSetupWizard={() => setIsSetupWizardOpen(true)}
                onOpenLogoSwitcher={() => setIsLogoSwitcherOpen(true)}
                onSelectLogo={handleSelectLogo}
                onOpenCode={() => setActiveTab('code')}
              />
            </div>
          </div>
        )}

        {isDevMode && activeTab === 'studio' && (
          <div className="space-y-6">
            <BrandStudio
              currentLogo={currentLogo}
              onSelectLogo={handleSelectLogo}
              customIcons={customIcons}
              onAddCustomIcon={handleAddCustomIcon}
              onDeleteCustomIcon={handleDeleteCustomIcon}
            />
          </div>
        )}

        {isDevMode && activeTab === 'placement' && (
          <div className="space-y-6">
            <MascotPlacementLab
              config={placementConfig}
              onChangeConfig={setPlacementConfig}
              activeEmotion={activeEmotion}
              onChangeEmotion={setActiveEmotion}
              currentLogo={currentLogo}
              customIcons={customIcons}
              mascotName={currentLogo}
            />
          </div>
        )}

        {isDevMode && activeTab === 'readme' && (
          <div className="space-y-6">
            <ReadmeViewer
              onSwitchTab={(tab) => {
                if (tab === 'simulator') setActiveTab('simulator');
                else if (tab === 'code' || tab === 'fixes') setActiveTab('code');
                else if (tab === 'download') setActiveTab('download');
              }}
            />
          </div>
        )}

        {isDevMode && activeTab === 'code' && (
          <div className="space-y-6">
            <CodeExplorer />
          </div>
        )}

        {isDevMode && activeTab === 'download' && (
          <div className="space-y-6">
            <DownloadSection
              showCicdMascot={placementConfig.cicdBanner}
              logoStyle={currentLogo}
              customIcons={customIcons}
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800/80 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2">
            <OpenAssistLogo style={currentLogo} size={20} customIcons={customIcons} />
            <span className="text-slate-300 font-medium">OpenAssist ({APP_VERSION.displayName})</span>
            <span>•</span>
            <span className="text-emerald-400 font-semibold">5.6 MB Lightweight APK</span>
            <span>•</span>
            <span>GPL-3.0 Licensed</span>
            <span>•</span>
            <span>100% Free &amp; Open-Source</span>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-slate-400">
            <a
              href="https://github.com/Cellate/OpenAssist/releases/latest"
              target="_blank"
              rel="noopener noreferrer"
              className="text-emerald-400 hover:text-emerald-300 font-bold transition-colors"
            >
              Download Latest APK
            </a>
            <a
              href="https://github.com/Cellate/OpenAssist"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-indigo-400 transition-colors"
            >
              GitHub Repository
            </a>
            <button
              type="button"
              onClick={toggleDevMode}
              className="hover:text-amber-400 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Wrench className="w-3 h-3" />
              <span>{isDevMode ? 'Exit Dev Mode' : 'Engineering Lab'}</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Modal: Mascot Selector & Custom Uploader */}
      <LogoSwitcherModal
        isOpen={isLogoSwitcherOpen}
        onClose={() => setIsLogoSwitcherOpen(false)}
        currentLogo={currentLogo}
        onSelectLogo={handleSelectLogo}
        customIcons={customIcons}
        onAddCustomIcon={handleAddCustomIcon}
        onDeleteCustomIcon={handleDeleteCustomIcon}
      />

      {/* Modal: Setup Wizard */}
      <SetupWizardModal
        isOpen={isSetupWizardOpen}
        onClose={() => setIsSetupWizardOpen(false)}
        currentLogo={currentLogo}
        onSelectLogo={handleSelectLogo}
        customIcons={customIcons}
        defaultAgent={defaultAgent}
        onSelectAgent={setDefaultAgent}
        speechEngine={speechEngine}
        onSelectSpeechEngine={setSpeechEngine}
        isDefaultAssist={isDefaultAssist}
        onToggleDefaultAssist={setIsDefaultAssist}
        enableSpeechBubble={enableSpeechBubble}
        onToggleSpeechBubble={setEnableSpeechBubble}
        enableTranslit={enableTranslit}
        onToggleTranslit={setEnableTranslit}
      />
    </div>
  );
}
