import { LogoStyle, CustomIconItem } from '../components/LogoVariations';

const ACTIVE_LOGO_KEY = 'openassist_active_logo';
const CUSTOM_ICONS_KEY = 'openassist_custom_icons';

export const DEFAULT_LOGO: LogoStyle = 'owl-orbital'; // Ozzy is the flagship default!

export function getStoredActiveLogo(): LogoStyle {
  try {
    const val = localStorage.getItem(ACTIVE_LOGO_KEY);
    if (val && val.trim()) {
      if (val === 'owl') return 'owl-orbital';
      return val as LogoStyle;
    }
  } catch (e) {
    console.error('Error reading active logo from localStorage:', e);
  }
  return DEFAULT_LOGO;
}

export function setStoredActiveLogo(style: LogoStyle): void {
  try {
    localStorage.setItem(ACTIVE_LOGO_KEY, style);
  } catch (e) {
    console.error('Error saving active logo to localStorage:', e);
  }
}

export function getStoredCustomIcons(): CustomIconItem[] {
  try {
    const raw = localStorage.getItem(CUSTOM_ICONS_KEY);
    if (raw) {
      return JSON.parse(raw) as CustomIconItem[];
    }
  } catch (e) {
    console.error('Error reading custom icons from localStorage:', e);
  }
  return [];
}

export function saveCustomIcon(icon: CustomIconItem): CustomIconItem[] {
  try {
    const current = getStoredCustomIcons();
    const updated = [icon, ...current.filter((item) => item.id !== icon.id)];
    localStorage.setItem(CUSTOM_ICONS_KEY, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error('Error saving custom icon to localStorage:', e);
    return getStoredCustomIcons();
  }
}

export function deleteStoredCustomIcon(id: string): CustomIconItem[] {
  try {
    const current = getStoredCustomIcons();
    const updated = current.filter((item) => item.id !== id);
    localStorage.setItem(CUSTOM_ICONS_KEY, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error('Error deleting custom icon from localStorage:', e);
    return getStoredCustomIcons();
  }
}

export async function processIconFile(file: File): Promise<{
  dataUrl: string;
  isSvg: boolean;
  svgText?: string;
  name: string;
  fileType: string;
}> {
  const isSvg = file.type === 'image/svg+xml' || file.name.toLowerCase().endsWith('.svg');
  const baseName = file.name.replace(/\.[^/.]+$/, '').trim() || 'Custom Icon';

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read file'));

    if (isSvg) {
      reader.onload = () => {
        const text = reader.result as string;
        const dataUrl = `data:image/svg+xml;utf8,\${encodeURIComponent(text)}`;
        resolve({
          dataUrl,
          isSvg: true,
          svgText: text,
          name: baseName,
          fileType: 'image/svg+xml',
        });
      };
      reader.readAsText(file);
    } else {
      reader.onload = () => {
        const dataUrl = reader.result as string;
        resolve({
          dataUrl,
          isSvg: false,
          name: baseName,
          fileType: file.type || 'image/png',
        });
      };
      reader.readAsDataURL(file);
    }
  });
}
