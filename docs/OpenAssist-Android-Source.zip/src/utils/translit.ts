/**
 * Port of OpenAssist Translit.kt for live browser Hindi-to-Hinglish transliteration.
 */
const devanagariToLatin: Record<string, string> = {
  "अ": "a", "आ": "aa", "इ": "i", "ई": "ee", "उ": "u", "ऊ": "oo",
  "ऋ": "ri", "ए": "e", "ऐ": "ai", "ओ": "o", "औ": "au",
  "क": "k", "ख": "kh", "ग": "g", "घ": "gh", "ङ": "ng",
  "च": "ch", "छ": "chh", "ज": "j", "झ": "jh", "ञ": "ny",
  "ट": "t", "ठ": "th", "ड": "d", "ढ": "dh", "ण": "n",
  "त": "t", "थ": "th", "द": "d", "ध": "dh", "न": "n",
  "प": "p", "फ": "f", "ब": "b", "भ": "bh", "म": "m",
  "य": "y", "र": "r", "ल": "l", "व": "v", "श": "sh",
  "ष": "sh", "स": "s", "ह": "h",
  "ा": "aa", "ि": "i", "ी": "ee", "ु": "u", "ू": "oo",
  "ृ": "ri", "े": "e", "ै": "ai", "ो": "o", "ौ": "au",
  "ं": "n", "ः": "h", "्": ""
};

export function isAlreadyLatin(text: string): boolean {
  const letters = text.replace(/[^a-zA-Z\u0900-\u097F]/g, '');
  if (!letters) return true;
  const latinCount = (letters.match(/[a-zA-Z]/g) || []).length;
  return latinCount / letters.length > 0.6;
}

export function toHinglish(hindi: string): string {
  if (isAlreadyLatin(hindi)) return hindi;
  let result = "";
  for (let i = 0; i < hindi.length; i++) {
    const ch = hindi[i];
    result += devanagariToLatin[ch] ?? ch;
  }
  return result;
}
