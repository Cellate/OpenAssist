import versionData from '../../assets/version.json';

export interface AppVersionInfo {
  version: string;
  versionCode: number;
  versionTag: string;
  displayName: string;
  channel: string;
  releaseDate: string;
  githubRepo: string;
  buildPackage: string;
  apkName: string;
  apkSize?: string;
  minSdkVersion: number;
  targetSdkVersion: number;
}

export const APP_VERSION: AppVersionInfo = versionData as AppVersionInfo;

/**
 * Normalizes and extracts numeric semantic version parts from release strings
 * Handles:
 *  - "v.1.63.0" -> [1, 63, 0]
 *  - "v1.63.0"  -> [1, 63, 0]
 *  - "1.63.0"   -> [1, 63, 0]
 *  - "v1.63"    -> [1, 63, 0]
 */
export function parseSemver(tagOrVersion: string): number[] {
  if (!tagOrVersion) return [0, 0, 0];
  // Remove leading v., V., v, V and spaces
  const cleaned = tagOrVersion
    .trim()
    .replace(/^v\.?/i, '')
    .trim();

  // Extract numeric dotted parts
  const parts = cleaned.split('.').map(p => {
    const num = parseInt(p.replace(/\D.*$/, ''), 10);
    return isNaN(num) ? 0 : num;
  });

  while (parts.length < 3) {
    parts.push(0);
  }
  return parts;
}

/**
 * Returns:
 *   1 if v1 is strictly greater than v2
 *  -1 if v1 is strictly smaller than v2
 *   0 if equal
 */
export function compareSemver(v1: string, v2: string): number {
  const p1 = parseSemver(v1);
  const p2 = parseSemver(v2);
  const len = Math.max(p1.length, p2.length);

  for (let i = 0; i < len; i++) {
    const n1 = p1[i] ?? 0;
    const n2 = p2[i] ?? 0;
    if (n1 > n2) return 1;
    if (n1 < n2) return -1;
  }
  return 0;
}

/**
 * Returns true if remoteTag is strictly newer than localVersion
 */
export function isNewerVersion(
  remoteTag: string,
  localVersion: string = APP_VERSION.version
): boolean {
  return compareSemver(remoteTag, localVersion) > 0;
}
