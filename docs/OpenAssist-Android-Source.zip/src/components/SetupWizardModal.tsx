import React, { useState, useEffect } from 'react';
import {
  X, Check, Sparkles, ArrowRight, ArrowLeft, ShieldCheck,
  RefreshCw, CheckCircle2, ArrowUp, ArrowDown, Plus, Trash2,
  ExternalLink, Globe, Lock, Search, Sliders, Volume2
} from 'lucide-react';
import { OpenAssistLogo, LogoStyle, CustomIconItem } from './LogoVariations';
import {
  AssistService,
  ServiceCategory,
  CATEGORY_LABELS,
  getStoredServices,
  saveStoredServices,
  getStoredHistoryEnabled,
  saveStoredHistoryEnabled,
  getStoredAutoSpeakEnabled,
  saveStoredAutoSpeakEnabled,
  getStoredSpeechRate,
  saveStoredSpeechRate
} from '../data/servicesCatalog';
import { APP_VERSION } from '../utils/version';

interface SetupWizardModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLogo: LogoStyle;
  onSelectLogo: (style: LogoStyle) => void;
  customIcons?: CustomIconItem[];
  defaultAgent: string;
  onSelectAgent: (agentId: string) => void;
  speechEngine: string;
  onSelectSpeechEngine: (engineId: string) => void;
  isDefaultAssist: boolean;
  onToggleDefaultAssist: (enabled: boolean) => void;
  enableSpeechBubble: boolean;
  onToggleSpeechBubble: (enabled: boolean) => void;
  enableTranslit: boolean;
  onToggleTranslit: (enabled: boolean) => void;
  isDarkMode?: boolean;
}

export const SetupWizardModal: React.FC<SetupWizardModalProps> = ({
  isOpen,
  onClose,
  currentLogo,
  onSelectLogo,
  customIcons = [],
  defaultAgent,
  onSelectAgent,
  speechEngine,
  onSelectSpeechEngine,
  isDefaultAssist,
  onToggleDefaultAssist,
  enableSpeechBubble,
  onToggleSpeechBubble,
  enableTranslit,
  onToggleTranslit,
  isDarkMode: propDarkMode,
}) => {
  const [step, setStep] = useState<number>(1);
  const [mascotToastMessage, setMascotToastMessage] = useState<string | null>(null);
  const [isRestarting, setIsRestarting] = useState<boolean>(false);
  const totalSteps = 6;
  const isDark = propDarkMode ?? (typeof window !== 'undefined' && window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)').matches : true);

  // Preferred Chips state
  const [services, setServices] = useState<AssistService[]>(() => getStoredServices());
  const [activeChipCategory, setActiveChipCategory] = useState<ServiceCategory>('all');
  const [showAddWebsiteForm, setShowAddWebsiteForm] = useState(false);
  const [newSiteName, setNewSiteName] = useState('');
  const [newSiteUrl, setNewSiteUrl] = useState('');
  const [newSiteCategory, setNewSiteCategory] = useState<ServiceCategory>('search');
  const [newSiteOpenInApp, setNewSiteOpenInApp] = useState(false);

  // Local History privacy state
  const [isHistoryEnabled, setIsHistoryEnabled] = useState<boolean>(() => getStoredHistoryEnabled());
  const [isAutoSpeakEnabled, setIsAutoSpeakEnabled] = useState<boolean>(() => getStoredAutoSpeakEnabled());
  const [speechRate, setSpeechRate] = useState<number>(() => getStoredSpeechRate());

  useEffect(() => {
    if (isOpen) {
      setServices(getStoredServices());
      setIsHistoryEnabled(getStoredHistoryEnabled());
      setIsAutoSpeakEnabled(getStoredAutoSpeakEnabled());
      setSpeechRate(getStoredSpeechRate());
    }
  }, [isOpen]);

  const handleToggleService = (id: string) => {
    setServices((prev) => {
      const updated = prev.map((s) => (s.id === id ? { ...s, isEnabled: !s.isEnabled } : s));
      saveStoredServices(updated);
      return updated;
    });
  };

  const handleToggleOpenInApp = (id: string) => {
    setServices((prev) => {
      const updated = prev.map((s) => (s.id === id ? { ...s, openInApp: !s.openInApp } : s));
      saveStoredServices(updated);
      return updated;
    });
  };

  const handleMoveService = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= services.length) return;
    setServices((prev) => {
      const next = [...prev];
      const temp = next[index];
      next[index] = next[targetIndex];
      next[targetIndex] = temp;
      saveStoredServices(next);
      return next;
    });
  };

  const handleAddCustomSite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSiteName.trim() || !newSiteUrl.trim()) return;

    let norm = newSiteUrl.trim();
    if (!norm.startsWith('http://') && !norm.startsWith('https://')) {
      norm = 'https://' + norm;
    }
    if (!norm.includes('{q}') && !norm.includes('?')) {
      norm = norm + '/search?q={q}';
    }

    const newService: AssistService = {
      id: 'custom_' + Date.now(),
      name: newSiteName.trim(),
      url: norm,
      category: newSiteCategory === 'all' ? 'custom' : newSiteCategory,
      isCustom: true,
      isEnabled: true,
      openInApp: newSiteOpenInApp,
      searchUrlTemplate: norm.includes('{q}') ? norm : `${norm}?q={q}`,
    };

    setServices((prev) => {
      const updated = [newService, ...prev];
      saveStoredServices(updated);
      return updated;
    });

    setNewSiteName('');
    setNewSiteUrl('');
    setShowAddWebsiteForm(false);
  };

  const handleDeleteService = (id: string) => {
    setServices((prev) => {
      const updated = prev.filter((s) => s.id !== id);
      saveStoredServices(updated);
      return updated;
    });
  };

  const handleToggleHistory = (val: boolean) => {
    setIsHistoryEnabled(val);
    saveStoredHistoryEnabled(val);
  };

  const handleToggleAutoSpeak = (val: boolean) => {
    setIsAutoSpeakEnabled(val);
    saveStoredAutoSpeakEnabled(val);
  };

  const handleCycleSpeechRate = () => {
    const rates = [1.0, 1.25, 1.5, 0.8];
    const nextIdx = (rates.indexOf(speechRate) + 1) % rates.length;
    const nextRate = rates[nextIdx >= 0 ? nextIdx : 0];
    setSpeechRate(nextRate);
    saveStoredSpeechRate(nextRate);
  };

  const getWholesomeGreeting = (mascot: LogoStyle): string => {
    const s = mascot.toLowerCase();
    if (s.startsWith('owl')) {
      return "Welcome home, friend! Ready to explore something wonderful today? I'm right here by your side whenever curiosity strikes! ✨";
    }
    if (s.startsWith('fox')) {
      return "Nexus synthesis online! I'm so thrilled to be your companion. What brilliant questions are we tackling today? 🦊";
    }
    if (s === 'bat') {
      return "Sonic radar locked on! I'm tuned to your wavelength, friend. Ready to listen and uncover insights anytime! 🦇";
    }
    if (s === 'otter') {
      return "Splashing into the sea of knowledge! Having you here makes today amazing. Let's dive deep and create! 🦦";
    }
    if (s === 'chameleon') {
      return "Rainbow vision active! I adapt to whatever you need, seamlessly. So happy to be your partner! 🦎";
    }
    if (s === 'tanuki') {
      return "Offline, loyal, and ready to roll! Your questions stay 100% private with me. Let's conquer the day! 🦝";
    }
    return "Welcome back, friend! I'm overjoyed to be your companion. Let's discover something wonderful together today! ✨";
  };

  const c = {
    modal: isDark ? 'bg-[#14161F] border-[#2B2E3F] text-white' : 'bg-white border-slate-300 text-slate-900 shadow-2xl',
    header: isDark ? 'bg-[#181B26] border-white/10 text-white' : 'bg-slate-100 border-slate-200 text-slate-900',
    headerTitle: isDark ? 'text-white' : 'text-slate-900 font-bold',
    subText: isDark ? 'text-zinc-400' : 'text-slate-600',
    descText: isDark ? 'text-zinc-300' : 'text-slate-700 font-medium',
    progressBg: isDark ? 'bg-[#1A1D28]' : 'bg-slate-200',
    banner: isDark ? 'bg-gradient-to-br from-indigo-950/60 to-[#191C28] border-indigo-500/30' : 'bg-slate-50 border-slate-200 shadow-xs',
    cardBox: isDark ? 'bg-[#171924] border-white/10' : 'bg-slate-50 border-slate-200 shadow-xs',
    unselectedCard: isDark ? 'bg-[#161822] border-white/5 hover:border-white/10 text-zinc-300' : 'bg-white border-slate-200 hover:border-slate-300 text-slate-900 shadow-xs',
    selectedCard: isDark ? 'bg-[#1E2235] border-indigo-500 shadow-md shadow-indigo-500/10 text-white' : 'bg-blue-50 border-blue-600 text-blue-950 shadow-xs ring-1 ring-blue-600 font-semibold',
    footer: isDark ? 'bg-[#161822] border-white/10' : 'bg-slate-100 border-slate-200',
    prevBtn: isDark ? 'text-zinc-400 hover:text-white' : 'text-slate-700 hover:text-slate-950 hover:bg-slate-200',
    logoTheme: (isDark ? 'dark' : 'light') as 'dark' | 'light',
  };

  const [isBenchmarking, setIsBenchmarking] = useState(false);
  const [benchmarkResults, setBenchmarkResults] = useState<{
    whisper: number | null;
    futo: number | null;
    google: number | null;
  }>({
    whisper: 185,
    futo: 115,
    google: 340,
  });

  if (!isOpen) return null;

  const runBenchmark = () => {
    setIsBenchmarking(true);
    setBenchmarkResults({ whisper: null, futo: null, google: null });
    setTimeout(() => {
      setBenchmarkResults({
        whisper: Math.floor(170 + Math.random() * 35),
        futo: Math.floor(105 + Math.random() * 25),
        google: Math.floor(310 + Math.random() * 60),
      });
      setIsBenchmarking(false);
    }, 900);
  };

  const MASCOT_PRESETS: { id: LogoStyle; name: string; desc: string }[] = [
    { id: 'owl-orbital', name: 'Ozzy', desc: 'Chubby AI Sentinel with Circle-to-Search orbit & cyber goggles (Default)' },
    { id: 'owl', name: 'Ozzy Classic', desc: 'Classic Night-Vision AI Sentinel with twin visor lenses' },
    { id: 'fox', name: 'Pip Nexus', desc: 'Curled search lasso orbit with connected spectacles' },
    { id: 'bat', name: 'Echo the Sonic Bat', desc: 'Ultrasonic acoustic scout with radar waves' },
    { id: 'otter', name: 'Nova the Star Otter', desc: 'Deep-query navigator holding an AI pearl gem' },
    { id: 'chameleon', name: 'Pico the Chameleon', desc: 'Dual-focal independent multi-modal vision' },
    { id: 'tanuki', name: 'Taro the Tanuki', desc: 'On-device transformer with tactile leaf emblem' },
  ];

  const SPEECH_ENGINES = [
    {
      id: 'local_model',
      name: 'Local Offline Whisper (GGUF)',
      badge: '100% Offline & Private',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
      latency: benchmarkResults.whisper ? `${benchmarkResults.whisper} ms` : 'Testing...',
      benefits: 'Runs completely on-device via JNI/C++ whisper.cpp. Zero audio sent over network. Works in airplane mode.',
      drawbacks: 'Requires ~40MB one-time tiny.en model download. Slightly higher battery usage during continuous dictation.',
    },
    {
      id: 'futo_voice_input',
      name: 'FUTO Voice Input (On-Device Neural)',
      badge: 'Fastest On-Device',
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
      latency: benchmarkResults.futo ? `${benchmarkResults.futo} ms` : 'Testing...',
      benefits: 'Optimized neural Whisper engine. Extremely low latency. Open-source copyleft architecture.',
      drawbacks: 'Requires the free FUTO Voice Input app installed on your device.',
    },
    {
      id: 'google_tts',
      name: 'Google Voice Typing / Cloud Speech',
      badge: 'Cloud Dependent',
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
      latency: benchmarkResults.google ? `${benchmarkResults.google} ms` : 'Testing...',
      benefits: 'Instant recognition without downloading local model files. Native on stock Android.',
      drawbacks: 'Transmits voice data to Google servers. Requires active internet. Unavailable on de-Googled LineageOS without microG.',
    },
  ];

  const filteredServices = services.filter((s) => {
    if (activeChipCategory === 'all') return true;
    return s.category === activeChipCategory;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200 text-left font-sans">
      <div className={`${c.modal} rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden`}>
        <div className={`px-5 py-4 border-b flex items-center justify-between ${c.header}`}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center p-1 shadow-md">
              <OpenAssistLogo style={currentLogo} size={28} theme={c.logoTheme} customIcons={customIcons} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className={`text-sm font-bold tracking-tight ${c.headerTitle}`}>OpenAssist Setup &amp; Onboarding</h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 dark:text-indigo-300 text-indigo-700 border border-indigo-500/30 font-semibold">
                  Step {step} of {totalSteps}
                </span>
              </div>
              <p className={`text-[11px] ${c.subText}`}>Configure your customizable digital assistant</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-full transition ${c.subText} hover:opacity-100`}
            title="Close setup wizard"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className={`w-full h-1 ${c.progressBg}`}>
          <div
            className="h-full bg-gradient-to-r from-indigo-500 to-[#8AB4F8] transition-all duration-300"
            style={{ width: `${(step / totalSteps) * 100}%` }}
          />
        </div>

        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {/* STEP 1: MASCOT SELECTION */}
          {step === 1 && (
            <div className="space-y-4">
              <div className={`p-4 rounded-2xl border flex items-start gap-3.5 shadow-md ${c.banner}`}>
                <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center p-1 shrink-0">
                  <OpenAssistLogo style={currentLogo} size={36} theme={c.logoTheme} customIcons={customIcons} />
                </div>
                <div className="space-y-1 text-xs">
                  <p className={`font-bold text-sm ${c.headerTitle}`}>Welcome to OpenAssist {APP_VERSION.displayName}! 🎉</p>
                  <p className={`${c.descText} leading-relaxed`}>
                    Your universal screen search &amp; digital assistant. Circle to Search, voice dictation, and 35+ customizable search &amp; AI services right on your phone without tracking.
                  </p>
                  <p className="text-indigo-600 dark:text-indigo-300 text-[11px] font-semibold pt-0.5">
                    Choose your companion mascot below. The app launcher icon will update to your chosen companion after restarting.
                  </p>
                </div>
              </div>

              {mascotToastMessage && (
                <div className="p-3 rounded-xl border bg-indigo-500/10 border-indigo-500/30 text-indigo-300 dark:text-indigo-200 text-xs flex items-center gap-2 animate-in fade-in duration-150">
                  <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>{mascotToastMessage}</span>
                </div>
              )}

              <div className="space-y-2">
                <label className={`text-xs font-semibold block ${c.headerTitle}`}>Select Active Mascot Companion:</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {MASCOT_PRESETS.map((m) => {
                    const isSelected = currentLogo === m.id;
                    return (
                      <div
                        key={m.id}
                        onClick={() => {
                          onSelectLogo(m.id);
                          setMascotToastMessage(`${m.name} chosen! Your app icon will change to this mascot upon restarting. You can safely proceed.`);
                        }}
                        className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center gap-3 select-none ${
                          isSelected ? c.selectedCard : c.unselectedCard
                        }`}
                      >
                        <div className="w-10 h-10 rounded-xl bg-black/10 dark:bg-black/40 border border-black/10 dark:border-white/10 flex items-center justify-center p-1 shrink-0">
                          <OpenAssistLogo style={m.id} size={28} theme={c.logoTheme} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className={`text-xs font-bold truncate ${isSelected ? (isDark ? 'text-white' : 'text-blue-900') : (isDark ? 'text-zinc-300' : 'text-slate-900')}`}>
                            {m.name}
                          </p>
                          <p className={`text-[10px] line-clamp-1 ${c.subText}`}>{m.desc}</p>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: DEFAULT ASSISTANT APP */}
          {step === 2 && (
            <div className="space-y-4">
              <div className={`p-4 rounded-2xl border flex items-start gap-3.5 shadow-md ${c.banner}`}>
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center p-1 shrink-0">
                  <OpenAssistLogo style={currentLogo} size={28} theme={c.logoTheme} customIcons={customIcons} />
                </div>
                <div className="space-y-1 text-xs">
                  <p className={`font-bold text-sm ${c.headerTitle}`}>Set OpenAssist as Default Assistant</p>
                  <p className={`${c.descText} leading-relaxed`}>
                    Setting OpenAssist as your device's default digital assistant allows Android to trigger Circle to Search when you long-press the Home button, swipe diagonally from the bottom corner, or hold the power key.
                  </p>
                </div>
              </div>

              <div className={`p-4 rounded-2xl border space-y-3 ${c.cardBox}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <p className={`text-xs font-bold ${c.headerTitle}`}>Default Assist &amp; Voice Input App</p>
                      <p className={`text-[10px] ${c.subText}`}>Settings &gt; Apps &gt; Default apps &gt; Digital assistant</p>
                    </div>
                  </div>
                  <button
                    onClick={() => onToggleDefaultAssist(!isDefaultAssist)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow ${
                      isDefaultAssist
                        ? 'bg-emerald-500 text-emerald-950'
                        : 'bg-slate-200 dark:bg-[#252838] text-slate-800 dark:text-zinc-300 hover:opacity-90 border border-black/10 dark:border-white/10'
                    }`}
                  >
                    {isDefaultAssist ? <Check className="w-3.5 h-3.5" /> : null}
                    <span>{isDefaultAssist ? 'Enabled' : 'Click to Set'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: PREFERRED CHIPS SELECTION & CUSTOMIZATION */}
          {step === 3 && (
            <div className="space-y-4">
              <div className={`p-4 rounded-2xl border flex items-start gap-3.5 shadow-md ${c.banner}`}>
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center p-1 shrink-0">
                  <Sliders className="w-5 h-5 text-indigo-400" />
                </div>
                <div className="space-y-1 text-xs">
                  <p className={`font-bold text-sm ${c.headerTitle}`}>Select Your Preferred Search &amp; AI Chips</p>
                  <p className={`${c.descText} leading-relaxed`}>
                    Choose which services appear in your top search bar. You can <strong>enable or disable</strong> chips, <strong>reorder</strong> their sequence with up/down arrows, toggle <strong>Open in App</strong> (to launch native YouTube, Reddit, Instagram, etc.), or easily add any website.
                  </p>
                </div>
              </div>

              {/* Category Filter Pills & Add Button */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap gap-1.5 text-xs">
                  {(['all', 'ai', 'search', 'social', 'productivity'] as ServiceCategory[]).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setActiveChipCategory(cat)}
                      className={`px-2.5 py-1 rounded-full text-[11px] font-semibold transition ${
                        activeChipCategory === cat
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : isDark
                          ? 'bg-zinc-800/80 text-zinc-300 hover:bg-zinc-700'
                          : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                      }`}
                    >
                      {CATEGORY_LABELS[cat]}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => setShowAddWebsiteForm(!showAddWebsiteForm)}
                  className="px-3 py-1 rounded-xl text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 hover:bg-indigo-500/30 flex items-center gap-1 transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Website / App</span>
                </button>
              </div>

              {/* Add Website Form */}
              {showAddWebsiteForm && (
                <form
                  onSubmit={handleAddCustomSite}
                  className={`p-3.5 rounded-2xl border space-y-3 animate-in fade-in duration-150 ${c.cardBox}`}
                >
                  <p className={`text-xs font-bold ${c.headerTitle}`}>Add Any Website or App</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="text-[10px] text-zinc-400 block mb-1">Service / Site Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Hacker News or Pinterest"
                        value={newSiteName}
                        onChange={(e) => setNewSiteName(e.target.value)}
                        className={`w-full px-2.5 py-1.5 rounded-xl border text-xs ${
                          isDark ? 'bg-zinc-900 border-zinc-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                        }`}
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400 block mb-1">Search URL Template ({'{q}'} will be replaced)</label>
                      <input
                        type="text"
                        placeholder="https://news.ycombinator.com/item?id={q}"
                        value={newSiteUrl}
                        onChange={(e) => setNewSiteUrl(e.target.value)}
                        className={`w-full px-2.5 py-1.5 rounded-xl border text-xs ${
                          isDark ? 'bg-zinc-900 border-zinc-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                        }`}
                      />
                    </div>
                  </div>
                  <div className="flex items-center justify-between pt-1">
                    <label className="flex items-center gap-2 text-xs text-zinc-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={newSiteOpenInApp}
                        onChange={(e) => setNewSiteOpenInApp(e.target.checked)}
                        className="rounded accent-indigo-600"
                      />
                      <span>Open in native app if installed</span>
                    </label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setShowAddWebsiteForm(false)}
                        className="px-2.5 py-1 rounded-lg text-xs text-zinc-400 hover:text-white"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-3.5 py-1 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white"
                      >
                        Add Chip
                      </button>
                    </div>
                  </div>
                </form>
              )}

              {/* Chips List with Reorder, Enable/Disable, OpenInApp */}
              <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
                {filteredServices.map((service, index) => {
                  const actualIndex = services.findIndex((s) => s.id === service.id);
                  return (
                    <div
                      key={service.id}
                      className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 text-xs transition ${
                        service.isEnabled ? c.cardBox : 'opacity-50 ' + c.cardBox
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {/* Checkbox */}
                        <input
                          type="checkbox"
                          checked={service.isEnabled}
                          onChange={() => handleToggleService(service.id)}
                          className="w-4 h-4 rounded accent-indigo-600 cursor-pointer shrink-0"
                          title="Enable / Disable Chip"
                        />

                        {/* Name and category */}
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className={`font-bold truncate ${c.headerTitle}`}>{service.name}</span>
                            {service.isCustom && (
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-semibold">
                                Custom
                              </span>
                            )}
                          </div>
                          <p className={`text-[10px] truncate max-w-[200px] sm:max-w-xs ${c.subText}`}>
                            {service.url}
                          </p>
                        </div>
                      </div>

                      {/* Right side controls: Open in app toggle, Reorder, Delete */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        {/* Open in App Toggle */}
                        <button
                          type="button"
                          onClick={() => handleToggleOpenInApp(service.id)}
                          title={service.openInApp ? 'Opens in native app if installed' : 'Opens in in-app WebView'}
                          className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold border flex items-center gap-1 transition ${
                            service.openInApp
                              ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                              : isDark
                              ? 'bg-zinc-800 border-zinc-700 text-zinc-400'
                              : 'bg-slate-200 border-slate-300 text-slate-600'
                          }`}
                        >
                          <ExternalLink className="w-2.5 h-2.5" />
                          <span>{service.openInApp ? 'App ↗' : 'Web'}</span>
                        </button>

                        {/* Reorder Up */}
                        <button
                          type="button"
                          disabled={actualIndex === 0}
                          onClick={() => handleMoveService(actualIndex, 'up')}
                          className="p-1 rounded-md hover:bg-zinc-700/50 disabled:opacity-20 text-zinc-300 transition"
                          title="Move Up in sequence"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>

                        {/* Reorder Down */}
                        <button
                          type="button"
                          disabled={actualIndex === services.length - 1}
                          onClick={() => handleMoveService(actualIndex, 'down')}
                          className="p-1 rounded-md hover:bg-zinc-700/50 disabled:opacity-20 text-zinc-300 transition"
                          title="Move Down in sequence"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>

                        {/* Delete Custom */}
                        {service.isCustom && (
                          <button
                            type="button"
                            onClick={() => handleDeleteService(service.id)}
                            className="p-1 rounded-md hover:bg-red-500/20 text-red-400 transition"
                            title="Delete custom website"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 4: SPEECH RECOGNITION BENCHMARK */}
          {step === 4 && (
            <div className="space-y-4">
              <div className={`p-4 rounded-2xl border flex items-start gap-3.5 shadow-md ${c.banner}`}>
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center p-1 shrink-0">
                  <OpenAssistLogo style={currentLogo} size={28} theme={c.logoTheme} customIcons={customIcons} />
                </div>
                <div className="space-y-1 text-xs">
                  <p className={`font-bold text-sm ${c.headerTitle}`}>Active Speech Recognition &amp; Latency Benchmark</p>
                  <p className={`${c.descText} leading-relaxed`}>
                    Compare speech engines to choose the best balance of offline privacy, speed, and hardware requirements.
                  </p>
                </div>
              </div>

              <div className={`flex items-center justify-between p-3 rounded-2xl border ${c.cardBox}`}>
                <div className="text-xs">
                  <p className={`font-bold ${c.headerTitle}`}>Live Speed Benchmark</p>
                  <p className={`text-[10px] ${c.subText}`}>Simulate transcription latency on your processor</p>
                </div>
                <button
                  onClick={runBenchmark}
                  disabled={isBenchmarking}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 text-white font-bold text-xs shadow flex items-center gap-1.5 transition active:scale-95 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isBenchmarking ? 'animate-spin' : ''}`} />
                  <span>{isBenchmarking ? 'Testing...' : 'Run Benchmark'}</span>
                </button>
              </div>

              <div className="space-y-2.5">
                {SPEECH_ENGINES.map((engine) => {
                  const isSelected = speechEngine === engine.id;
                  return (
                    <div
                      key={engine.id}
                      onClick={() => onSelectSpeechEngine(engine.id)}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all space-y-2 select-none ${
                        isSelected ? c.selectedCard : c.unselectedCard
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                              isSelected ? 'border-indigo-400 bg-indigo-600 text-white' : 'border-zinc-400 dark:border-zinc-600'
                            }`}
                          >
                            {isSelected && <Check className="w-2.5 h-2.5" />}
                          </div>
                          <span className={`text-xs font-bold ${isSelected ? (isDark ? 'text-white' : 'text-blue-900') : (isDark ? 'text-zinc-200' : 'text-slate-900')}`}>
                            {engine.name}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border font-bold ${engine.badgeColor}`}>
                            {engine.badge}
                          </span>
                          <span className="text-[10px] font-mono text-slate-700 dark:text-zinc-300 bg-black/5 dark:bg-black/40 px-2 py-0.5 rounded-md">
                            {engine.latency}
                          </span>
                        </div>
                      </div>
                      <div className={`text-[11px] space-y-1 pl-6 ${c.descText}`}>
                        <p><strong className="text-emerald-600 dark:text-emerald-400 font-semibold">Benefits:</strong> {engine.benefits}</p>
                        <p className={c.subText}><strong className="text-amber-600 dark:text-amber-400 font-semibold">Drawbacks:</strong> {engine.drawbacks}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 5: 100% ON-DEVICE LOCAL HISTORY & PRIVACY */}
          {step === 5 && (
            <div className="space-y-4">
              <div className={`p-4 rounded-2xl border flex items-start gap-3.5 shadow-md ${c.banner}`}>
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center p-1 shrink-0">
                  <Lock className="w-5 h-5 text-emerald-400" />
                </div>
                <div className="space-y-1 text-xs">
                  <p className={`font-bold text-sm ${c.headerTitle}`}>Local History &amp; Privacy (100% On-Device)</p>
                  <p className={`${c.descText} leading-relaxed`}>
                    OpenAssist never sends your search queries, circled image crops, or browsing sessions to any cloud server. Everything stays strictly in your private device memory.
                  </p>
                </div>
              </div>

              {/* Privacy Disclosure Card */}
              <div className={`p-4 rounded-2xl border space-y-3 ${c.cardBox}`}>
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className={`text-xs font-bold ${c.headerTitle}`}>Enable Local Query History</p>
                    <p className={`text-[10px] ${c.subText}`}>
                      {isHistoryEnabled
                        ? '✅ History is enabled and saved 100% locally on your phone.'
                        : '🚫 History is disabled. Zero queries or links are saved.'}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleToggleHistory(!isHistoryEnabled)}
                    className={`w-12 h-7 rounded-full transition-colors relative p-0.5 shrink-0 ${
                      isHistoryEnabled ? 'bg-emerald-600' : 'bg-zinc-600'
                    }`}
                  >
                    <div
                      className={`w-6 h-6 rounded-full bg-white shadow-md transform transition-transform ${
                        isHistoryEnabled ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                <div className="border-t border-white/5 pt-3 space-y-2 text-xs">
                  <div className="flex items-start gap-2 text-[11px] text-zinc-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>Zero Cloud Tracking:</strong> No telemetry, analytics, or logging ever leaves your phone.</span>
                  </div>
                  <div className="flex items-start gap-2 text-[11px] text-zinc-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>Base Chat URL Isolation:</strong> External document links (like Google Docs) do not overwrite your AI conversation history links.</span>
                  </div>
                  <div className="flex items-start gap-2 text-[11px] text-zinc-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>Full Control:</strong> You can turn this on or off anytime in Settings, or tap to clear all history with one touch.</span>
                  </div>
                </div>
              </div>

              {/* Auto-Read Aloud & Speech Output Card */}
              <div className={`p-4 rounded-2xl border space-y-3 ${c.cardBox}`}>
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5">
                      <Volume2 className="w-4 h-4 text-indigo-400" />
                      <p className={`text-xs font-bold ${c.headerTitle}`}>Auto-Read Aloud Chatbot Responses</p>
                    </div>
                    <p className={`text-[10px] ${c.subText}`}>
                      {isAutoSpeakEnabled
                        ? '✅ Answers are automatically spoken aloud as soon as generation completes.'
                        : '🚫 Speech readout disabled. Only speaks when manually requested.'}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleToggleAutoSpeak(!isAutoSpeakEnabled)}
                    className={`w-12 h-7 rounded-full transition-colors relative p-0.5 shrink-0 ${
                      isAutoSpeakEnabled ? 'bg-indigo-600' : 'bg-zinc-600'
                    }`}
                  >
                    <div
                      className={`w-6 h-6 rounded-full bg-white shadow-md transform transition-transform ${
                        isAutoSpeakEnabled ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                <div className="border-t border-white/5 pt-3 flex items-center justify-between">
                  <div>
                    <p className={`text-[11px] font-bold ${c.headerTitle}`}>Default Playback Speed</p>
                    <p className={`text-[10px] ${c.subText}`}>Hybrid site native audio &amp; on-device Android TTS</p>
                  </div>
                  <button
                    type="button"
                    onClick={handleCycleSpeechRate}
                    className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 hover:bg-indigo-600/30 transition cursor-pointer"
                  >
                    {speechRate}x ▾
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STEP 6: WELCOME & LAUNCH */}
          {step === 6 && (
            <div className="space-y-4">
              {/* Wholesome Mascot Welcome Card */}
              <div className={`p-4 rounded-3xl border flex items-start gap-4 shadow-xl ${
                isDark
                  ? 'bg-gradient-to-br from-indigo-950/80 via-[#161826] to-[#121420] border-indigo-500/40 text-white'
                  : 'bg-gradient-to-br from-blue-50 via-indigo-50/60 to-white border-blue-200 text-slate-900 shadow-md'
              }`}>
                <div className="w-16 h-16 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center p-1.5 shrink-0 shadow-lg">
                  <OpenAssistLogo style={currentLogo} size={48} theme={c.logoTheme} customIcons={customIcons} />
                </div>
                <div className="space-y-1.5 text-xs flex-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-400/20 text-amber-500 dark:text-amber-300 border border-amber-400/30">
                      Welcome Companion
                    </span>
                    <h4 className="font-extrabold text-base tracking-tight">
                      {MASCOT_PRESETS.find(m => m.id === currentLogo)?.name || 'Ozzy'} Welcomes You! 🎉
                    </h4>
                  </div>
                  <p className="text-sm italic font-medium leading-relaxed opacity-95 text-indigo-950 dark:text-indigo-100">
                    "{getWholesomeGreeting(currentLogo)}"
                  </p>
                  <p className="text-[11px] text-zinc-600 dark:text-zinc-300">
                    Your faithful assistant is always present at the top of OpenAssist whenever you trigger Circle to Search.
                  </p>
                </div>
              </div>

              {/* Suggestion Card: Sign in to Gemini / Favorite AI Service */}
              <div className={`p-4 rounded-2xl border space-y-2 ${
                isDark
                  ? 'bg-blue-950/30 border-blue-500/30 text-blue-200'
                  : 'bg-blue-50 border-blue-200 text-blue-950'
              }`}>
                <div className="flex items-center gap-2 font-bold text-xs text-blue-600 dark:text-blue-300">
                  <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>💡 Mascot Pro-Tip: Sign In to Gemini &amp; AI Services</span>
                </div>
                <p className="text-[11px] leading-relaxed text-zinc-700 dark:text-zinc-300">
                  We strongly recommend signing in to your favorite AI assistant — especially <strong>Gemini</strong>. By default, Gemini does not permit attaching circled screenshots or images to questions without signing in to your Google account. Signing in also guarantees your complete conversation history is preserved on that specific chat!
                </p>
              </div>

              {/* App Icon Apply & Restart Option */}
              <div className={`p-4 rounded-2xl border space-y-3 ${c.cardBox}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className={`text-xs font-bold ${c.headerTitle}`}>App Icon Setup</p>
                    <p className={`text-[10px] ${c.subText}`}>
                      Your chosen companion is <strong>{MASCOT_PRESETS.find(m => m.id === currentLogo)?.name || 'Ozzy'}</strong>.
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      setIsRestarting(true);
                      setTimeout(() => {
                        setIsRestarting(false);
                        onClose();
                      }, 1200);
                    }}
                    disabled={isRestarting}
                    className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isRestarting ? 'animate-spin' : ''}`} />
                    <span>{isRestarting ? 'Applying & Restarting...' : 'Restart App to Apply Icon'}</span>
                  </button>
                </div>
                <p className={`text-[10px] leading-relaxed ${c.subText}`}>
                  Restarting the app applies your companion mascot as your home screen launcher icon immediately. You can also safely proceed directly without restarting right now.
                </p>
              </div>

              {/* Behavior switches */}
              <div className="space-y-2">
                <div className={`p-3 rounded-2xl border flex items-center justify-between ${c.cardBox}`}>
                  <div>
                    <p className={`text-xs font-bold ${c.headerTitle}`}>Mascot Speech Bubbles &amp; Tips</p>
                    <p className={`text-[10px] ${c.subText}`}>
                      Mascot displays reactive tips and feedback in overlay.
                    </p>
                  </div>
                  <button
                    onClick={() => onToggleSpeechBubble(!enableSpeechBubble)}
                    className={`w-10 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                      enableSpeechBubble ? 'bg-indigo-600' : 'bg-zinc-400 dark:bg-zinc-700'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                        enableSpeechBubble ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                <div className={`p-3 rounded-2xl border flex items-center justify-between ${c.cardBox}`}>
                  <div>
                    <p className={`text-xs font-bold ${c.headerTitle}`}>Hindi to Hinglish Transliteration</p>
                    <p className={`text-[10px] ${c.subText}`}>
                      Auto-converts spoken or typed Devanagari Hindi into Hinglish (Translit.kt).
                    </p>
                  </div>
                  <button
                    onClick={() => onToggleTranslit(!enableTranslit)}
                    className={`w-10 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                      enableTranslit ? 'bg-indigo-600' : 'bg-zinc-400 dark:bg-zinc-700'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                        enableTranslit ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* FOOTER NAVIGATION */}
        <div className={`px-5 py-4 border-t flex items-center justify-between ${c.footer}`}>
          <button
            onClick={() => setStep((s) => Math.max(1, s - 1))}
            disabled={step === 1}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition disabled:opacity-30 flex items-center gap-1.5 ${c.prevBtn}`}
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Previous</span>
          </button>
          <div className="flex items-center gap-1.5">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <span
                key={i}
                onClick={() => setStep(i)}
                className={`w-2 h-2 rounded-full cursor-pointer transition-all ${
                  step === i ? 'w-5 bg-indigo-600' : (isDark ? 'bg-zinc-700 hover:bg-zinc-500' : 'bg-slate-300 hover:bg-slate-400')
                }`}
              />
            ))}
          </div>
          {step < totalSteps ? (
            <button
              onClick={() => setStep((s) => Math.min(totalSteps, s + 1))}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow"
            >
              <span>Next</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 text-emerald-950 text-xs font-bold transition flex items-center gap-1.5 shadow-lg active:scale-95"
            >
              <span>Launch OpenAssist 🎉</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
