import React, { useState } from 'react';
import {
  Sparkles, Check, Download, Eye, Monitor, Palette, Heart, Zap,
  Upload
} from 'lucide-react';
import {
  OpenAssistLogo,
  LogoStyle,
  CustomIconItem
} from './LogoVariations';
import { PROJECT_FILES } from '../data/projectFiles';

interface BrandStudioProps {
  currentLogo: LogoStyle;
  onSelectLogo: (style: LogoStyle) => void;
  customIcons?: CustomIconItem[];
  onAddCustomIcon?: (icon: CustomIconItem) => void;
  onDeleteCustomIcon?: (id: string) => void;
}

export type MascotCategory =
  | 'Fox Variation'
  | 'Owl Variation'
  | 'Independent Mascot'
  | 'Cute Mascot'
  | 'Geometric'
  | 'Custom';

interface LogoMetadata {
  id: LogoStyle;
  name: string;
  tagline: string;
  inspiration: string;
  metaphor: string;
  category: MascotCategory;
  badgeColor: string;
}

const LOGO_METAS: LogoMetadata[] = [
  {
    id: 'owl-orbital',
    name: 'Ozzy',
    tagline: 'Flagship Circle-to-Search Sentinel',
    inspiration: 'Circle-to-Search gesture orbit + 8 crop adjust handles + Chubby Sentinel 2.0',
    metaphor: 'The definitive OpenAssist mascot: a chubby, lovable night-vision owl nestled inside an active Circle-to-Search gesture lasso track with 8 precision calibration crop handles, cyber goggles, and dual AI sparks.',
    category: 'Owl Variation',
    badgeColor: 'from-blue-500 to-indigo-600',
  },
  {
    id: 'owl',
    name: 'Ozzy Classic',
    tagline: 'The Night-Vision AI Sentinel',
    inspiration: 'GitHub Octocat + DeepSeek curvature + Night-Vision Omniscience',
    metaphor: 'Owls rotate 270 degrees and spot prey in total darkness. Ozzy turns your Android screen into an omniscient 360 degree visual canvas with twin Circle-to-Search visor lenses, acoustic ear crests for voice dictation, and an AI forehead spark.',
    category: 'Owl Variation',
    badgeColor: 'from-indigo-500 to-purple-600',
  },
  {
    id: 'owl-cosmic',
    name: 'Ozzy Cosmic Orbit',
    tagline: 'Planetary Aura & Star Spark Sentinel',
    inspiration: 'Planetary Saturn Rings + Cosmic Intelligence',
    metaphor: 'Ozzy in deep space orbit: a floating celestial owl wrapped in cosmic nebula rings with star sparks and deep-indigo night-vision lenses.',
    category: 'Owl Variation',
    badgeColor: 'from-purple-600 to-indigo-600',
  },
  {
    id: 'owl-talons',
    name: 'Ozzy Kawaii Perch',
    tagline: 'Bun & Byte Talons on Lens Rim',
    inspiration: 'Bun Dumpling + Byte Kitten Kawaii Talons',
    metaphor: 'Maximum cuteness! An irresistibly chubby marshmallow owl perched directly atop the glowing Circle-to-Search spectacles, with two cute little white talons resting on the rim, sparkly anime eyes, and fluttering side winglets.',
    category: 'Owl Variation',
    badgeColor: 'from-purple-500 to-pink-500',
  },
  {
    id: 'owl-radar',
    name: 'Ozzy Screen Scanner',
    tagline: 'Holographic Targeting Reticles',
    inspiration: 'Night-Vision Radar + Visual Screen Targeting HUD',
    metaphor: 'Concentric circular holographic radar reticles and crosshairs are projected inside Ozzy visor lenses to actively scan, OCR, and parse whatever you circle on screen, with audio antenna ear beacons.',
    category: 'Owl Variation',
    badgeColor: 'from-cyan-400 to-blue-600',
  },
  {
    id: 'owl-wings',
    name: 'Ozzy Privacy Shield',
    tagline: 'Wing Embrace & Telemetry Defense',
    inspiration: 'Cybernetic Aerodynamic Wings + Security Shield',
    metaphor: 'Ozzy spreads aerodynamic cybernetic wings around the glowing Circle-to-Search portal, symbolizing on-device private processing, zero-telemetry de-Googled protection, and swift local response.',
    category: 'Owl Variation',
    badgeColor: 'from-sky-400 to-indigo-600',
  },
  {
    id: 'owl-monocle',
    name: 'Ozzy Scholar Loupe',
    tagline: 'Detective Circle-to-Search Loupe',
    inspiration: 'Single-Lens Magnifying Loupe + Scholar Wink',
    metaphor: 'A delightfully witty, scholarly detective: Ozzy curiously peers through an oversized circular magnifying loupe with one giant sparkly curious eye, a playful wink on the other, and wing holding the cyber handle.',
    category: 'Owl Variation',
    badgeColor: 'from-indigo-400 to-amber-500',
  },
  {
    id: 'owl-minimal',
    name: 'Ozzy Pure-Minimal',
    tagline: 'DeepSeek Aerodynamic Modernist',
    inspiration: 'DeepSeek streamlined geometry + modern flat iconography',
    metaphor: 'Pure Bauhaus vector simplicity: clean circular contours, sharp triangular ear crests, and bold high-contrast goggles that scale down to 16x16 px browser favicon size with pristine clarity.',
    category: 'Owl Variation',
    badgeColor: 'from-indigo-600 to-purple-700',
  },
  {
    id: 'fox',
    name: 'Pip Nexus (Master Synthesis)',
    tagline: 'The Ultimate Circle-to-Search Fox',
    inspiration: 'Seamless union of Ozzy lenses, Byte paws, Ollie spark & Kube-Loop orbit',
    metaphor: 'The master flagship synthesis: a deeply adorable cyber-fox whose curled tail forms the complete Circle-to-Search lasso orbit, with connected search goggles, dual outer calibration nodes, two tiny white paws resting gently on the lenses, rosy blush cheeks, and a golden top AI spark.',
    category: 'Fox Variation',
    badgeColor: 'from-amber-500 to-orange-600',
  },
  {
    id: 'fox-orbital',
    name: 'Pip Astro-Lasso',
    tagline: 'Kube-Loop Gesture Ring Fusion',
    inspiration: 'Kubernetes Helm + Circle-to-Search continuous gesture track',
    metaphor: 'Merges the cute fox with a mathematically perfect continuous gesture lasso track, complete with an open gesture break, 3 Android touch calibration anchor nodes, and a crown AI star.',
    category: 'Fox Variation',
    badgeColor: 'from-blue-500 to-amber-500',
  },
  {
    id: 'fox-cyber',
    name: 'Pip Cyber-Visor',
    tagline: 'Ozzy Sentinel & Acoustic Fusion',
    inspiration: 'Ozzy the Owl Connected Visor + Voice Dictation ear facets',
    metaphor: 'Features Ozzy the Owl high-tech connected search visor with precision calibration nodes, geometric audio receiver ear facets for on-device Whisper dictation, and a sleek white chest plate.',
    category: 'Fox Variation',
    badgeColor: 'from-indigo-500 to-orange-500',
  },
  {
    id: 'fox-paws',
    name: 'Pip Paws-on-Lens',
    tagline: 'Byte Paws & Ollie Kawaii Companion',
    inspiration: 'Byte Kitten Paws + Ollie Floating Antenna Orb',
    metaphor: 'Maximum cuteness! Two tiny white paws rest adorably on the bottom edge of the search spectacles, while a floating listening antenna with an orbital audio ring hovers overhead.',
    category: 'Fox Variation',
    badgeColor: 'from-pink-500 to-amber-500',
  },
  {
    id: 'fox-firefly',
    name: 'Pip Radar-Lens',
    tagline: 'Lumi Holographic Screen Radar',
    inspiration: 'Lumi the Firefly Bioluminescent Targeting Reticle',
    metaphor: 'Concentric circular radar target reticles are projected inside the fox search lenses to actively scan, target, and analyze whatever you circle on screen.',
    category: 'Fox Variation',
    badgeColor: 'from-cyan-400 to-orange-500',
  },
  {
    id: 'fox-halo',
    name: 'Pip Cosmic-Halo',
    tagline: 'Planetary Vision & Ollie Wonder',
    inspiration: 'Ollie Cosmic Orbit + Planetary Saturn Rings',
    metaphor: 'A glowing planetary orbital halo ring gently floats around the fox perky ears with orbital telemetry beacons, combining cosmic intelligence with wide curious anime eyes and starlight sparks.',
    category: 'Fox Variation',
    badgeColor: 'from-sky-400 to-purple-500',
  },
  {
    id: 'fox-headset',
    name: 'Pip Voice-Sentinel',
    tagline: 'Whisper Audio & Dictation Scout',
    inspiration: 'Ozzy Audio Facets + On-Device Voice Speech Pulse',
    metaphor: 'Sleek floating acoustic communicator earcups hug the fox ears with pulsating voice equalizer waveform arcs, symbolizing instantaneous speech-to-text dictation and voice assistant power.',
    category: 'Fox Variation',
    badgeColor: 'from-cyan-500 to-amber-500',
  },
  {
    id: 'fox-monocle',
    name: 'Pip Scout-Loupe',
    tagline: 'Detective Circle-to-Search Loupe',
    inspiration: 'Single-Lens Circle-to-Search Magnifier + Playful Wink',
    metaphor: 'A deeply charming detective scout: the fox playfully peers through an oversized glowing circular magnifying loupe with one giant sparkly curious eye, a cheerful wink, and paw holding the cyber handle.',
    category: 'Fox Variation',
    badgeColor: 'from-amber-400 to-blue-500',
  },
  {
    id: 'fox-minimal',
    name: 'Pip Pure-Minimal',
    tagline: 'DeepSeek Aerodynamic Modernist',
    inspiration: 'DeepSeek streamlined flow + modern flat iconography',
    metaphor: 'Pure vector simplicity: a seamless aerodynamic yin-yang circular contour with bold high-contrast goggles that scale with razor-sharp perfection down to 16x16 px favicon size.',
    category: 'Fox Variation',
    badgeColor: 'from-orange-500 to-rose-600',
  },
  {
    id: 'bat',
    name: 'Echo the Sonic Bat',
    tagline: 'Ultrasonic Acoustic & Voice Scout',
    inspiration: 'Fruit Bat Echolocation + Cozy Velvet Hoodie Wings',
    metaphor: 'Bats navigate with acoustic sonar in total darkness. Echo powers low-latency Whisper speech-to-text dictation and audio intelligence with giant radar ears, acoustic pulse waveforms, a cozy wing hug, and glowing Circle-to-Search visor lenses.',
    category: 'Independent Mascot',
    badgeColor: 'from-indigo-600 to-cyan-500',
  },
  {
    id: 'otter',
    name: 'Nova the Star Otter',
    tagline: 'Deep-Query Zero-Gravity Navigator',
    inspiration: 'River Otter Tool Mastery + Zero-G Space Orbit',
    metaphor: 'Otters are natural tool-users that crack open hard shells. Nova cracks open complex on-screen OCR text, equations, and multi-layered queries while floating in zero-G with spherical bubble lenses, hydrodynamic tail ring, and paws clasping a radiant AI pearl gem.',
    category: 'Independent Mascot',
    badgeColor: 'from-sky-500 to-amber-500',
  },
  {
    id: 'chameleon',
    name: 'Pico the Multi-Modal Chameleon',
    tagline: 'Dual-Focal 360 Degree Vision Intelligence',
    inspiration: 'Chameleon Independent Eye Swivel + Multi-Modal AI',
    metaphor: 'Chameleons look in two different directions at once. Pico embodies multi-modal intelligence: dual independent turret Circle-to-Search lenses allow simultaneously analyzing text on one part of your screen and graphics on another, with coiled fiber-optic data tail.',
    category: 'Independent Mascot',
    badgeColor: 'from-emerald-500 to-cyan-500',
  },
  {
    id: 'tanuki',
    name: 'Taro the Quantum Tanuki',
    tagline: 'On-Device Transformer & Shape-Shifter',
    inspiration: 'Japanese Tanuki Lore + Red Panda Fluff + Local AI Compilers',
    metaphor: 'Legendary tanuki transform reality at will. Taro transforms raw Android screen pixels into structured JSON intents locally on your device with a bushy ringed sensory tail, tactile calibration spectacles, and an AI leaf emblem.',
    category: 'Independent Mascot',
    badgeColor: 'from-orange-500 to-emerald-500',
  },
  {
    id: 'sprite',
    name: 'Ollie the Cosmic Sprite',
    tagline: 'The Chubby Bubble Droid',
    inspiration: 'Bun Dumpling + Ollama Llama + Kirby',
    metaphor: 'Developer tools thrive when they have warmth and memeable charm. Ollie is a chubby, floating digital sprite wearing oversized Circle-to-Search magnifying spectacles and an audio listening antenna.',
    category: 'Cute Mascot',
    badgeColor: 'from-violet-500 to-pink-500',
  },
  {
    id: 'kitten',
    name: 'Byte the Dumpling Kitten',
    tagline: 'The Squishy Robo-Companion',
    inspiration: 'Bun Dumpling + GitHub Octocat + Android Bugdroid',
    metaphor: 'An irresistibly squishy marshmallow cyber-kitten with perked audio receiver ears and tiny paws resting on a glowing search portal ring. Giant sparkly anime eyes and rosy blush cheeks that make developers smile.',
    category: 'Cute Mascot',
    badgeColor: 'from-purple-500 to-indigo-600',
  },
  {
    id: 'firefly',
    name: 'Lumi the Cyber-Firefly',
    tagline: 'The Bioluminescent Vision Guide',
    inspiration: 'Pokemon Celebi + Discord Clyde + Oceanic glow',
    metaphor: 'Fireflies illuminate the dark - Lumi illuminates what is on your screen! Features twin curled acoustic listening antennae, translucent wings, and a glowing circular lantern tummy that acts as the Circle-to-Search spotlight.',
    category: 'Cute Mascot',
    badgeColor: 'from-sky-400 to-cyan-600',
  },
  {
    id: 'axolotl',
    name: 'Kiko the Cosmic Axolotl',
    tagline: 'The Bubble-Helmet Vision Explorer',
    inspiration: 'Internet Axolotl love + Astronaut Bubble Visor',
    metaphor: 'An adorable aquatic space explorer wearing a giant transparent circular astronaut helmet (the Circle-to-Search portal) with Wi-Fi signal external gills, derpy happy smile, and starry eyes.',
    category: 'Cute Mascot',
    badgeColor: 'from-pink-400 to-rose-600',
  },
  {
    id: 'orbital',
    name: 'Kube-Loop (The Orbital Iris)',
    tagline: 'Structural Geometric Power',
    inspiration: 'Kubernetes Helm + Vite Bolt + Svelte Continuity Loop',
    metaphor: 'A continuous geometric gesture loop representing the finger-circling motion of Circle-to-Search. Features an open gesture break for "Open" source, 3 Android gesture calibration anchor nodes, and a 4-point radiant AI prism core.',
    category: 'Geometric',
    badgeColor: 'from-blue-500 to-cyan-400',
  },
  {
    id: 'whale',
    name: 'Moby-Ray (The Deep-Assist)',
    tagline: 'The Friendly Oceanic Navigator',
    inspiration: 'DeepSeek Cetacean + Docker Moby Whale',
    metaphor: 'DeepSeek and Docker proved that marine navigators are beloved symbols of traversing deep model spaces and container fleets. Moby-Ray loops in an aerodynamic circular search orbit, projecting an AI spark from its blowhole.',
    category: 'Geometric',
    badgeColor: 'from-sky-400 to-blue-600',
  },
];

export const BrandStudio: React.FC<BrandStudioProps> = ({
  currentLogo,
  onSelectLogo,
  customIcons = [],
}) => {
  const [selectedStyle, setSelectedStyle] = useState<LogoStyle>(currentLogo);
  const [previewTheme, setPreviewTheme] = useState<'dark' | 'light' | 'mono-white' | 'mono-black'>('dark');
  const [activeFilter, setActiveFilter] = useState<'all' | 'independent' | 'cute' | 'fox' | 'owl' | 'geometric' | 'custom'>('all');

  const activeMeta = LOGO_METAS.find((m) => m.id === selectedStyle) || LOGO_METAS[0];

  const filteredMetas = LOGO_METAS.filter((meta) => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'owl') return meta.category === 'Owl Variation';
    if (activeFilter === 'fox') return meta.category === 'Fox Variation';
    if (activeFilter === 'independent') return meta.category === 'Independent Mascot';
    if (activeFilter === 'cute') return meta.category === 'Cute Mascot';
    if (activeFilter === 'geometric') return meta.category === 'Geometric';
    return true;
  });

  const getSvgCode = (style: LogoStyle): string => {
    const rawStyle = (style || 'owl-orbital').toString().toLowerCase().trim();
    const aliasMap: Record<string, string> = {
      default: 'owl-orbital',
      ozzy: 'owl-orbital',
      'owl-default': 'owl',
      pip: 'fox',
      fennec: 'fox',
      cat: 'kitten',
      byte: 'kitten',
      luna: 'kitten',
      echo: 'bat',
      nova: 'otter',
      pico: 'chameleon',
      taro: 'tanuki',
      momo: 'tanuki',
      ollie: 'sprite',
      bolt: 'sprite',
      lumi: 'firefly',
      kiko: 'axolotl',
      iris: 'orbital',
      moby: 'whale',
    };
    const canonicalId = aliasMap[rawStyle] || rawStyle;
    const key = `assets/mascots/${canonicalId}.svg`;
    if (PROJECT_FILES[key]) return PROJECT_FILES[key];
    if (PROJECT_FILES[`/${key}`]) return PROJECT_FILES[`/${key}`];
    if (PROJECT_FILES[`${canonicalId}.svg`]) return PROJECT_FILES[`${canonicalId}.svg`];
    if (PROJECT_FILES[canonicalId]) return PROJECT_FILES[canonicalId];
    if (PROJECT_FILES['assets/mascots/owl-orbital.svg']) return PROJECT_FILES['assets/mascots/owl-orbital.svg'];
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" width="256" height="256"><text x="20" y="50" fill="white">OpenAssist</text></svg>`;
  };

  const downloadSvg = (style: LogoStyle) => {
    const code = getSvgCode(style);
    const blob = new Blob([code], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `openassist-logo-${style}.svg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8 text-left">
      <div className="bg-gradient-to-r from-[#171A24] via-[#14151C] to-[#1A1C28] border border-white/10 rounded-3xl p-6 sm:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#6366F1]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#6366F1]/15 text-[#818CF8] text-xs font-semibold border border-[#6366F1]/30">
              <Sparkles className="w-3.5 h-3.5" />
              Cute, Approachable &amp; Iconic Mascots (27 Companions)
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              OpenAssist Mascot Collection
            </h2>
            <p className="text-sm text-zinc-300 leading-relaxed">
              Warm, lovable, and community-driven companions inspired by{' '}
              <strong className="text-white">Bun</strong>,{' '}
              <strong className="text-white">Ollama</strong>,{' '}
              <strong className="text-white">GitHub Octocat</strong>, and{' '}
              <strong className="text-white">DeepSeek</strong>. Every mascot features bespoke vector artwork from{' '}
              <code className="text-sky-300 bg-sky-950/60 px-1.5 py-0.5 rounded text-xs">assets/mascots/</code>{' '}
              with core <strong className="text-[#38BDF8]">Circle-to-Search</strong> gesture and{' '}
              <strong className="text-[#818CF8]">Speech Dictation</strong> listening elements.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onSelectLogo(selectedStyle)}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#4F46E5] to-[#6366F1] hover:from-[#4338CA] hover:to-[#4F46E5] text-white text-xs font-semibold shadow-lg shadow-[#4F46E5]/25 flex items-center gap-2 transition-all active:scale-95"
            >
              {currentLogo === selectedStyle ? (
                <>
                  <Check className="w-4 h-4 text-emerald-300" />
                  Active Logo Everywhere
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-amber-300" />
                  Set as Active App Logo
                </>
              )}
            </button>
            <button
              onClick={() => downloadSvg(selectedStyle)}
              className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-200 border border-white/10 text-xs font-medium flex items-center gap-2 transition-all active:scale-95"
            >
              <Download className="w-4 h-4 text-sky-400" />
              Download SVG
            </button>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/5 pb-4 gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow ${
              activeFilter === 'all'
                ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-indigo-500/25 ring-2 ring-indigo-400/40'
                : 'bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            All Mascots (27)
          </button>
          <button
            onClick={() => setActiveFilter('independent')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow ${
              activeFilter === 'independent'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-cyan-500/25 ring-2 ring-cyan-400/40'
                : 'bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <span>✨</span>
            Independent (4: Echo, Nova, Pico, Taro)
          </button>
          <button
            onClick={() => setActiveFilter('cute')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow ${
              activeFilter === 'cute'
                ? 'bg-gradient-to-r from-pink-500 to-rose-600 text-white shadow-rose-500/25 ring-2 ring-rose-400/40'
                : 'bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <Heart className="w-3.5 h-3.5 fill-current text-rose-300" />
            Cute Companions (4: Ollie, Byte, Lumi, Kiko)
          </button>
          <button
            onClick={() => setActiveFilter('fox')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow ${
              activeFilter === 'fox'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-amber-500/25 ring-2 ring-amber-400/40'
                : 'bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <span>🦊</span>
            Pip Fox Family (9)
          </button>
          <button
            onClick={() => setActiveFilter('owl')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow ${
              activeFilter === 'owl'
                ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-indigo-500/25 ring-2 ring-indigo-400/40'
                : 'bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <span>🦉</span>
            Ozzy Owl Family (8)
          </button>
          <button
            onClick={() => setActiveFilter('geometric')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition ${
              activeFilter === 'geometric'
                ? 'bg-[#38BDF8] text-[#0A1835]'
                : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
            }`}
          >
            <span>🌀</span>
            Geometric &amp; Oceanic (2)
          </button>
          <button
            onClick={() => setActiveFilter('custom')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 ${
              activeFilter === 'custom'
                ? 'bg-pink-600 text-white shadow-pink-600/20'
                : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            Custom Icons ({customIcons.length})
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredMetas.map((meta) => {
          const isSelected = selectedStyle === meta.id;
          const isCurrentlyActive = currentLogo === meta.id;
          return (
            <div
              key={meta.id}
              onClick={() => setSelectedStyle(meta.id)}
              className={`relative rounded-2xl p-5 border cursor-pointer transition-all duration-200 flex flex-col justify-between ${
                isSelected
                  ? 'bg-[#181A24] border-[#818CF8] shadow-lg shadow-[#818CF8]/15 ring-2 ring-[#818CF8]/30 scale-[1.02]'
                  : 'bg-[#13141A] border-white/5 hover:border-white/20 hover:bg-[#161720]'
              }`}
            >
              {isCurrentlyActive && (
                <span className="absolute top-3 right-3 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  CURRENT
                </span>
              )}
              <div>
                <div className="w-full h-36 rounded-xl bg-[#0B0C10] flex items-center justify-center p-4 border border-white/5 mb-4 group">
                  <div className="transition-transform duration-300 group-hover:scale-110">
                    <OpenAssistLogo style={meta.id} size={96} theme="dark" />
                  </div>
                </div>
                <span className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider text-white bg-gradient-to-r ${meta.badgeColor} mb-1.5`}>
                  {meta.category}
                </span>
                <h4 className="text-sm font-bold text-white tracking-tight">{meta.name}</h4>
                <p className="text-xs text-zinc-400 mt-1 line-clamp-2">{meta.tagline}</p>
              </div>
              <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-xs">
                <span className="text-[11px] text-zinc-500 font-mono">
                  {meta.id}.svg
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectLogo(meta.id);
                    setSelectedStyle(meta.id);
                  }}
                  className={`text-[11px] font-semibold px-2 py-1 rounded-md transition-colors ${
                    isCurrentlyActive
                      ? 'text-emerald-400 bg-emerald-500/10'
                      : 'text-indigo-400 hover:text-white hover:bg-indigo-600/20'
                  }`}
                >
                  {isCurrentlyActive ? 'Active' : 'Apply'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-[#14151C] border border-white/10 rounded-2xl p-6 space-y-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white">{activeMeta.name}</h3>
                <span className="text-xs px-2 py-0.5 rounded bg-white/5 text-zinc-400 border border-white/10 font-mono">
                  {activeMeta.id}.svg
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-1">{activeMeta.inspiration}</p>
            </div>
            <button
              onClick={() => onSelectLogo(selectedStyle)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                currentLogo === selectedStyle
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow'
              }`}
            >
              {currentLogo === selectedStyle ? (
                <>
                  <Check className="w-3.5 h-3.5" /> Selected
                </>
              ) : (
                <>
                  <Zap className="w-3.5 h-3.5" /> Make Active
                </>
              )}
            </button>
          </div>
          <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5">
            <h4 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1 flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-indigo-400" />
              Design Metaphor &amp; Structural Philosophy
            </h4>
            <p className="text-xs text-zinc-300 leading-relaxed">{activeMeta.metaphor}</p>
          </div>
        </div>

        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#14151C] border border-white/10 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-purple-400" />
                Theme Contrast Preview
              </h4>
              <div className="flex items-center gap-1 bg-white/5 p-0.5 rounded-lg border border-white/5 text-[10px]">
                <button
                  onClick={() => setPreviewTheme('dark')}
                  className={`px-2 py-0.5 rounded ${previewTheme === 'dark' ? 'bg-[#4F46E5] text-white' : 'text-zinc-400'}`}
                >
                  Dark
                </button>
                <button
                  onClick={() => setPreviewTheme('light')}
                  className={`px-2 py-0.5 rounded ${previewTheme === 'light' ? 'bg-[#4F46E5] text-white' : 'text-zinc-400'}`}
                >
                  Light
                </button>
              </div>
            </div>
            <div
              className={`h-48 rounded-xl flex items-center justify-center p-6 transition-colors border ${
                previewTheme === 'dark'
                  ? 'bg-[#0D1117] border-white/10'
                  : 'bg-[#F6F8FA] border-zinc-300'
              }`}
            >
              <OpenAssistLogo style={selectedStyle} size={130} theme={previewTheme} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
