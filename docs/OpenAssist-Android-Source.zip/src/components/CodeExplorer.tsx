import React, { useState } from 'react';
import {
  FileCode, Check, Copy, File, Search, ShieldCheck
} from 'lucide-react';
import { PROJECT_FILES } from '../data/projectFiles';

const CRITICAL_FILES = [
  {
    path: 'README.md',
    badge: 'Documentation & Guide',
    reason: 'Complete system architecture, 8-handle crop specs, dual-engine speech details, CI/CD instructions, and compatibility matrix.'
  },
  {
    path: 'app/src/main/java/com/openassist/app/Speech.kt',
    badge: 'Fixed Oppo & FUTO',
    reason: 'Eliminated "Voice search isn\'t available" Google modal popup by locking FUTO packages and routing Google Speech directly in-process without forced offline Hindi flags.'
  },
  {
    path: 'app/src/main/java/com/openassist/app/OverlayActivity.kt',
    badge: 'Speech & Crop Overlay',
    reason: 'Eliminated cumulative partial speech word duplication, added live Privacy Listening Card, and unified 8-handle crop resizing.'
  },
  {
    path: 'app/src/main/java/com/openassist/app/AssistService.kt',
    badge: 'Delegated Engine',
    reason: 'StubRecognitionService delegates to real speech engines rather than returning hardcoded ERROR_RECOGNIZER_BUSY.'
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    badge: 'Manifest Configured',
    reason: 'Registered VoiceInteractionService and proper digital assistant intent filters.'
  },
  {
    path: 'app/src/main/java/com/openassist/app/WebActivity.kt',
    badge: 'Fixed Auto-Pasting',
    reason: 'Added multi-strategy file injection: DataTransfer Drag & Drop on rich-textarea, dynamic file input search, synthetic paste event, and native hardware paste fallback.'
  },
  {
    path: 'app/src/main/java/com/openassist/app/Translit.kt',
    badge: 'Hinglish Transliteration',
    reason: 'Provides complete Devanagari to Latin phonetics so Hindi spoken input is converted cleanly to Hinglish.'
  },
  {
    path: 'app/src/main/java/com/openassist/app/ModelStore.kt',
    badge: 'Multi-Model Store',
    reason: 'Implements WhisperModelPicker v2: multi-model loading, per-language model binding (Hinglish/Hindi/English), and fast model cycling.'
  },
  {
    path: 'app/src/main/java/com/openassist/app/SettingsActivity.kt',
    badge: 'Unified Whisper Hub',
    reason: 'Unified voice engine selector, multi-model Whisper manager, per-language bindings, and interactive testing sandbox with live transcription.'
  },
  {
    path: 'app/src/main/java/com/openassist/app/SelectionView.kt',
    badge: 'Circle to Search Canvas',
    reason: 'Google Neon Glow lasso, 8 resize handles, pinch zoom and 2-finger pan.'
  }
];

export const CodeExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<string>('app/src/main/java/com/openassist/app/Speech.kt');
  const [searchTerm, setSearchTerm] = useState('');
  const [copied, setCopied] = useState(false);

  const fileList = Object.keys(PROJECT_FILES);
  const filteredFiles = fileList.filter((f) =>
    f.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const currentContent = PROJECT_FILES[selectedFile] || '';
  const criticalInfo = CRITICAL_FILES.find((c) => c.path === selectedFile);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto p-4 space-y-6 text-left">
      <div>
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <FileCode className="w-5 h-5 text-[#8AB4F8]" />
          Project Source Code &amp; Architecture Explorer
        </h2>
        <p className="text-xs text-zinc-400 mt-1">
          Explore all {fileList.length} files in the OpenAssist codebase. Critical universal optimizations and stability fixes are tagged below.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
        {CRITICAL_FILES.slice(0, 4).map((item) => (
          <button
            key={item.path}
            onClick={() => setSelectedFile(item.path)}
            className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
              selectedFile === item.path
                ? 'bg-[#1E2330] border-[#8AB4F8]/50 shadow-md ring-1 ring-[#8AB4F8]/20'
                : 'bg-[#18191E] border-white/5 hover:border-white/10 hover:bg-[#1E1F26]'
            }`}
          >
            <div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400">
                {item.badge}
              </span>
              <p className="text-xs font-semibold text-white mt-1.5 truncate">
                {item.path.split('/').pop()}
              </p>
            </div>
            <p className="text-[10px] text-zinc-400 mt-1 line-clamp-2 leading-tight">
              {item.reason}
            </p>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#141518] border border-[#2D2F36] rounded-2xl overflow-hidden shadow-xl min-h-[580px]">
        <div className="lg:col-span-4 border-b lg:border-b-0 lg:border-r border-[#2D2F36] flex flex-col bg-[#16171B]">
          <div className="p-3 border-b border-[#2D2F36]">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search file path or name..."
                className="w-full bg-[#1F2026] text-xs text-white placeholder-zinc-500 rounded-lg pl-8 pr-3 py-1.5 border border-white/5 focus:outline-none focus:border-[#8AB4F8]"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto max-h-[500px] p-2 space-y-1">
            {filteredFiles.map((path) => {
              const fileName = path.split('/').pop();
              const isSelected = selectedFile === path;
              const isCritical = CRITICAL_FILES.some((c) => c.path === path);

              return (
                <button
                  key={path}
                  onClick={() => setSelectedFile(path)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition ${
                    isSelected
                      ? 'bg-[#8AB4F8] text-[#0A1835] font-semibold'
                      : 'text-zinc-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <File className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-[#0A1835]' : 'text-zinc-400'}`} />
                    <span className="truncate">{fileName}</span>
                  </div>
                  {isCritical && (
                    <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-mono ${
                      isSelected ? 'bg-[#0A1835]/20 text-[#0A1835]' : 'bg-emerald-500/20 text-emerald-400'
                    }`}>
                      FIXED
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div className="lg:col-span-8 flex flex-col bg-[#121316]">
          <div className="h-11 px-4 border-b border-[#2D2F36] flex items-center justify-between bg-[#18191E]">
            <div className="flex items-center gap-2 truncate">
              <span className="text-xs font-mono text-[#8AB4F8] truncate">{selectedFile}</span>
              {criticalInfo && (
                <span className="text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full shrink-0">
                  {criticalInfo.badge}
                </span>
              )}
            </div>
            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium bg-[#2C2D34] text-zinc-200 hover:text-white hover:bg-[#383A42] transition"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  Copy Code
                </>
              )}
            </button>
          </div>
          {criticalInfo && (
            <div className="bg-[#1A202C] border-b border-[#2D3748] px-4 py-2 text-[11px] text-zinc-300 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-white">Universal Android Optimization: </span>
                {criticalInfo.reason}
              </div>
            </div>
          )}
          <div className="flex-1 overflow-auto p-4 max-h-[500px]">
            <pre className="font-mono text-xs text-zinc-300 leading-relaxed tab-4">
              {currentContent.split('\n').map((line, idx) => (
                <div key={idx} className="flex hover:bg-white/5 px-1 rounded">
                  <span className="w-10 select-none text-zinc-600 text-right pr-4 text-[11px]">
                    {idx + 1}
                  </span>
                  <span className="flex-1 whitespace-pre">{line}</span>
                </div>
              ))}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
