import React, { useState } from 'react';
import {
  BookOpen, Copy, Check, Download, ShieldCheck,
  Smartphone, Sparkles, Layers, Cpu, Terminal,
  HelpCircle, ChevronRight, FileText, Heart, Volume2
} from 'lucide-react';
import { PROJECT_FILES } from '../data/projectFiles';
import { mascotAudio } from '../utils/mascotAudio';
import { OpenAssistLogo } from './LogoVariations';
import { APP_VERSION } from '../utils/version';

interface ReadmeViewerProps {
  onSwitchTab?: (tab: 'simulator' | 'readme' | 'download' | 'code' | 'fixes') => void;
}

interface MascotInfo {
  id: string;
  name: string;
  tagline: string;
  badge: string;
  badgeColor: string;
  svgFile: string;
  description: string;
  soundType: 'chirp' | 'boop' | 'sonar' | 'purr' | 'bubble';
}

const MASCOTS: MascotInfo[] = [
  {
    id: 'owl',
    name: 'Ozzy Sentinel',
    tagline: 'Flagship Night-Vision AI Sentinel',
    badge: 'Flagship Default',
    badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    svgFile: '/assets/mascots/owl.svg',
    description: 'Guards screen captures with on-device memory sandboxing and zero telemetry.',
    soundType: 'chirp',
  },
  {
    id: 'fox',
    name: 'Pip Nexus',
    tagline: 'Master Synthesis Screen Fox',
    badge: 'Precision Lasso',
    badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    svgFile: '/assets/mascots/fox.svg',
    description: 'Specializes in sub-millimeter 8-handle crop resizing and rapid visual search.',
    soundType: 'chirp',
  },
  {
    id: 'bat',
    name: 'Echo the Bat',
    tagline: 'Ultrasonic Acoustic Voice Scout',
    badge: 'Whisper Audio',
    badgeColor: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    svgFile: '/assets/mascots/bat.svg',
    description: 'Listens locally via embedded Whisper.cpp C++ JNI bridge with zero cloud audio leakage.',
    soundType: 'sonar',
  },
  {
    id: 'otter',
    name: 'Nova the Otter',
    tagline: 'Zero-Gravity Deep-Query Navigator',
    badge: 'Multi-AI Router',
    badgeColor: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
    svgFile: '/assets/mascots/otter.svg',
    description: 'Seamlessly channels queries to any AI: Claude, ChatGPT, Gemini, or local Ollama servers.',
    soundType: 'bubble',
  },
  {
    id: 'chameleon',
    name: 'Pico the Chameleon',
    tagline: 'Dual-Focal 360 Degree Vision Specialist',
    badge: 'Multi-Modal',
    badgeColor: 'bg-teal-500/10 text-teal-400 border-teal-500/20',
    svgFile: '/assets/mascots/chameleon.svg',
    description: 'Adapts to any screen resolution and orientation with fluid 0.6x to 12.0x pinch-zoom.',
    soundType: 'chirp',
  },
  {
    id: 'tanuki',
    name: 'Taro the Tanuki',
    tagline: 'On-Device Pixel Transformer',
    badge: 'Privacy Cache',
    badgeColor: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
    svgFile: '/assets/mascots/tanuki.svg',
    description: 'Instantly flushes captured screen buffers upon overlay close for total confidentiality.',
    soundType: 'boop',
  },
  {
    id: 'sprite',
    name: 'Ollie the Sprite',
    tagline: 'Floating Droid with Search Spectacles',
    badge: 'System Service',
    badgeColor: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
    svgFile: '/assets/mascots/sprite.svg',
    description: 'Coordinates official Android VoiceInteractionService lifecycle events and gestures.',
    soundType: 'chirp',
  },
  {
    id: 'kitten',
    name: 'Byte the Kitten',
    tagline: 'Squishy Robo-Kitten on Search Portal',
    badge: 'Touch Companion',
    badgeColor: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
    svgFile: '/assets/mascots/kitten.svg',
    description: 'Reactions that bring joy and warmth to every long-press assistant trigger.',
    soundType: 'purr',
  },
  {
    id: 'firefly',
    name: 'Lumi the Firefly',
    tagline: 'Bioluminescent Spotlight & Screen Radar',
    badge: 'Neon Glow',
    badgeColor: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
    svgFile: '/assets/mascots/firefly.svg',
    description: 'Illuminates the glowing lasso path across any background or dark app theme.',
    soundType: 'sonar',
  },
  {
    id: 'axolotl',
    name: 'Kiko the Axolotl',
    tagline: 'Cosmic Astronaut Vision Explorer',
    badge: 'Cross-ROM',
    badgeColor: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
    svgFile: '/assets/mascots/axolotl.svg',
    description: 'Ensures flawless native operation on LineageOS, GrapheneOS, CalyxOS, and OEM Android.',
    soundType: 'bubble',
  },
];

export const ReadmeViewer: React.FC<ReadmeViewerProps> = ({ onSwitchTab }) => {
  const [viewMode, setViewMode] = useState<'visual' | 'raw'>('visual');
  const [copiedRaw, setCopiedRaw] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [selectedMascot, setSelectedMascot] = useState<string>('owl');

  const rawReadmeContent = PROJECT_FILES['README.md'] || '';

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedRaw(true);
    setTimeout(() => setCopiedRaw(false), 2500);
  };

  const handleDownloadReadme = () => {
    const blob = new Blob([rawReadmeContent], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'README.md';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const faqs = [
    {
      q: 'Does OpenAssist require root access, Magisk, or unlocking the bootloader?',
      a: 'No. OpenAssist operates purely in user space as a standard Android application. It implements the documented Android VoiceInteractionService system API, requiring only the standard Default Digital Assistant user toggle.'
    },
    {
      q: 'Why do I need to enable "Use screenshot" in Android Settings?',
      a: 'Android security requires explicit user consent before passing screen capture bitmaps to any assistant application. Once enabled under Settings > Apps > Default apps > Digital assistant app, OpenAssist can capture and highlight your screen upon gesture activation.'
    },
    {
      q: 'Can I use OpenAssist with a self-hosted LLM like Ollama or LM Studio?',
      a: 'Yes! In OpenAssist Settings (or by tapping "+ Add AI" in the overlay toolbar), enter your local web interface URL (e.g. http://192.168.1.50:3000 for Open WebUI or http://192.168.1.50:1234 for LM Studio). OpenAssist will open your local interface and inject the cropped screenshot and prompt seamlessly.'
    },
    {
      q: 'How does on-device Whisper speech recognition work?',
      a: 'OpenAssist embeds a native C++ JNI bridge linking whisper.cpp (GGML v2). It runs quantized acoustic models directly on your device CPU/NPU without sending voice data over the internet. You can also use system offline engines like FUTO Voice Input or Vosk.'
    },
    {
      q: 'Can I use OpenAssist if I do not have Google Play Services installed?',
      a: 'Yes! OpenAssist was architected from the ground up for de-Googled ROMs (LineageOS, GrapheneOS, CalyxOS, /e/OS). It functions natively without microG or proprietary Google Play libraries.'
    },
    {
      q: 'Does OpenAssist collect any user telemetry or analytics?',
      a: 'Zero. OpenAssist contains no tracking SDKs, no telemetry beacons, no ad frameworks, and no remote error tracking. Captured screenshots are held in temporary memory and are only sent to whichever AI service you explicitly command.'
    }
  ];

  return (
    <div className="max-w-5xl mx-auto p-4 space-y-10 text-left">
      <div className="relative overflow-hidden bg-gradient-to-br from-[#161922] via-[#121318] to-[#0D0E12] border border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#8AB4F8]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-start gap-4">
            <div className="relative shrink-0 group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-[#202430] to-[#12141A] border border-white/15 p-2 flex items-center justify-center shadow-lg group-hover:scale-105 transition">
                <OpenAssistLogo
                  style="owl-orbital"
                  size={64}
                  theme="dark"
                  className="filter drop-shadow-[0_4px_12px_rgba(138,180,248,0.3)]"
                />
              </div>
              <span className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500 text-black shadow">
                {APP_VERSION.displayName}
              </span>
            </div>
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  100% Free &amp; Open Source
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#8AB4F8]/10 text-[#8AB4F8] border border-[#8AB4F8]/20">
                  GPLv3 Licensed
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-500/10 text-purple-400 border border-purple-500/20">
                  On-Device Whisper
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  Zero Telemetry
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
                OpenAssist Documentation
              </h1>
              <p className="text-xs sm:text-sm text-zinc-300 max-w-2xl leading-relaxed">
                The free and open-source Digital Assistant &amp; Circle to Search for Android. Engineered for complete privacy, multi-AI freedom, and sub-pixel visual precision.
              </p>
            </div>
          </div>

          <div className="flex flex-row md:flex-col gap-2 w-full md:w-auto shrink-0">
            <div className="flex bg-[#191B22] p-1 rounded-xl border border-white/10 text-xs">
              <button
                onClick={() => setViewMode('visual')}
                className={`flex-1 md:flex-initial px-3 py-1.5 rounded-lg font-medium transition flex items-center justify-center gap-1.5 ${
                  viewMode === 'visual'
                    ? 'bg-[#8AB4F8] text-[#0A1835] font-bold shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Guide</span>
              </button>
              <button
                onClick={() => setViewMode('raw')}
                className={`flex-1 md:flex-initial px-3 py-1.5 rounded-lg font-medium transition flex items-center justify-center gap-1.5 ${
                  viewMode === 'raw'
                    ? 'bg-[#8AB4F8] text-[#0A1835] font-bold shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Raw Markdown</span>
              </button>
            </div>
            <button
              onClick={() => copyToClipboard(rawReadmeContent)}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-[#20222A] hover:bg-[#2A2D37] text-zinc-200 border border-white/10 flex items-center justify-center gap-2 transition shadow-sm"
            >
              {copiedRaw ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied README.md!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Copy Markdown</span>
                </>
              )}
            </button>
            <button
              onClick={handleDownloadReadme}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-[#2A2D38] hover:bg-[#343845] text-zinc-200 border border-white/10 flex items-center justify-center gap-2 transition shadow-sm"
            >
              <Download className="w-3.5 h-3.5 text-sky-400" />
              <span>Download README.md</span>
            </button>
          </div>
        </div>

        {viewMode === 'visual' && (
          <div className="mt-6 pt-5 border-t border-white/5 flex flex-wrap gap-2 text-xs">
            <a href="#overview" className="px-3 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10 transition">Overview</a>
            <a href="#pillars" className="px-3 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10 transition">Core Pillars</a>
            <a href="#mascots" className="px-3 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10 transition">Mascot Cast</a>
            <a href="#matrix" className="px-3 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10 transition">Capabilities</a>
            <a href="#architecture" className="px-3 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10 transition">Architecture</a>
            <a href="#setup" className="px-3 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10 transition">Setup Guide</a>
            <a href="#faq" className="px-3 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10 transition">FAQ</a>
          </div>
        )}
      </div>

      {viewMode === 'raw' ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-zinc-400">
            <span>Viewing repository root <code className="text-zinc-200">README.md</code> ({rawReadmeContent.length} bytes)</span>
            <button
              onClick={() => copyToClipboard(rawReadmeContent)}
              className="px-3 py-1 rounded-lg bg-white/10 text-white hover:bg-white/15 transition flex items-center gap-1.5 font-semibold"
            >
              {copiedRaw ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedRaw ? 'Copied' : 'Copy All'}</span>
            </button>
          </div>
          <div className="bg-[#0F1014] border border-white/10 rounded-2xl p-5 overflow-x-auto shadow-inner">
            <pre className="text-xs font-mono text-zinc-300 leading-relaxed whitespace-pre-wrap selection:bg-[#8AB4F8]/30">
              {rawReadmeContent}
            </pre>
          </div>
        </div>
      ) : (
        <>
          <section id="overview" className="space-y-4">
            <div className="flex items-center gap-2 text-white text-lg font-bold">
              <BookOpen className="w-5 h-5 text-[#8AB4F8]" />
              <h2>Overview &amp; Philosophy</h2>
            </div>
            <div className="bg-[#15161C] border border-white/10 rounded-2xl p-6 text-xs sm:text-sm text-zinc-300 leading-relaxed space-y-4">
              <p>
                OpenAssist brings complete digital assistance and visual Circle to Search to Android users with zero vendor lock-in, zero telemetry, and maximum flexibility. Whether on privacy-first custom distributions (LineageOS, GrapheneOS, CalyxOS) or standard OEM devices, OpenAssist delivers a full-featured screen search experience in a completely free, open-source package.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                <div className="bg-[#1C1E26] p-4 rounded-xl border border-white/5 space-y-2">
                  <span className="font-bold text-white flex items-center gap-1.5 text-xs">
                    <Smartphone className="w-4 h-4 text-emerald-400" />
                    Native System Service
                  </span>
                  <p className="text-zinc-400 text-xs">
                    Implements Android&apos;s standard <code className="text-zinc-200">VoiceInteractionService</code>. Triggers via long-press Home or corner navigation gestures with instant response.
                  </p>
                </div>
                <div className="bg-[#1C1E26] p-4 rounded-xl border border-white/5 space-y-2">
                  <span className="font-bold text-white flex items-center gap-1.5 text-xs">
                    <Layers className="w-4 h-4 text-sky-400" />
                    8-Handle Precision Crop
                  </span>
                  <p className="text-zinc-400 text-xs">
                    Glowing lasso with 8 precision handles (52dp hitboxes), 2-finger panning, and 0.6x to 12.0x pinch-zoom for sub-millimeter visual capture.
                  </p>
                </div>
                <div className="bg-[#1C1E26] p-4 rounded-xl border border-white/5 space-y-2">
                  <span className="font-bold text-white flex items-center gap-1.5 text-xs">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    Zero AI Lock-In
                  </span>
                  <p className="text-zinc-400 text-xs">
                    Direct integration with Claude, ChatGPT, Gemini, DeepSeek, Grok, or local self-hosted models (Ollama, LM Studio) on your own network.
                  </p>
                </div>
              </div>
            </div>
          </section>

          <section id="pillars" className="space-y-4">
            <div className="flex items-center gap-2 text-white text-lg font-bold">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <h2>Core Platform Pillars</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-gradient-to-br from-[#181B24] to-[#12141A] border border-white/10 space-y-2.5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">Absolute Privacy Guarantee</h3>
                    <span className="text-[11px] text-emerald-400 font-semibold">100% On-Device Processing</span>
                  </div>
                </div>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  OpenAssist collects zero telemetry, zero analytics, and zero device fingerprints. Screen bitmaps remain strictly in memory and are never transmitted to third parties. Screen data is dispatched only to the AI backend you explicitly select.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-gradient-to-br from-[#181B24] to-[#12141A] border border-white/10 space-y-2.5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center shrink-0">
                    <Cpu className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">Offline Whisper Speech</h3>
                    <span className="text-[11px] text-purple-400 font-semibold">Native C++ JNI GGML Engine</span>
                  </div>
                </div>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  High-performance on-device voice transcription powered by Whisper.cpp. Supports quantized models (Tiny, Base, Small) and privacy-focused system engines like FUTO Voice Input and Vosk without forced cloud reliance.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-gradient-to-br from-[#181B24] to-[#12141A] border border-white/10 space-y-2.5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center shrink-0">
                    <Sparkles className="w-5 h-5 text-sky-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">Universal AI Connectivity</h3>
                    <span className="text-[11px] text-sky-400 font-semibold">Cloud &amp; Local LAN Endpoints</span>
                  </div>
                </div>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  Choose from leading cloud services (Claude, ChatGPT, Gemini, DeepSeek, Grok) or keep everything completely offline by connecting your local network Ollama or LM Studio instance (<code className="text-zinc-200">http://192.168.x.x:3000</code>).
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-gradient-to-br from-[#181B24] to-[#12141A] border border-white/10 space-y-2.5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
                    <Layers className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">Sub-Millimeter Touch Precision</h3>
                    <span className="text-[11px] text-amber-400 font-semibold">8 Anchors &amp; Multi-Touch Zoom</span>
                  </div>
                </div>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  Smooth neon glow freehand lasso with 4 corner anchors and 4 midpoint edge handles. Equipped with 52dp hitboxes that prevent accidental mis-touches, along with fluid two-finger panning and 0.6x to 12.0x pinch-to-zoom.
                </p>
              </div>
            </div>
          </section>

          <section id="mascots" className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white text-lg font-bold">
                <Heart className="w-5 h-5 text-rose-400" />
                <h2>Mascot Companions Showcase</h2>
              </div>
              <span className="text-xs text-zinc-400 hidden sm:inline">10 Reactive Personalities with Audio Chirps</span>
            </div>
            <div className="bg-[#15161C] border border-white/10 rounded-2xl p-5 space-y-5">
              <p className="text-xs text-zinc-300 leading-relaxed">
                OpenAssist brings warmth and personality to screen search. Select your favorite companion in Settings; each mascot comes with bespoke vector artwork and responsive sound effects that react during search and voice listening.
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                {MASCOTS.map((m) => {
                  const isSelected = selectedMascot === m.id;
                  return (
                    <button
                      key={m.id}
                      onClick={() => {
                        setSelectedMascot(m.id);
                        if (m.soundType === 'sonar') mascotAudio.playChime('listen');
                        else if (m.soundType === 'bubble') mascotAudio.playChime('tip');
                        else if (m.soundType === 'purr') mascotAudio.playChime('success');
                        else mascotAudio.playChime('poke');
                      }}
                      className={`p-3 rounded-xl border text-center transition flex flex-col items-center gap-2.5 relative group ${
                        isSelected
                          ? 'bg-[#1F2330] border-[#8AB4F8]/60 shadow-lg ring-1 ring-[#8AB4F8]/40'
                          : 'bg-[#181A22] border-white/5 hover:border-white/20 hover:bg-[#1C1F2A]'
                      }`}
                    >
                      <div className="w-14 h-14 p-1 rounded-xl bg-black/20 flex items-center justify-center group-hover:scale-110 transition duration-200">
                        <OpenAssistLogo
                          style={m.id}
                          size={48}
                          theme="dark"
                          className="filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.4)]"
                        />
                      </div>
                      <div className="space-y-0.5">
                        <h4 className="text-xs font-bold text-white truncate max-w-[120px]">{m.name}</h4>
                        <span className={`inline-block px-1.5 py-0.2 rounded text-[9px] font-semibold border ${m.badgeColor}`}>
                          {m.badge}
                        </span>
                      </div>
                      <div className="opacity-0 group-hover:opacity-100 transition absolute top-1.5 right-1.5">
                        <Volume2 className="w-3 h-3 text-zinc-400" />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </section>

          <section id="faq" className="space-y-4">
            <div className="flex items-center gap-2 text-white text-lg font-bold">
              <HelpCircle className="w-5 h-5 text-purple-400" />
              <h2>Frequently Asked Questions</h2>
            </div>
            <div className="space-y-2.5">
              {faqs.map((faq, idx) => (
                <div
                  key={idx}
                  className="bg-[#15161C] border border-white/10 rounded-2xl overflow-hidden transition"
                >
                  <button
                    onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                    className="w-full p-4 text-left flex items-center justify-between text-xs sm:text-sm font-semibold text-white hover:bg-white/[0.02]"
                  >
                    <span>{faq.q}</span>
                    <ChevronRight
                      className={`w-4 h-4 text-zinc-400 transition-transform ${
                        activeFaq === idx ? 'rotate-90 text-[#8AB4F8]' : ''
                      }`}
                    />
                  </button>
                  {activeFaq === idx && (
                    <div className="p-4 pt-0 text-xs text-zinc-300 leading-relaxed border-t border-white/5 bg-[#121318]">
                      {faq.a}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>
        </>
      )}
    </div>
  );
};
