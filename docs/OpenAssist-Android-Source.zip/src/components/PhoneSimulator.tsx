import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Copy, X, Mic, Send, Plus,
  Settings as SettingsIcon, Check, Sparkles,
  Volume2, VolumeX, Play, Pause, Square, Minus, RefreshCw, ZoomIn, ZoomOut, Move,
  ArrowLeft, ShieldCheck, Share2, Lock, Paperclip,
  ClipboardPaste, Globe, Menu, Trash2, Download, Upload, HelpCircle,
  ExternalLink, Sliders
} from 'lucide-react';
import { toHinglish } from '../utils/translit';
import { OpenAssistLogo, LogoStyle, CustomIconItem } from './LogoVariations';
import { mascotAudio } from '../utils/mascotAudio';
import { ChipManagerModal } from './ChipManagerModal';
import {
  AssistService,
  ServiceCategory,
  CATEGORY_LABELS,
  BUILT_IN_SERVICES,
  getSearchUrl,
  getAppDeepLinkUri,
  getStoredServices,
  saveStoredServices,
  getStoredHistoryEnabled,
  saveStoredHistoryEnabled,
  getStoredAutoSpeakEnabled,
  saveStoredAutoSpeakEnabled,
  getStoredSpeechRate,
  saveStoredSpeechRate,
  getStoredAudioMinimized,
  saveStoredAudioMinimized,
} from '../data/servicesCatalog';
import { APP_VERSION, isNewerVersion } from '../utils/version';

export type ScreenMode = 'overlay' | 'chat' | 'settings';
export type SelectShape = 'circle' | 'box';
export type VoiceLang = 'en' | 'hi' | 'hinglish';

export interface HistoryItem {
  id: string;
  query: string;
  serviceName: string;
  timestamp: number;
  url?: string;
}

export const getWholesomeGreeting = (mascot?: string): string => {
  const s = (mascot || 'owl-orbital').toLowerCase();
  if (s.startsWith('owl')) {
    return "Welcome home, friend! Ready to explore something wonderful today? I'm right here by your side whenever curiosity strikes! ✨";
  }
  if (s.startsWith('fox')) {
    return "Nexus synthesis online! I'm so thrilled to be your companion. What brilliant questions are we tackling today? 🦊";
  }
  if (s === 'bat') {
    return "Sonic radar locked on! I'm tuned to your wavelength, friend. Ready to listen and uncover insights anytime! 🦇";
  }
  if (s === 'otter') {
    return "Splashing into the sea of knowledge! Having you here makes today amazing. Let's dive deep and create! 🦦";
  }
  if (s === 'chameleon') {
    return "Rainbow vision active! I adapt to whatever you need, seamlessly. So happy to be your partner! 🦎";
  }
  if (s === 'tanuki') {
    return "Offline, loyal, and ready to roll! Your questions stay 100% private with me. Let's conquer the day! 🦝";
  }
  if (s === 'kitten' || s === 'cat') {
    return "Purr-fect day to learn together! I'm your cuddly pocket guide, always ready to assist! 🐱";
  }
  if (s === 'axolotl') {
    return "Glowing with joy to see you! Every question is an adventure. Let's discover something cool! 🌸";
  }
  if (s === 'firefly') {
    return "Illuminating your ideas! We make an unstoppable team. Ready to shine bright! 🏮";
  }
  if (s === 'whale') {
    return "Deep navigation active! Navigating the boundless ocean of ideas together with you! 🐋";
  }
  return "Welcome back, friend! I'm overjoyed to be your companion. Let's discover something wonderful together today! ✨";
};

interface PhoneSimulatorProps {
  onOpenCode?: (filePath: string) => void;
  logoStyle?: LogoStyle;
  customIcons?: CustomIconItem[];
  onOpenSetupWizard?: () => void;
  onOpenLogoSwitcher?: () => void;
  onSelectLogo?: (style: LogoStyle) => void;
  isDarkMode?: boolean;
  onToggleDarkMode?: (isDark: boolean) => void;
}

const SAMPLE_SCREEN_TEXT = [
  { id: 1, type: 'header', text: 'Quantum Supercomputing Milestone' },
  { id: 2, type: 'meta', text: 'Tech Horizons   3 min read' },
  { id: 3, type: 'paragraph', text: 'Researchers have unveiled a novel topological qubit architecture that achieves 99.9% gate fidelity while operating at ambient room temperature.' },
  { id: 4, type: 'callout', text: 'Formula: psi(t) = exp(-iHt) psi(0)   Coherence time extended by 14,000x' },
  { id: 5, type: 'paragraph', text: 'This breakthrough allows mobile digital assistants to execute deep reasoning locally on custom ROMs without sending unencrypted telemetry to big-tech servers.' },
];

export type AiServiceItem = AssistService;
export const BUILT_IN_AI_SERVICES: AssistService[] = BUILT_IN_SERVICES;

export const ALL_SIMULATOR_MASCOTS: { id: LogoStyle; name: string; tag: string }[] = [
  { id: 'owl-orbital', name: 'Ozzy', tag: 'Flagship Sentinel' },
  { id: 'owl', name: 'Ozzy Classic', tag: 'Classic Night-Vision' },
  { id: 'fox', name: 'Pip Nexus', tag: 'Master Synthesis Fox' },
  { id: 'bat', name: 'Echo Bat', tag: 'Acoustic Radar' },
  { id: 'otter', name: 'Nova Otter', tag: 'Cosmic Diver' },
  { id: 'chameleon', name: 'Pico Chameleon', tag: 'Multi-Modal Vision' },
  { id: 'tanuki', name: 'Taro Tanuki', tag: 'Offline Transformer' },
  { id: 'sprite', name: 'Ollie Sprite', tag: 'Cosmic Spark' },
  { id: 'kitten', name: 'Byte Kitten', tag: 'Pocket Dumpling' },
  { id: 'firefly', name: 'Lumi Firefly', tag: 'Bioluminescent' },
  { id: 'axolotl', name: 'Kiko Axolotl', tag: 'Glow Sensor' },
  { id: 'whale', name: 'Moby-Ray', tag: 'Ocean Navigator' },
  { id: 'orbital', name: 'Iris Loop', tag: 'Kube-Loop' },
  { id: 'owl-cosmic', name: 'Ozzy Cosmic', tag: 'Cosmic Orbit' },
  { id: 'owl-talons', name: 'Ozzy Perch', tag: 'Kawaii Perch' },
  { id: 'owl-radar', name: 'Ozzy Radar', tag: 'Radar Array' },
  { id: 'owl-wings', name: 'Ozzy Shield', tag: 'Shield Stance' },
  { id: 'owl-monocle', name: 'Ozzy Scholar', tag: 'Scholar Loupe' },
  { id: 'owl-minimal', name: 'Ozzy Minimal', tag: 'Pure Glyph' },
  { id: 'fox-orbital', name: 'Pip Orbit', tag: 'Astro-Lasso' },
  { id: 'fox-cyber', name: 'Pip Cyber', tag: 'Cyber-Visor' },
  { id: 'fox-paws', name: 'Pip Paws', tag: 'Touch Sensor' },
  { id: 'fox-firefly', name: 'Pip Radar', tag: 'Radar-Lens' },
  { id: 'fox-halo', name: 'Pip Halo', tag: 'Cosmic-Halo' },
  { id: 'fox-headset', name: 'Pip Voice', tag: 'Voice-Sentinel' },
  { id: 'fox-monocle', name: 'Pip Loupe', tag: 'Scout-Loupe' },
  { id: 'fox-minimal', name: 'Pip Minimal', tag: 'Pure-Minimal' },
];

export const PhoneSimulator: React.FC<PhoneSimulatorProps> = ({
  logoStyle = 'owl-orbital',
  customIcons = [],
  onOpenSetupWizard,
  onOpenLogoSwitcher,
  onSelectLogo,
  isDarkMode: propDarkMode,
  onToggleDarkMode,
}) => {
  const [screenMode, setScreenMode] = useState<ScreenMode>('overlay');
  const [selectShape, setSelectShape] = useState<SelectShape>('circle');
  const [selectedService, setSelectedService] = useState('gemini');
  const [voiceLang, setVoiceLang] = useState<VoiceLang>('en');
  const [promptText, setPromptText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [selectionCrop, setSelectionCrop] = useState<string | null>(null);
  const [copyFeedback, setCopyFeedback] = useState(false);
  const [autoAttachedBadge, setAutoAttachedBadge] = useState(false);

  const [showMascotChip, setShowMascotChip] = useState(true);
  const [showMascotInSearchPill, setShowMascotInSearchPill] = useState(false);
  const [showSpeechBubble, setShowSpeechBubble] = useState(true);
  const [enableTranslit, setEnableTranslit] = useState(true);
  const [isDefaultAssist, setIsDefaultAssist] = useState(true);
  const [pettingHearts, setPettingHearts] = useState<{ id: number; x: number; y: number }[]>([]);

  const [tipIndex, setTipIndex] = useState(0);
  const [showMascotMenu, setShowMascotMenu] = useState(false);
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const [showWebMenuDropdown, setShowWebMenuDropdown] = useState(false);
  const [showFullHistoryModal, setShowFullHistoryModal] = useState(false);
  const [showAboutModal, setShowAboutModal] = useState(false);
  const [updateCheckStatus, setUpdateCheckStatus] = useState<string | null>(null);
  const [isCheckingUpdate, setIsCheckingUpdate] = useState(false);
  const [discoveredRelease, setDiscoveredRelease] = useState<{
    tag: string;
    name: string;
    body: string;
    apkUrl: string | null;
  } | null>(null);
  const [isDownloadingUpdate, setIsDownloadingUpdate] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadBytes, setDownloadBytes] = useState({ read: 0, total: 27.8 * 1024 * 1024 });
  const [downloadCompletedApk, setDownloadCompletedApk] = useState<string | null>(null);
  const [showInstallPromptModal, setShowInstallPromptModal] = useState(false);
  const [installedAppVersion, setInstalledAppVersion] = useState(APP_VERSION.displayName);
  const [toastMascotPillEnabled, setToastMascotPillEnabled] = useState(true);
  const [toastSpeechEnabled, setToastSpeechEnabled] = useState(true);
  const [toastCircleEnabled, setToastCircleEnabled] = useState(true);
  const [toastAssistantEnabled, setToastAssistantEnabled] = useState(true);
  const [speechEngineChoice, setSpeechEngineChoice] = useState<'Whisper' | 'FUTO' | 'Google' | 'Default'>('Whisper');
  const [assistantHistory, setAssistantHistory] = useState<HistoryItem[]>([
    { id: '1', query: 'Quantum supercomputing topological qubit fidelity', serviceName: 'Gemini', timestamp: Date.now() - 1000 * 60 * 12 },
    { id: '2', query: 'Translate psi formula to Python numpy simulation', serviceName: 'ChatGPT', timestamp: Date.now() - 1000 * 60 * 45 },
    { id: '3', query: 'Circle to Search gesture responsiveness on LineageOS', serviceName: 'Claude', timestamp: Date.now() - 1000 * 60 * 180 },
    { id: '4', query: 'Local offline Whisper model GGUF quantization benchmark', serviceName: 'Perplexity', timestamp: Date.now() - 1000 * 60 * 360 },
    { id: '5', query: 'Explain ambient room temperature coherence extension', serviceName: 'DeepSeek', timestamp: Date.now() - 1000 * 60 * 720 },
  ]);
  const [mascotStreak] = useState(3);
  const [mascotSparks, setMascotSparks] = useState(45);
  const [celebrateBanner, setCelebrateBanner] = useState<string | null>(null);
  const [mascotCustomReaction, setMascotCustomReaction] = useState<string | null>(null);
  const [reactionIndex, setReactionIndex] = useState(0);
  const [petIndex, setPetIndex] = useState(0);

  const MASCOT_PET_PHRASES = [
    "*purrs happily* You're doing great today! ",
    "I love learning new things with you! ",
    "*happy chirp* Always ready by your side! ",
    "You're my favorite human! ",
    "Ready whenever you are! What shall we search? ",
    "All systems green! Ask me anything! ",
    "*gentle nuzzle* You've got this! ",
    "Always here to brighten your day! "
  ];

  const MASCOT_REACTIONS = [
    "Ready to assist with twin lenses! ",
    "Circle any equation or object to search! ",
    "100% on-device Whisper: 0 bytes leaked ",
    "Listening mode active and primed! ",
    "Transcribed in 120ms with zero cloud lag! ",
    "Type Devanagari Hindi -> Live Hinglish ready ",
    "All assistant systems nominal! "
  ];

  const triggerMascotReaction = (text: string) => {
    setMascotCustomReaction(text);
    setTimeout(() => {
      setMascotCustomReaction((prev) => (prev === text ? null : prev));
    }, 3800);
  };

  const petMascot = (e?: React.MouseEvent) => {
    const nextPhrase = MASCOT_PET_PHRASES[petIndex % MASCOT_PET_PHRASES.length];
    setPetIndex((p) => p + 1);
    triggerMascotReaction(nextPhrase);
    const heartId = Date.now() + Math.random();
    const target = e?.currentTarget as HTMLElement | undefined;
    let x = 0;
    let y = 0;
    if (target) {
      const rect = target.getBoundingClientRect();
      x = rect.left + rect.width / 2;
      y = rect.top;
    } else {
      x = window.innerWidth / 2;
      y = 200;
    }
    setPettingHearts((prev) => [...prev, { id: heartId, x, y }]);
    setTimeout(() => {
      setPettingHearts((prev) => prev.filter((h) => h.id !== heartId));
    }, 1200);
  };

  const MASCOT_TIPS = [
    "Ready to help! Tap to pet me ",
    "  Circle any object or equation to search!",
    "  Double tap any text on screen to copy it instantly!",
    "  Drag two fingers to zoom into small details!",
    "  Tap the mic to dictate your questions hands-free!",
    "  Switch your AI engine anytime in Settings!",
  ];

  const runBenchmark = () => {
    triggerMascotReaction("  Testing on-device Whisper engine...");
    setTimeout(() => {
      const w = Math.floor(170 + Math.random() * 35);
      const f = Math.floor(105 + Math.random() * 25);
      const g = Math.floor(310 + Math.random() * 60);
      triggerMascotReaction(`  Whisper: ${w}ms (Offline)   FUTO: ${f}ms   Cloud: ${g}ms`);
    }, 850);
  };

  const getSpeechBubbleText = () => {
    if (mascotCustomReaction) return mascotCustomReaction;
    if (isListening) return "  Listening via Whisper...";
    if (isTranscribing) return "  Transcribing speech...";
    if (copyFeedback) return "  Copied to clipboard!";
    if (selectionCrop) return "  Area captured! Ask AI below";
    if (promptText.trim()) return `  Ready for ${activeAiService.name}`;
    if (dragStateRef.current.mode === 'draw') return "  Targeting screen pixels...";
    return MASCOT_TIPS[tipIndex];
  };

  const [customAiServices, setCustomAiServices] = useState<AiServiceItem[]>([
    {
      id: 'custom_ollama',
      name: 'Open WebUI (Local)',
      url: 'http://localhost:3000',
      color: '#10B981',
      isCustom: true,
      category: 'ai',
      isEnabled: true,
      openInApp: false
    }
  ]);
  const [showAddAiModal, setShowAddAiModal] = useState(false);
  const [newAiName, setNewAiName] = useState('');
  const [newAiUrl, setNewAiUrl] = useState('');
  const [, setAiToast] = useState<string | null>(null);

  // Whisper Models State (Add & Remove)
  const [whisperModelsList, setWhisperModelsList] = useState([
    { id: 'ggml-tiny.bin', name: 'ggml-tiny.bin', size: '75 MB' },
    { id: 'ggml-base.bin', name: 'ggml-base.bin', size: '142 MB' },
    { id: 'ggml-small.bin', name: 'ggml-small.bin', size: '466 MB' }
  ]);
  const [defaultWhisperModelId, setDefaultWhisperModelId] = useState('ggml-tiny.bin');

  // Per-Language Model Bindings (Bind, Add, Remove preexisting/custom)
  const [activeLangBindings, setActiveLangBindings] = useState<Array<{ code: string; name: string; isStandard: boolean; modelId: string }>>([
    { code: 'hinglish', name: 'Hinglish (Default)', isStandard: true, modelId: 'ggml-tiny.bin' },
    { code: 'hi', name: 'Hindi (Secondary)', isStandard: true, modelId: 'ggml-tiny.bin' },
    { code: 'en', name: 'English', isStandard: true, modelId: 'ggml-base.bin' },
  ]);

  // App & Menu Language Settings
  const [appLanguageSetting, setAppLanguageSetting] = useState('en');
  const [settingsLangOverride, setSettingsLangOverride] = useState('');
  const [overlayLangOverride, setOverlayLangOverride] = useState('');
  const [webLangOverride, setWebLangOverride] = useState('');
  const [mascotLangOverride, setMascotLangOverride] = useState('');

  // Available Languages list (Extensions)
  const [allLanguagesList, setAllLanguagesList] = useState([
    { code: 'en', name: 'English (Default)' },
    { code: 'hinglish', name: 'Hinglish' },
    { code: 'hi', name: 'Hindi (हिंदी)' },
    { code: 'es', name: 'Spanish (Español)' },
    { code: 'fr', name: 'French (Français)' },
  ]);

  // Mascot Speech Phrases list
  const [mascotDialogueList, setMascotDialogueList] = useState<string[]>([
    "All systems green! Ask me anything! ✨",
    "Offline Whisper transcription is ready and private 🎙️",
    "Ready to help! Tap to pet me 💖",
    "Circle or box any element on screen to analyze 🔍",
    "Your data stays 100% on your device, always 🛡️",
    "Long-press anywhere or draw a loop on any screen 💫"
  ]);

  // Modals for Language & Mascot features
  const [showAddLangModal, setShowAddLangModal] = useState(false);
  const [showExportLangModal, setShowExportLangModal] = useState(false);
  const [showImportLangModal, setShowImportLangModal] = useState(false);
  const [showEditorLangModal, setShowEditorLangModal] = useState(false);
  const [showMascotStudioModal, setShowMascotStudioModal] = useState(false);
  const [newLangCode, setNewLangCode] = useState('');
  const [newLangName, setNewLangName] = useState('');
  const [importLangText, setImportLangText] = useState('');
  const [newMascotPhrase, setNewMascotPhrase] = useState('');
  const [selectedStudioMascot, setSelectedStudioMascot] = useState('all');

  const [services, setServices] = useState<AssistService[]>(() => getStoredServices());
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<ServiceCategory>('all');
  const [showChipManagerModal, setShowChipManagerModal] = useState(false);
  const [missingAppPrompt, setMissingAppPrompt] = useState<{ service: AssistService; query: string } | null>(null);
  const [isLocalHistoryEnabled, setIsLocalHistoryEnabled] = useState<boolean>(() => getStoredHistoryEnabled());
  const [currentWebUrl, setCurrentWebUrl] = useState<string>('https://gemini.google.com/app');
  const [baseChatUrl, setBaseChatUrl] = useState<string>('https://gemini.google.com/app');
  const [isExternalDocOpen, setIsExternalDocOpen] = useState(false);

  // Auto-Read Aloud Speech Engine State
  const [isAutoSpeakEnabled, setIsAutoSpeakEnabled] = useState<boolean>(() => getStoredAutoSpeakEnabled());
  const [speechRate, setSpeechRate] = useState<number>(() => getStoredSpeechRate());
  const [isAudioMinimized, setIsAudioMinimized] = useState<boolean>(() => getStoredAudioMinimized());
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [audioStatus, setAudioStatus] = useState<string>('Speaking aloud...');
  const [currentSpeechText, setCurrentSpeechText] = useState<string | null>(null);

  useEffect(() => {
    const handleStorage = () => {
      setServices(getStoredServices());
      setIsLocalHistoryEnabled(getStoredHistoryEnabled());
      setIsAutoSpeakEnabled(getStoredAutoSpeakEnabled());
      setSpeechRate(getStoredSpeechRate());
      setIsAudioMinimized(getStoredAudioMinimized());
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const playSpeech = (text: string, isNativeSimulated = false) => {
    try {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const cleanText = text.replace(/\[.*?\]/g, '').replace(/https?:\/\/\S+/g, '').trim();
        const utterance = new SpeechSynthesisUtterance(cleanText);
        utterance.rate = speechRate;
        utterance.onstart = () => {
          setIsPlayingAudio(true);
          setAudioStatus(isNativeSimulated ? 'Playing site audio...' : 'Speaking aloud...');
        };
        utterance.onend = () => {
          setIsPlayingAudio(false);
          setAudioStatus('Finished speaking');
        };
        utterance.onerror = () => {
          setIsPlayingAudio(false);
        };
        window.speechSynthesis.speak(utterance);
      }
      setCurrentSpeechText(text);
      setIsPlayingAudio(true);
      setAudioStatus(isNativeSimulated ? 'Playing site audio...' : 'Speaking aloud...');
      triggerMascotReaction("Reading response aloud ✨");
    } catch (e) {
      console.warn('Speech playback error', e);
    }
  };

  const togglePlayPauseAudio = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      if (isPlayingAudio) {
        window.speechSynthesis.cancel();
        setIsPlayingAudio(false);
        setAudioStatus('Paused');
      } else if (currentSpeechText) {
        playSpeech(currentSpeechText);
      }
    }
  };

  const stopAudioPlayback = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlayingAudio(false);
    setCurrentSpeechText(null);
    triggerMascotReaction("Speech stopped");
  };

  const cycleSpeechRate = () => {
    const rates = [1.0, 1.25, 1.5, 0.8];
    const nextIdx = (rates.indexOf(speechRate) + 1) % rates.length;
    const nextRate = rates[nextIdx >= 0 ? nextIdx : 0];
    setSpeechRate(nextRate);
    saveStoredSpeechRate(nextRate);
    if (isPlayingAudio && currentSpeechText) {
      playSpeech(currentSpeechText);
    }
    triggerMascotReaction(`Playback speed: ${nextRate}x`);
  };

  const toggleAutoSpeakQuick = () => {
    const next = !isAutoSpeakEnabled;
    setIsAutoSpeakEnabled(next);
    saveStoredAutoSpeakEnabled(next);
    if (!next && isPlayingAudio) {
      stopAudioPlayback();
    }
    triggerMascotReaction(`Auto-Read Aloud: ${next ? 'Enabled' : 'Muted'}`);
  };

  const handleToggleMinimizeAudio = () => {
    const next = !isAudioMinimized;
    setIsAudioMinimized(next);
    saveStoredAudioMinimized(next);
  };

  const allAiServices = services;
  const enabledServices = services.filter(s => s.isEnabled);
  const activeAiService = services.find(s => s.id === selectedService) || enabledServices[0] || services[0] || BUILT_IN_SERVICES[0];

  const handleAddCustomAi = (name: string, url: string) => {
    let norm = url.trim();
    if (!norm) return;
    if (!norm.startsWith('http://') && !norm.startsWith('https://')) {
      norm = 'https://' + norm;
    }
    const newService: AssistService = {
      id: 'custom_' + Date.now(),
      name: name.trim() || 'Custom Website',
      url: norm,
      category: 'custom',
      color: '#8AB4F8',
      isCustom: true,
      isEnabled: true,
      openInApp: false,
      searchUrlTemplate: norm.includes('{q}') ? norm : `${norm}?q={q}`
    };
    const updated = [newService, ...services];
    setServices(updated);
    saveStoredServices(updated);
    setSelectedService(newService.id);
    setShowAddAiModal(false);
    setNewAiName('');
    setNewAiUrl('');
    triggerMascotReaction(`Added ${newService.name} chip!`);
  };

  const handleRemoveCustomAi = (id: string) => {
    const target = services.find(s => s.id === id);
    const updated = services.filter(s => s.id !== id);
    setServices(updated);
    saveStoredServices(updated);
    if (selectedService === id) {
      setSelectedService('gemini');
    }
    triggerMascotReaction(`Removed ${target?.name || 'custom chip'}`);
  };

  const speechRecognitionRef = useRef<any>(null);
  const accumulatedTranscriptRef = useRef<string>('');
  const baseTextRef = useRef<string>('');
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('portrait');
  const [isDarkMode, setIsDarkMode] = useState(propDarkMode ?? true);
  const [navType, setNavType] = useState<'3-button' | 'gesture'>('3-button');

  useEffect(() => {
    if (propDarkMode !== undefined) {
      setIsDarkMode(propDarkMode);
    }
  }, [propDarkMode]);

  const handleToggleDarkMode = (val?: boolean) => {
    const next = typeof val === 'boolean' ? val : !isDarkMode;
    setIsDarkMode(next);
    onToggleDarkMode?.(next);
  };

  const theme = {
    isDark: isDarkMode,
    bg: isDarkMode ? '#121214' : '#F8FAFC',
    card: isDarkMode ? '#202124' : '#FFFFFF',
    surfaceHi: isDarkMode ? '#3C4043' : '#F1F5F9',
    surfacePill: isDarkMode ? '#202124' : '#FFFFFF',
    accent: isDarkMode ? '#8AB4F8' : '#1D4ED8',
    onAccent: isDarkMode ? '#0B1B3D' : '#FFFFFF',
    text: isDarkMode ? '#F8FAFC' : '#0F172A',
    muted: isDarkMode ? '#94A3B8' : '#334155',
    border: isDarkMode ? 'rgba(255, 255, 255, 0.12)' : '#CBD5E1',
  };

  const [scale, setScale] = useState(1);
  const [panY, setPanY] = useState(0);
  const [panX, setPanX] = useState(0);
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });
  const [autoStartMic] = useState(false);
  const [autoAttach, setAutoAttach] = useState(true);
  const [selectedEngine, setSelectedEngine] = useState('local_model');
  const [processingMode] = useState<'post_processing' | 'real_time'>('post_processing');
  const [isTranscribing, setIsTranscribing] = useState(false);

  const [loadedModels] = useState<Array<{ id: string; name: string; sizeMb: string }>>([
    { id: 'm1', name: 'whisper-base-hinglish.bin', sizeMb: '73.8 MB' },
    { id: 'm2', name: 'whisper-small-hindi.bin', sizeMb: '142.1 MB' },
    { id: 'm3', name: 'whisper-tiny-en.onnx', sizeMb: '39.0 MB' }
  ]);
  const [defaultModelId, setDefaultModelId] = useState('m1');
  const [langModelMap, setLangModelMap] = useState<Record<string, string>>({
    hinglish: 'm1',
    hi: 'm2',
    en: 'm3'
  });
  const [testTextBoxValue, setTestTextBoxValue] = useState('');

  const getActiveModel = () => {
    const assignedId = langModelMap[voiceLang] || defaultModelId;
    return loadedModels.find(m => m.id === assignedId) || loadedModels[0] || null;
  };

  const getEngineChipLabel = () => {
    if (selectedEngine === 'local_model') {
      const m = getActiveModel();
      return m ? `Local (${m.name.split('.')[0].slice(0, 8)})` : 'Local Whisper';
    }
    if (selectedEngine === 'google_tts') return 'Google';
    if (selectedEngine === 'futo_voice_input') return 'FUTO';
    return 'Default';
  };

  const cycleModel = () => {
    if (loadedModels.length === 0) return;
    const current = getActiveModel();
    const currentIndex = loadedModels.findIndex(m => m.id === current?.id);
    const nextIndex = (currentIndex + 1) % loadedModels.length;
    const nextModel = loadedModels[nextIndex];
    setDefaultModelId(nextModel.id);
    setLangModelMap(prev => ({ ...prev, [voiceLang]: nextModel.id }));
  };

  const [chatMessages, setChatMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string; image?: string; autoAttached?: boolean }>>([
    {
      role: 'assistant',
      text: 'Hello! I am ready. You can circle anything on your screen, dictate in English, Hindi, or Hinglish, and attachments will be auto-injected right into this chat box.',
    }
  ]);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pointsRef = useRef<Array<{ x: number; y: number }>>([]);
  const boxStartRef = useRef<{ x: number; y: number } | null>(null);
  const boxEndRef = useRef<{ x: number; y: number } | null>(null);

  type HandlePosition = 'nw' | 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w';
  interface DragState {
    mode: 'none' | 'draw' | 'resize' | 'move';
    handle: HandlePosition | null;
    startX: number;
    startY: number;
    origMinX: number;
    origMinY: number;
    origMaxX: number;
    origMaxY: number;
  }
  const dragStateRef = useRef<DragState>({
    mode: 'none',
    handle: null,
    startX: 0,
    startY: 0,
    origMinX: 0,
    origMinY: 0,
    origMaxX: 0,
    origMaxY: 0
  });
  const [canvasCursor, setCanvasCursor] = useState<string>('crosshair');

  const getBoxCoords = () => {
    if (!boxStartRef.current || !boxEndRef.current) return null;
    const minX = Math.min(boxStartRef.current.x, boxEndRef.current.x);
    const minY = Math.min(boxStartRef.current.y, boxEndRef.current.y);
    const maxX = Math.max(boxStartRef.current.x, boxEndRef.current.x);
    const maxY = Math.max(boxStartRef.current.y, boxEndRef.current.y);
    const w = maxX - minX;
    const h = maxY - minY;
    if (w < 6 || h < 6) return null;
    return { minX, minY, maxX, maxY, w, h };
  };

  const getHandles = (coords: { minX: number; minY: number; maxX: number; maxY: number; w: number; h: number }) => {
    const { minX, minY, maxX, maxY, w, h } = coords;
    return [
      { pos: 'nw' as HandlePosition, x: minX, y: minY, cursor: 'nwse-resize' },
      { pos: 'n' as HandlePosition, x: minX + w / 2, y: minY, cursor: 'ns-resize' },
      { pos: 'ne' as HandlePosition, x: maxX, y: minY, cursor: 'nesw-resize' },
      { pos: 'e' as HandlePosition, x: maxX, y: minY + h / 2, cursor: 'ew-resize' },
      { pos: 'se' as HandlePosition, x: maxX, y: maxY, cursor: 'nwse-resize' },
      { pos: 's' as HandlePosition, x: minX + w / 2, y: maxY, cursor: 'ns-resize' },
      { pos: 'sw' as HandlePosition, x: minX, y: maxY, cursor: 'nesw-resize' },
      { pos: 'w' as HandlePosition, x: minX, y: minY + h / 2, cursor: 'ew-resize' },
    ];
  };

  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const width = canvas.width;
    const height = canvas.height;

    ctx.save();
    ctx.clearRect(0, 0, width, height);
    ctx.translate(panX, panY);
    ctx.scale(scale, scale);

    ctx.fillStyle = isDarkMode ? '#121214' : '#F8FAFC';
    ctx.fillRect(0, 0, width, height);

    ctx.fillStyle = isDarkMode ? '#1E1E24' : '#FFFFFF';
    ctx.fillRect(16, 20, width - 32, 70);

    ctx.fillStyle = isDarkMode ? '#8AB4F8' : '#1D4ED8';
    ctx.font = 'bold 15px sans-serif';
    ctx.fillText('Universal Android 10+   All ROMs & Devices', 28, 48);

    ctx.fillStyle = isDarkMode ? '#9AA0A6' : '#475569';
    ctx.font = '11px sans-serif';
    ctx.fillText('Long-press Home gesture detected   Overlay Active', 28, 68);

    let currentY = 110;
    SAMPLE_SCREEN_TEXT.forEach((item) => {
      if (item.type === 'header') {
        ctx.fillStyle = isDarkMode ? '#FFFFFF' : '#0F172A';
        ctx.font = 'bold 16px sans-serif';
        ctx.fillText(item.text, 20, currentY);
        currentY += 24;
      } else if (item.type === 'meta') {
        ctx.fillStyle = isDarkMode ? '#8AB4F8' : '#2563EB';
        ctx.font = '11px sans-serif';
        ctx.fillText(item.text, 20, currentY);
        currentY += 20;
      } else if (item.type === 'callout') {
        ctx.fillStyle = isDarkMode ? '#1F2937' : '#EFF6FF';
        ctx.roundRect(16, currentY - 14, width - 32, 42, 8);
        ctx.fill();
        ctx.strokeStyle = isDarkMode ? '#38BDF8' : '#3B82F6';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.fillStyle = isDarkMode ? '#7DD3FC' : '#1E40AF';
        ctx.font = '12px monospace';
        ctx.fillText(item.text, 26, currentY + 12);
        currentY += 50;
      } else {
        ctx.fillStyle = isDarkMode ? '#E8EAED' : '#1E293B';
        ctx.font = '13px sans-serif';
        const words = item.text.split(' ');
        let line = '';
        for (let n = 0; n < words.length; n++) {
          const testLine = line + words[n] + ' ';
          const metrics = ctx.measureText(testLine);
          if (metrics.width > width - 48 && n > 0) {
            ctx.fillText(line, 20, currentY);
            line = words[n] + ' ';
            currentY += 18;
          } else {
            line = testLine;
          }
        }
        ctx.fillText(line, 20, currentY);
        currentY += 26;
      }
    });
    ctx.restore();

    if (boxStartRef.current && boxEndRef.current) {
      const minX = Math.min(boxStartRef.current.x, boxEndRef.current.x);
      const minY = Math.min(boxStartRef.current.y, boxEndRef.current.y);
      const maxX = Math.max(boxStartRef.current.x, boxEndRef.current.x);
      const maxY = Math.max(boxStartRef.current.y, boxEndRef.current.y);
      const boxW = maxX - minX;
      const boxH = maxY - minY;

      if (boxW > 10 && boxH > 10) {
        ctx.fillStyle = isDarkMode ? 'rgba(0, 0, 0, 0.55)' : 'rgba(15, 23, 42, 0.45)';
        ctx.fillRect(0, 0, width, height);
        ctx.clearRect(minX, minY, boxW, boxH);

        ctx.save();
        ctx.beginPath();
        ctx.rect(minX, minY, boxW, boxH);
        ctx.clip();
        ctx.translate(panX, panY);
        ctx.scale(scale, scale);
        ctx.fillStyle = isDarkMode ? '#121214' : '#F8FAFC';
        ctx.fillRect(0, 0, width, height);
        ctx.fillStyle = isDarkMode ? '#1E1E24' : '#FFFFFF';
        ctx.fillRect(16, 20, width - 32, 70);
        ctx.fillStyle = isDarkMode ? '#8AB4F8' : '#1D4ED8';
        ctx.font = 'bold 15px sans-serif';
        ctx.fillText('Universal Android 10+   All ROMs & Devices', 28, 48);
        ctx.restore();

        ctx.strokeStyle = '#8AB4F8';
        ctx.lineWidth = 2.5;
        ctx.strokeRect(minX, minY, boxW, boxH);

        const handles = [
          { pos: 'nw', x: minX, y: minY },
          { pos: 'n', x: minX + boxW / 2, y: minY },
          { pos: 'ne', x: maxX, y: minY },
          { pos: 'w', x: minX, y: minY + boxH / 2 },
          { pos: 'e', x: maxX, y: minY + boxH / 2 },
          { pos: 'sw', x: minX, y: maxY },
          { pos: 's', x: minX + boxW / 2, y: maxY },
          { pos: 'se', x: maxX, y: maxY }
        ];

        handles.forEach((h) => {
          const isActive = dragStateRef.current.handle === h.pos;
          ctx.beginPath();
          ctx.arc(h.x, h.y, isActive ? 8 : 6.5, 0, Math.PI * 2);
          ctx.fillStyle = isActive ? '#D2E3FC' : '#FFFFFF';
          ctx.fill();
          ctx.strokeStyle = '#8AB4F8';
          ctx.lineWidth = 2.5;
          ctx.stroke();
        });
      }
    } else {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
      ctx.fillRect(0, 0, width, height);
    }

    if (selectShape === 'circle' && pointsRef.current.length > 1) {
      ctx.beginPath();
      ctx.moveTo(pointsRef.current[0].x, pointsRef.current[0].y);
      for (let i = 1; i < pointsRef.current.length; i++) {
        ctx.lineTo(pointsRef.current[i].x, pointsRef.current[i].y);
      }
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.lineWidth = 14;
      ctx.strokeStyle = 'rgba(138, 180, 248, 0.45)';
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(pointsRef.current[0].x, pointsRef.current[0].y);
      for (let i = 1; i < pointsRef.current.length; i++) {
        ctx.lineTo(pointsRef.current[i].x, pointsRef.current[i].y);
      }
      ctx.lineWidth = 3.5;
      ctx.strokeStyle = '#FFFFFF';
      ctx.stroke();
    }
  }, [panX, panY, scale, selectShape, isDarkMode]);

  useEffect(() => {
    renderCanvas();
  }, [renderCanvas]);

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (isPanning) {
      dragStateRef.current = {
        mode: 'move',
        handle: null,
        startX: x,
        startY: y,
        origMinX: 0,
        origMinY: 0,
        origMaxX: 0,
        origMaxY: 0
      };
      setPanStart({ x: e.clientX - panX, y: e.clientY - panY });
      return;
    }

    const box = getBoxCoords();
    if (box) {
      const handles = getHandles(box);
      const hitRadius = 16;
      const hitHandle = handles.find(h => Math.hypot(x - h.x, y - h.y) <= hitRadius);
      if (hitHandle) {
        dragStateRef.current = {
          mode: 'resize',
          handle: hitHandle.pos,
          startX: x,
          startY: y,
          origMinX: box.minX,
          origMinY: box.minY,
          origMaxX: box.maxX,
          origMaxY: box.maxY
        };
        pointsRef.current = [];
        setCanvasCursor(hitHandle.cursor);
        renderCanvas();
        return;
      }
      if (x >= box.minX && x <= box.maxX && y >= box.minY && y <= box.maxY) {
        dragStateRef.current = {
          mode: 'move',
          handle: null,
          startX: x,
          startY: y,
          origMinX: box.minX,
          origMinY: box.minY,
          origMaxX: box.maxX,
          origMaxY: box.maxY
        };
        pointsRef.current = [];
        setCanvasCursor('move');
        renderCanvas();
        return;
      }
    }

    dragStateRef.current = {
      mode: 'draw',
      handle: null,
      startX: x,
      startY: y,
      origMinX: 0,
      origMinY: 0,
      origMaxX: 0,
      origMaxY: 0
    };

    if (selectShape === 'circle') {
      pointsRef.current = [{ x, y }];
      boxStartRef.current = null;
      boxEndRef.current = null;
    } else {
      boxStartRef.current = { x, y };
      boxEndRef.current = { x, y };
      pointsRef.current = [];
    }
    setCanvasCursor('crosshair');
    renderCanvas();
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (isPanning && dragStateRef.current.mode !== 'none') {
      setPanX(e.clientX - panStart.x);
      setPanY(e.clientY - panStart.y);
      renderCanvas();
      return;
    }

    if (dragStateRef.current.mode === 'none') {
      if (isPanning) {
        setCanvasCursor('grab');
      } else {
        const box = getBoxCoords();
        if (box) {
          const handles = getHandles(box);
          const hitRadius = 16;
          const hitHandle = handles.find(h => Math.hypot(x - h.x, y - h.y) <= hitRadius);
          if (hitHandle) {
            setCanvasCursor(hitHandle.cursor);
          } else if (x >= box.minX && x <= box.maxX && y >= box.minY && y <= box.maxY) {
            setCanvasCursor('move');
          } else {
            setCanvasCursor('crosshair');
          }
        } else {
          setCanvasCursor('crosshair');
        }
      }
      return;
    }

    const { mode, handle, startX, startY, origMinX, origMinY, origMaxX, origMaxY } = dragStateRef.current;
    const dx = x - startX;
    const dy = y - startY;
    const maxW = canvas.width;
    const maxH = canvas.height;

    if (mode === 'resize' && handle) {
      let newMinX = origMinX;
      let newMinY = origMinY;
      let newMaxX = origMaxX;
      let newMaxY = origMaxY;

      if (handle.includes('w')) {
        newMinX = Math.max(0, Math.min(origMaxX - 12, origMinX + dx));
      }
      if (handle.includes('e')) {
        newMaxX = Math.min(maxW, Math.max(origMinX + 12, origMaxX + dx));
      }
      if (handle.includes('n')) {
        newMinY = Math.max(0, Math.min(origMaxY - 12, origMinY + dy));
      }
      if (handle.includes('s')) {
        newMaxY = Math.min(maxH, Math.max(origMinY + 12, origMaxY + dy));
      }

      boxStartRef.current = { x: newMinX, y: newMinY };
      boxEndRef.current = { x: newMaxX, y: newMaxY };
      pointsRef.current = [];
      renderCanvas();
    } else if (mode === 'move') {
      const clampedDx = Math.max(-origMinX, Math.min(maxW - origMaxX, dx));
      const clampedDy = Math.max(-origMinY, Math.min(maxH - origMinY, dy));
      boxStartRef.current = { x: origMinX + clampedDx, y: origMinY + clampedDy };
      boxEndRef.current = { x: origMaxX + clampedDx, y: origMaxY + clampedDy };
      pointsRef.current = [];
      renderCanvas();
    } else if (mode === 'draw') {
      if (selectShape === 'circle') {
        pointsRef.current.push({ x, y });
      } else {
        boxEndRef.current = { x, y };
      }
      renderCanvas();
    }
  };

  const handleMouseUp = () => {
    const { mode } = dragStateRef.current;
    if (mode === 'none') return;

    if (mode === 'draw' && selectShape === 'circle' && pointsRef.current.length > 2) {
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      pointsRef.current.forEach((p) => {
        minX = Math.min(minX, p.x);
        minY = Math.min(minY, p.y);
        maxX = Math.max(maxX, p.x);
        maxY = Math.max(maxY, p.y);
      });
      const pad = 8;
      boxStartRef.current = { x: Math.max(0, minX - pad), y: Math.max(0, minY - pad) };
      boxEndRef.current = {
        x: Math.min(canvasRef.current?.width || 346, maxX + pad),
        y: Math.min(canvasRef.current?.height || 460, maxY + pad)
      };
      pointsRef.current = [];
    }

    const prevMode = dragStateRef.current.mode;
    dragStateRef.current = {
      mode: 'none',
      handle: null,
      startX: 0,
      startY: 0,
      origMinX: 0,
      origMinY: 0,
      origMaxX: 0,
      origMaxY: 0
    };

    if (prevMode !== 'none') {
      generateCrop();
    }
    renderCanvas();
  };

  const generateCrop = () => {
    const canvas = canvasRef.current;
    if (!canvas || !boxStartRef.current || !boxEndRef.current) return;
    const minX = Math.min(boxStartRef.current.x, boxEndRef.current.x);
    const minY = Math.min(boxStartRef.current.y, boxEndRef.current.y);
    const boxW = Math.max(10, Math.abs(boxEndRef.current.x - boxStartRef.current.x));
    const boxH = Math.max(10, Math.abs(boxEndRef.current.y - boxStartRef.current.y));

    const offscreen = document.createElement('canvas');
    offscreen.width = boxW;
    offscreen.height = boxH;
    const offCtx = offscreen.getContext('2d');
    if (!offCtx) return;
    offCtx.drawImage(canvas, minX, minY, boxW, boxH, 0, 0, boxW, boxH);
    const dataUrl = offscreen.toDataURL('image/png');
    setSelectionCrop(dataUrl);
    setCopyFeedback(true);
    setTimeout(() => setCopyFeedback(false), 2200);
  };

  const handleCopyManual = () => {
    if (!selectionCrop) {
      setSpeechError('Please draw a selection circle or box on the screen first.');
      setTimeout(() => setSpeechError(null), 3000);
      return;
    }
    setCopyFeedback(true);
    setTimeout(() => setCopyFeedback(false), 2200);
  };

  const handleSelectAll = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    boxStartRef.current = { x: 0, y: 0 };
    boxEndRef.current = { x: canvas.width, y: canvas.height };
    pointsRef.current = [];
    generateCrop();
    renderCanvas();
  };

  const handleAutoCircleDemo = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setSelectShape('circle');
    boxStartRef.current = { x: 16, y: 100 };
    boxEndRef.current = { x: canvas.width - 20, y: 165 };
    pointsRef.current = [];
    generateCrop();
    renderCanvas();
    setPromptText("Explain quantum supercomputing milestone formula");
  };

  const handleResetView = () => {
    setScale(1);
    setPanX(0);
    setPanY(0);
    boxStartRef.current = null;
    boxEndRef.current = null;
    pointsRef.current = [];
    setSelectionCrop(null);
    renderCanvas();
  };

  const applyOutputText = (txt: string) => {
    const clean = txt.trim();
    if (!clean) return;
    const base = baseTextRef.current.trim();
    const combined = base ? `${base} ${clean}` : clean;
    if (screenMode === 'settings') {
      setTestTextBoxValue(combined);
    } else {
      setPromptText(combined);
    }
  };

  const toggleListening = () => {
    setSpeechError(null);
    if (isListening) {
      setIsListening(false);
      setIsTranscribing(true);
      setTimeout(() => {
        let finalRaw = accumulatedTranscriptRef.current.trim();
        if (!finalRaw) {
          finalRaw = voiceLang === 'hi'
            ? 'इस स्क्रीन को एक्सप्लेन करें'
            : voiceLang === 'hinglish'
            ? 'Mujhe is concept ke baare mein explain karo'
            : 'Explain this quantum computing architecture in simple terms';
        }
        if (finalRaw) {
          const out = voiceLang === 'hinglish' ? toHinglish(finalRaw) : finalRaw;
          applyOutputText(out);
        }
        setIsTranscribing(false);
      }, 700);
      return;
    }

    setIsTranscribing(false);
    accumulatedTranscriptRef.current = '';
    const currentBase = (screenMode === 'settings' ? testTextBoxValue : promptText).trim();
    baseTextRef.current = currentBase;

    setIsListening(true);
    setTimeout(() => {
      accumulatedTranscriptRef.current = voiceLang === 'hi'
        ? 'इस स्क्रीन को एक्सप्लेन करें'
        : voiceLang === 'hinglish'
        ? 'Mujhe is concept ke baare mein explain karo'
        : 'Explain this quantum computing architecture in simple terms';
    }, 300);
  };

  const handleSendToAi = (serviceToUse?: AssistService) => {
    if (!promptText.trim() && !selectionCrop) return;
    const currentCrop = selectionCrop;
    const currentPrompt = promptText.trim() || 'Analyze this selected image area.';
    const targetService = serviceToUse || activeAiService;

    // 1. If Open in App is enabled, trigger non-intrusive mascot notification
    if (targetService.openInApp) {
      setMissingAppPrompt({
        service: targetService,
        query: currentPrompt
      });
    }

    // 2. Direct search vs AI URL computation
    const searchUrl = getSearchUrl(targetService, currentPrompt);
    const uniqueChatUrl = targetService.category === 'ai'
      ? `${targetService.url}${targetService.url.includes("?") ? "&" : "/"}c/${Math.random().toString(36).substring(2, 9)}`
      : searchUrl;

    setCurrentWebUrl(uniqueChatUrl);
    setBaseChatUrl(uniqueChatUrl);
    setIsExternalDocOpen(false);

    // 3. Respect 100% On-Device Local History preference
    if (isLocalHistoryEnabled) {
      const newHistItem: HistoryItem = {
        id: 'h_' + Date.now(),
        query: currentPrompt,
        serviceName: targetService.name,
        timestamp: Date.now(),
        url: uniqueChatUrl
      };
      setAssistantHistory(prev => [newHistItem, ...prev.filter(item => item.query !== currentPrompt)]);
    }

    setSelectedService(targetService.id);
    setScreenMode('chat');
    setAutoAttachedBadge(true);

    if (targetService.category === 'ai') {
      const newMessages = [...chatMessages, {
        role: 'user' as const,
        text: currentPrompt,
        image: currentCrop || undefined,
        autoAttached: !!currentCrop
      }];
      setChatMessages(newMessages);
      setPromptText('');

      setTimeout(() => {
        let aiResponse = `[${targetService.name} Assistant Response]\nI received your query: "${currentPrompt}"`;
        if (currentCrop) {
          aiResponse += `\n\nScreenshot attachment received and verified.`;
        }
        aiResponse += `\n\nIn the real OpenAssist Android app on your device, this prompt and cropped screenshot are automatically sent to ${targetService.name} (${targetService.url}) via accessibility and synthetic paste injection.`;
        setChatMessages((prev) => [
          ...prev,
          {
            role: 'assistant',
            text: aiResponse
          }
        ]);
        if (isAutoSpeakEnabled) {
          setTimeout(() => {
            playSpeech(aiResponse, true);
          }, 350);
        }
      }, 800);
    } else {
      setPromptText('');
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 items-start justify-center max-w-7xl mx-auto p-4">
      <div className="flex flex-col items-center">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3 bg-[#1E1F24] p-1.5 rounded-xl border border-[#2D2F36] shadow-sm w-full max-w-full">
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => setScreenMode('overlay')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                screenMode === 'overlay'
                  ? 'bg-[#8AB4F8] text-[#0A1835] font-semibold shadow'
                  : 'text-zinc-300 hover:text-white'
              }`}
            >
              Search Overlay
            </button>
            <button
              onClick={() => setScreenMode('chat')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                screenMode === 'chat'
                  ? 'bg-[#8AB4F8] text-[#0A1835] font-semibold shadow'
                  : 'text-zinc-300 hover:text-white'
              }`}
            >
              AI Web Chat
            </button>
            <button
              onClick={() => setScreenMode('settings')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                screenMode === 'settings'
                  ? 'bg-[#8AB4F8] text-[#0A1835] font-semibold shadow'
                  : 'text-zinc-300 hover:text-white'
              }`}
            >
              Settings
            </button>
            {onOpenSetupWizard && (
              <button
                onClick={onOpenSetupWizard}
                className="px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 bg-gradient-to-r from-indigo-500/25 to-blue-500/25 text-indigo-300 hover:text-white border border-indigo-500/40 shadow-sm"
                title="Launch or revisit first-time setup guide"
              >
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>Setup Wizard</span>
              </button>
            )}
            {onOpenLogoSwitcher && (
              <button
                onClick={onOpenLogoSwitcher}
                className="px-2.5 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1 bg-[#181A22] text-zinc-300 hover:text-white border border-white/10"
                title="Switch mascot or upload custom icon"
              >
                <span>Mascot</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-[#121214] p-0.5 rounded-lg border border-white/10">
              <button
                onClick={() => handleToggleDarkMode()}
                className={`px-2 py-1 rounded text-[11px] font-medium transition flex items-center gap-1 ${
                  !isDarkMode ? 'bg-amber-400 text-black font-bold shadow' : 'text-zinc-400 hover:text-white'
                }`}
                title="Toggle Light / Dark mode"
              >
                {isDarkMode ? 'Dark' : 'Light'}
              </button>
              <button
                onClick={() => setNavType(navType === '3-button' ? 'gesture' : '3-button')}
                className={`px-2 py-1 rounded text-[11px] font-medium transition flex items-center gap-1 ${
                  navType === '3-button' ? 'bg-[#8AB4F8] text-[#0A1835] font-bold shadow' : 'text-zinc-400 hover:text-white'
                }`}
                title="Toggle 3-button navigation vs gesture navigation"
              >
                {navType === '3-button' ? '3-Button' : 'Gestures'}
              </button>
            </div>
            <div className="flex items-center gap-1 bg-[#121214] p-0.5 rounded-lg border border-white/10">
              <button
                onClick={() => {
                  setOrientation('portrait');
                  setTimeout(() => renderCanvas(), 50);
                }}
                className={`px-2 py-1 rounded text-[11px] font-medium transition flex items-center gap-1 ${
                  orientation === 'portrait'
                    ? 'bg-[#8AB4F8] text-[#0A1835] font-bold shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
                title="Portrait Mode"
              >
                Portrait
              </button>
              <button
                onClick={() => {
                  setOrientation('landscape');
                  setTimeout(() => renderCanvas(), 50);
                }}
                className={`px-2 py-1 rounded text-[11px] font-medium transition flex items-center gap-1 ${
                  orientation === 'landscape'
                    ? 'bg-[#8AB4F8] text-[#0A1835] font-bold shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
                title="Landscape Mode"
              >
                Landscape
              </button>
            </div>
          </div>
        </div>

        <div className={`relative ${
          orientation === 'landscape' ? 'w-[740px] h-[395px]' : 'w-[370px] h-[720px]'
        } bg-[#121214] rounded-[44px] p-3 shadow-2xl border-[6px] border-[#2A2B32] overflow-hidden flex flex-col ring-1 ring-white/10 transition-all duration-300`}>
          {orientation === 'landscape' ? (
            <div className="absolute left-2.5 top-1/2 -translate-y-1/2 flex flex-col items-center gap-2 z-50 pointer-events-none" title="Camera Cutout">
              <div className="w-3.5 h-3.5 bg-[#1F2026] rounded-full border border-[#3A3B44] shadow-inner" />
              <div className="h-6 w-1 bg-[#2A2B32] rounded-full" />
            </div>
          ) : (
            <div className="absolute top-2 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 select-none pointer-events-none" title="Camera Cutout">
              <div className="w-10 h-3 bg-[#2A2B32] rounded-full" />
              <div className="w-3.5 h-3.5 bg-[#1F2026] rounded-full border border-[#3A3B44]" />
            </div>
          )}

          <div className={`h-6 flex items-center justify-between ${
            orientation === 'landscape' ? 'pl-8 pr-4' : 'px-4'
          } text-[11px] text-zinc-400 font-mono z-40 select-none`}>
            <span>9:41</span>
            <div className="flex items-center gap-1.5">
              <span>5G</span>
              <span className="text-[10px]">100%</span>
            </div>
          </div>

          <div className="relative flex-1 rounded-[32px] overflow-hidden bg-[#121214] flex flex-col">
            {screenMode === 'overlay' && (
              <div className="relative flex-1 flex flex-col">
                <div
                  className="absolute top-2 left-2 z-30 flex items-center justify-between pointer-events-auto"
                  style={{ right: orientation === 'landscape' && navType === '3-button' ? '4.5rem' : orientation === 'landscape' ? '1.5rem' : '0.5rem' }}
                >
                  <div
                    className="flex items-center gap-1.5 px-2 py-1 rounded-full shadow border transition-colors overflow-x-auto scrollbar-none max-w-[85%]"
                    style={{
                      backgroundColor: isDarkMode ? 'rgba(32, 33, 36, 0.94)' : 'rgba(255, 255, 255, 0.95)',
                      borderColor: theme.border,
                    }}
                  >
                    {showMascotChip && (
                      <div className="relative shrink-0">
                        <button
                          onClick={(e) => {
                            petMascot(e);
                            setShowMascotMenu(!showMascotMenu);
                          }}
                          className={`flex items-center gap-1 pl-1 pr-2 py-0.5 rounded-full text-[11px] font-bold transition active:scale-95 border ${
                            showMascotMenu
                              ? 'bg-indigo-600 text-white border-indigo-400 shadow-md'
                              : 'bg-gradient-to-r from-indigo-500/25 to-purple-500/25 text-indigo-300 hover:text-white border-indigo-500/35 hover:border-indigo-400'
                          }`}
                          title="Tap to pet mascot and discover cute tips!"
                        >
                          <div className="w-5 h-5 rounded-full bg-black/50 flex items-center justify-center p-0.5 shrink-0 overflow-hidden shadow-inner">
                            <OpenAssistLogo style={logoStyle} size={16} theme="dark" customIcons={customIcons} />
                          </div>
                          <span className="text-[10px] tracking-tight">
                            {typeof logoStyle === 'string' && logoStyle.startsWith('custom:')
                              ? 'Custom'
                              : logoStyle === 'owl-orbital' || logoStyle === 'owl' || (typeof logoStyle === 'string' && logoStyle.startsWith('owl'))
                              ? 'Ozzy'
                              : logoStyle === 'fox' || (typeof logoStyle === 'string' && logoStyle.startsWith('fox'))
                              ? 'Pip'
                              : logoStyle === 'bat'
                              ? 'Echo'
                              : logoStyle === 'otter'
                              ? 'Nova'
                              : logoStyle === 'chameleon'
                              ? 'Pico'
                              : logoStyle === 'tanuki'
                              ? 'Taro'
                              : logoStyle === 'sprite'
                              ? 'Ollie'
                              : logoStyle === 'kitten'
                              ? 'Byte'
                              : logoStyle === 'firefly'
                              ? 'Lumi'
                              : logoStyle === 'axolotl'
                              ? 'Kiko'
                              : logoStyle === 'whale'
                              ? 'Moby'
                              : String(logoStyle).toUpperCase()}
                          </span>
                          <Sparkles className="w-2.5 h-2.5 text-amber-300 shrink-0 animate-pulse" />
                        </button>
                      </div>
                    )}
                    <button
                      onClick={handleCopyManual}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium transition shrink-0"
                      style={{ backgroundColor: theme.surfaceHi, color: theme.text }}
                    >
                      <Copy className="w-3 h-3" />
                      Copy
                    </button>
                    <button
                      onClick={handleSelectAll}
                      className="px-2.5 py-1 rounded-full text-[11px] font-medium transition shrink-0"
                      style={{ backgroundColor: theme.surfaceHi, color: theme.text }}
                    >
                      Whole
                    </button>
                    <button
                      onClick={() => setSelectShape(selectShape === 'circle' ? 'box' : 'circle')}
                      className="px-2.5 py-1 rounded-full text-[11px] font-medium transition shrink-0"
                      style={{
                        backgroundColor: selectShape === 'circle' ? theme.accent : theme.surfaceHi,
                        color: selectShape === 'circle' ? theme.onAccent : theme.text,
                        fontWeight: selectShape === 'circle' ? 700 : 500,
                      }}
                    >
                      {selectShape === 'circle' ? 'Circle' : 'Box'}
                    </button>
                    <button
                      onClick={handleResetView}
                      className="px-2.5 py-1 rounded-full text-[11px] font-medium transition shrink-0"
                      style={{ backgroundColor: theme.surfaceHi, color: theme.text }}
                    >
                      Fit
                    </button>
                  </div>
                  <button
                    onClick={() => setScreenMode('chat')}
                    className="p-1.5 rounded-full shadow transition shrink-0"
                    style={{ backgroundColor: theme.surfaceHi, color: theme.text }}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {showSpeechBubble && (
                  <div
                    className={`pointer-events-auto transition-all animate-in fade-in duration-200 z-20 ${
                      orientation === 'landscape'
                        ? 'absolute top-10 left-2 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#181A26]/95 border border-indigo-500/40 text-[11px] text-zinc-100 shadow-xl max-w-[420px]'
                        : 'absolute top-11 left-2 flex items-center gap-1.5 px-2.5 py-1 rounded-2xl bg-[#181A26]/95 backdrop-blur-md border border-indigo-500/40 text-[10px] text-zinc-100 shadow-xl max-w-[290px]'
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-ping shrink-0" />
                    <span className="truncate font-semibold tracking-tight">{getSpeechBubbleText()}</span>
                  </div>
                )}

                <div className="relative flex-1 overflow-hidden">
                  <canvas
                    ref={canvasRef}
                    width={orientation === 'landscape' ? 716 : 346}
                    height={orientation === 'landscape' ? 330 : 460}
                    style={{ cursor: canvasCursor }}
                    className="w-full h-full block select-none"
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseUp}
                  />
                  {!selectionCrop && (
                    <div
                      className="absolute top-20 left-1/2 -translate-x-1/2 pointer-events-none px-4 py-1.5 rounded-full border text-xs shadow"
                      style={{
                        backgroundColor: isDarkMode ? 'rgba(32, 33, 36, 0.9)' : 'rgba(255, 255, 255, 0.95)',
                        borderColor: theme.border,
                        color: theme.text,
                      }}
                    >
                      {isPanning ? 'Drag canvas to pan' : 'Circle or box any element on screen'}
                    </div>
                  )}
                </div>

                <div
                  className={`p-3 backdrop-blur-md flex flex-col gap-2 transition-all ${
                    orientation === 'landscape'
                      ? 'max-w-[440px] w-full mr-auto ml-3 mb-3 rounded-2xl shadow-2xl border'
                      : 'w-full border-t'
                  }`}
                  style={{
                    backgroundColor: isDarkMode ? 'rgba(24, 25, 28, 0.95)' : 'rgba(245, 246, 248, 0.95)',
                    borderColor: theme.border,
                  }}
                >
                  {selectionCrop && (
                    <div
                      className="flex items-center justify-between p-1.5 rounded-xl border"
                      style={{ backgroundColor: theme.card, borderColor: theme.border }}
                    >
                      <div className="flex items-center gap-2">
                        <img
                          src={selectionCrop}
                          alt="Selection Crop"
                          className="w-9 h-9 object-cover rounded-lg border bg-black"
                          style={{ borderColor: theme.border }}
                        />
                        <div className="text-left">
                          <p className="text-[11px] font-medium" style={{ color: theme.text }}>Selection attached</p>
                          <p className="text-[9px]" style={{ color: theme.accent }}>PNG   Ready for AI injection</p>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setSelectionCrop(null);
                          boxStartRef.current = null;
                          boxEndRef.current = null;
                          renderCanvas();
                        }}
                        className="p-1 rounded-full text-zinc-400 hover:text-white"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  {/* Category Filter Tabs */}
                  <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none select-none text-[10px]">
                    {(['all', 'ai', 'search', 'social', 'productivity'] as ServiceCategory[]).map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setActiveCategoryFilter(cat)}
                        className={`px-2 py-0.5 rounded-full font-semibold whitespace-nowrap transition ${
                          activeCategoryFilter === cat
                            ? 'bg-indigo-600 text-white shadow-xs'
                            : theme.isDark
                            ? 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                            : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                        }`}
                      >
                        {cat === 'all' ? 'All' : cat === 'ai' ? 'AI Models' : cat === 'search' ? 'Search' : cat === 'social' ? 'Social' : 'Tools'}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                    <button
                      onClick={() => {
                        const next: Record<VoiceLang, VoiceLang> = {
                          en: 'hi',
                          hi: 'hinglish',
                          hinglish: 'en',
                        };
                        setVoiceLang(next[voiceLang]);
                      }}
                      className="px-2.5 py-1 rounded-full text-[10px] font-bold transition whitespace-nowrap"
                      style={{ backgroundColor: theme.surfaceHi, color: theme.accent }}
                    >
                      {voiceLang === 'en' ? 'EN' : voiceLang === 'hi' ? 'HI' : 'Hinglish'}
                    </button>
                    <button
                      onClick={() => {
                        if (selectedEngine === 'local_model') {
                          setSelectedEngine('google_tts');
                        } else if (selectedEngine === 'google_tts') {
                          setSelectedEngine('futo_voice_input');
                        } else {
                          setSelectedEngine('local_model');
                        }
                      }}
                      className="px-2.5 py-1 rounded-full text-[10px] font-bold transition whitespace-nowrap"
                      style={{
                        backgroundColor: selectedEngine === 'local_model' ? theme.accent : theme.surfaceHi,
                        color: selectedEngine === 'local_model' ? theme.onAccent : theme.text,
                      }}
                    >
                      {getEngineChipLabel()}
                    </button>
                    {enabledServices
                      .filter(s => activeCategoryFilter === 'all' || s.category === activeCategoryFilter)
                      .map((s) => (
                        <button
                          key={s.id}
                          onClick={() => {
                            setSelectedService(s.id);
                            if (promptText.trim()) {
                              handleSendToAi(s);
                            }
                          }}
                          className="px-2.5 py-0.5 rounded-full text-[11px] whitespace-nowrap transition flex items-center gap-1 shrink-0"
                          style={{
                            backgroundColor: selectedService === s.id ? theme.accent : theme.surfaceHi,
                            color: selectedService === s.id ? theme.onAccent : theme.text,
                            fontWeight: selectedService === s.id ? 600 : 400,
                          }}
                          title={s.openInApp ? `${s.name} (Opens in native app if installed)` : `${s.name} (Opens in WebView)`}
                        >
                          <span>{s.name}</span>
                          {s.openInApp && <span className="text-[9px] opacity-80">↗</span>}
                        </button>
                      ))}

                    {/* Manage Chips Button */}
                    <button
                      onClick={() => setShowChipManagerModal(true)}
                      className="px-2 py-0.5 rounded-full text-[11px] font-bold border border-dashed transition hover:opacity-90 shrink-0 flex items-center gap-0.5"
                      style={{ borderColor: theme.border, color: theme.accent }}
                      title="Manage Chips (Add, Reorder, Enable/Disable)"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Chips</span>
                    </button>
                  </div>

                  <div
                    className="flex items-center gap-1.5 rounded-full px-2.5 py-1.5 border shadow-inner transition-colors"
                    style={{ backgroundColor: theme.surfacePill, borderColor: theme.border }}
                  >
                    <button
                      onClick={() => {
                        const input = document.createElement('input');
                        input.type = 'file';
                        input.accept = 'image/*';
                        input.onchange = (e: any) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = () => {
                              setSelectionCrop(reader.result as string);
                            };
                            reader.readAsDataURL(file);
                          }
                        };
                        input.click();
                      }}
                      className="p-1.5 rounded-full transition shrink-0"
                      style={{ backgroundColor: theme.surfaceHi, color: theme.text }}
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <div className="relative flex-1 flex items-center min-w-0">
                      <input
                        type="text"
                        value={promptText}
                        onChange={(e) => setPromptText(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSendToAi()}
                        placeholder={`Ask ${activeAiService.name}`}
                        style={{ color: theme.text }}
                        className="w-full bg-transparent text-xs placeholder-zinc-400 focus:outline-none px-1"
                      />
                    </div>
                    <button
                      onClick={toggleListening}
                      className="p-1.5 rounded-full transition shrink-0 shadow-sm"
                      style={{
                        backgroundColor: isListening ? theme.accent : theme.surfaceHi,
                        color: isListening ? theme.onAccent : theme.text,
                      }}
                    >
                      <Mic className="w-3.5 h-3.5" />
                    </button>
                    {(promptText.trim() || selectionCrop) && (
                      <button
                        onClick={() => handleSendToAi()}
                        className="p-1.5 rounded-full transition shrink-0 shadow font-bold"
                        style={{ backgroundColor: theme.accent, color: theme.onAccent }}
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}

            {screenMode === 'chat' && (
              <div
                className="flex-1 flex flex-col transition-colors overflow-hidden relative"
                style={{ backgroundColor: theme.bg, color: theme.text }}
              >
                {/* Modern Web Assistant Top Action Bar (Adaptive Layout, Fits Perfectly) */}
                <div
                  className="px-2 py-1.5 flex items-center justify-between border-b transition-colors shrink-0 select-none"
                  style={{ backgroundColor: theme.card, borderColor: theme.border }}
                >
                  {/* Left Controls: Mascot Chip, AI Model Selector, Language, Voice Input (Horizontally Scrollable) */}
                  <div className="flex items-center gap-1.5 min-w-0 flex-1 overflow-x-auto scrollbar-none py-0.5">
                    {/* 1. Mascot Companion Chip (Adaptive Width & Border) */}
                    <button
                      onClick={petMascot}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold border transition hover:scale-105 active:scale-95 shrink-0 whitespace-nowrap box-border shadow-xs"
                      style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                      title="Mascot Companion Chip"
                    >
                      <div className="w-4 h-4 rounded-full overflow-hidden shrink-0 flex items-center justify-center">
                        <OpenAssistLogo style={logoStyle} size={15} theme={isDarkMode ? 'dark' : 'light'} customIcons={customIcons} />
                      </div>
                      <span className="leading-tight font-bold tracking-tight">
                        {ALL_SIMULATOR_MASCOTS.find(m => m.id === logoStyle)?.name?.split(' ')[0] || logoStyle.split('-')[0].toUpperCase()}
                      </span>
                    </button>

                    {/* 2. Model Switcher Pill */}
                    <div className="relative shrink-0">
                      <button
                        onClick={() => setShowModelDropdown(!showModelDropdown)}
                        className="flex items-center gap-0.5 px-2 py-1 rounded-full text-[10px] font-bold border transition hover:opacity-90 active:scale-95"
                        style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: activeAiService.color || theme.accent }}
                        title="Switch AI Web Assistant"
                      >
                        <span className="truncate max-w-[55px]">{activeAiService.name}</span>
                        <span className="text-[8px]">▾</span>
                      </button>
                      {showModelDropdown && (
                        <div
                          className="absolute left-0 top-full mt-1 w-48 rounded-xl border shadow-xl z-50 p-1.5 space-y-1 backdrop-blur-md"
                          style={{ backgroundColor: theme.card, borderColor: theme.border }}
                        >
                          <div className="text-[10px] font-bold px-2 py-1 uppercase tracking-wider" style={{ color: theme.muted }}>
                            Select AI Model
                          </div>
                          <div className="max-h-48 overflow-y-auto space-y-0.5">
                            {allAiServices.map(s => (
                              <button
                                key={s.id}
                                onClick={() => {
                                  setSelectedService(s.id);
                                  setShowModelDropdown(false);
                                  triggerMascotReaction(`Loaded ${s.name}!`);
                                }}
                                className="w-full text-left px-2 py-1 rounded-lg text-xs font-medium flex items-center justify-between transition hover:opacity-80"
                                style={{
                                  backgroundColor: selectedService === s.id ? theme.surfaceHi : 'transparent',
                                  color: selectedService === s.id ? theme.accent : theme.text
                                }}
                              >
                                <span className="truncate">{s.name}</span>
                                {selectedService === s.id && <Check className="w-3 h-3 text-emerald-400" />}
                              </button>
                            ))}
                          </div>
                          <button
                            onClick={() => {
                              setShowModelDropdown(false);
                              setShowAddAiModal(true);
                            }}
                            className="w-full text-center px-2 py-1 text-[11px] font-bold rounded-lg border border-dashed transition hover:opacity-90 mt-1"
                            style={{ borderColor: theme.border, color: theme.accent }}
                          >
                            + Add Custom AI
                          </button>
                        </div>
                      )}
                    </div>

                    {/* 3. Language Switcher Pill */}
                    <button
                      onClick={() => {
                        const nextLang: VoiceLang = voiceLang === 'en' ? 'hinglish' : voiceLang === 'hinglish' ? 'hi' : 'en';
                        setVoiceLang(nextLang);
                        triggerMascotReaction(`Language: ${nextLang.toUpperCase()}`);
                      }}
                      className="px-1.5 py-1 rounded-full text-[10px] font-semibold border transition hover:opacity-90 active:scale-95 shrink-0"
                      style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                      title="Switch Voice Language"
                    >
                      {voiceLang === 'hinglish' ? 'HING' : voiceLang.toUpperCase()}
                    </button>

                    {/* 4. Voice Input Engine Switcher Pill */}
                    <button
                      onClick={() => {
                        const nextEngine = speechEngineChoice === 'Whisper' ? 'FUTO' : speechEngineChoice === 'FUTO' ? 'Google' : speechEngineChoice === 'Google' ? 'Default' : 'Whisper';
                        setSpeechEngineChoice(nextEngine);
                        triggerMascotReaction(`Voice Engine: ${nextEngine}`);
                      }}
                      className="px-1.5 py-1 rounded-full text-[10px] font-semibold border transition hover:opacity-90 active:scale-95 shrink-0 truncate max-w-[58px]"
                      style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                      title="Switch Speech Recognition Engine"
                    >
                      {speechEngineChoice}
                    </button>
                  </div>

                  {/* Right Controls: Voice Mic, Settings, Hamburger Menu */}
                  <div className="flex items-center gap-1 shrink-0 ml-1">
                    {/* 5. Voice Dictation Mic Button */}
                    <button
                      onClick={toggleListening}
                      className="p-1.5 rounded-lg border transition hover:scale-105 active:scale-95 shrink-0"
                      style={{
                        backgroundColor: isListening ? '#EF4444' : theme.surfaceHi,
                        borderColor: theme.border,
                        color: isListening ? '#FFFFFF' : theme.text
                      }}
                      title="Voice Transcription (Mic)"
                    >
                      <Mic className="w-3.5 h-3.5" />
                    </button>

                    {/* 5B. Auto-Speak / Read Aloud Quick Toggle Button */}
                    <button
                      onClick={toggleAutoSpeakQuick}
                      className="p-1.5 rounded-lg border transition hover:scale-105 active:scale-95 shrink-0"
                      style={{
                        backgroundColor: isAutoSpeakEnabled ? (isDarkMode ? '#312E81' : '#EEF2FF') : theme.surfaceHi,
                        borderColor: isAutoSpeakEnabled ? '#6366F1' : theme.border,
                        color: isAutoSpeakEnabled ? '#818CF8' : theme.muted
                      }}
                      title={isAutoSpeakEnabled ? 'Auto-Speak Responses: Enabled (Tap to mute)' : 'Auto-Speak Responses: Muted (Tap to enable)'}
                    >
                      {isAutoSpeakEnabled ? <Volume2 className="w-3.5 h-3.5 text-indigo-400" /> : <VolumeX className="w-3.5 h-3.5 text-zinc-400" />}
                    </button>

                    {/* 6. Settings Button */}
                    <button
                      onClick={() => setScreenMode('settings')}
                      className="p-1.5 rounded-lg border transition hover:scale-105 active:scale-95 shrink-0"
                      style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                      title="Enter Settings"
                    >
                      <SettingsIcon className="w-3.5 h-3.5" />
                    </button>

                    {/* 7. Far Right: Hamburger Menu Button */}
                    <div className="relative shrink-0">
                      <button
                        onClick={() => setShowWebMenuDropdown(!showWebMenuDropdown)}
                        className="p-1.5 rounded-lg border transition hover:scale-105 active:scale-95 shrink-0"
                        style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                        title="Actions & History Menu"
                      >
                        <Menu className="w-3.5 h-3.5" />
                      </button>

                      {showWebMenuDropdown && (
                        <div
                          className="absolute right-0 top-full mt-1 w-52 rounded-xl border shadow-xl z-50 p-1.5 space-y-1 backdrop-blur-md"
                          style={{ backgroundColor: theme.card, borderColor: theme.border }}
                        >
                          <div className="text-[10px] font-bold px-2 py-1 uppercase tracking-wider" style={{ color: theme.muted }}>
                            Assistant Actions
                          </div>

                          <button
                            onClick={() => {
                              setShowWebMenuDropdown(false);
                              if (selectionCrop) {
                                const newMsg = {
                                  role: 'user' as const,
                                  text: 'Analyze circled screenshot',
                                  image: selectionCrop,
                                  autoAttached: true
                                };
                                setChatMessages(prev => [...prev, newMsg]);
                                triggerMascotReaction("Circled screenshot attached to chat!");
                                setTimeout(() => {
                                  setChatMessages(prev => [
                                    ...prev,
                                    {
                                      role: 'assistant',
                                      text: `[${activeAiService.name} Assistant Response]\nI have analyzed your attached screenshot area. All details match the screen capture.`
                                    }
                                  ]);
                                }, 700);
                              } else {
                                triggerMascotReaction("Copied screenshot to clipboard (Ready to paste)!");
                              }
                            }}
                            className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 transition hover:opacity-80"
                            style={{ backgroundColor: theme.surfaceHi, color: theme.text }}
                          >
                            <ClipboardPaste className="w-3.5 h-3.5 text-blue-400" />
                            <span>Attach Selection / Paste</span>
                          </button>

                          <button
                            onClick={() => {
                              setShowWebMenuDropdown(false);
                              setChatMessages([{
                                role: 'assistant',
                                text: `New conversation started with ${activeAiService.name}. Circle anything on screen or dictate anytime!`
                              }]);
                              triggerMascotReaction("Started new chat!");
                            }}
                            className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 transition hover:opacity-80"
                            style={{ backgroundColor: theme.surfaceHi, color: theme.text }}
                          >
                            <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Start New Chat</span>
                          </button>

                          <button
                            onClick={() => {
                              setShowWebMenuDropdown(false);
                              setShowFullHistoryModal(true);
                            }}
                            className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 transition hover:opacity-80"
                            style={{ backgroundColor: theme.surfaceHi, color: theme.text }}
                          >
                            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                            <span>Query History ({assistantHistory.length})</span>
                          </button>

                          <a
                            href={activeAiService.url}
                            target="_blank"
                            rel="noreferrer"
                            onClick={() => setShowWebMenuDropdown(false)}
                            className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 transition hover:opacity-80"
                            style={{ backgroundColor: theme.surfaceHi, color: theme.text }}
                          >
                            <Globe className="w-3.5 h-3.5 text-indigo-400" />
                            <span>Open in Browser</span>
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Non-intrusive Mascot Banner for Missing App with 1-tap setting adjustment */}
                {missingAppPrompt && (
                  <div className="mx-2.5 my-2 p-3 rounded-2xl border shadow-xl bg-gradient-to-r from-amber-500/15 via-[#1E2335] to-indigo-500/15 border-amber-500/30 text-xs shrink-0 animate-in slide-in-from-top duration-200">
                    <div className="flex items-start gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center p-1 shrink-0">
                        <OpenAssistLogo style={logoStyle} size={22} theme={isDarkMode ? 'dark' : 'light'} customIcons={customIcons} />
                      </div>
                      <div className="flex-1 min-w-0 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <p className="font-bold text-[11px] text-amber-300">
                            {ALL_SIMULATOR_MASCOTS.find(m => m.id === logoStyle)?.name || 'Ozzy'}:
                          </p>
                          <button
                            onClick={() => setMissingAppPrompt(null)}
                            className="text-zinc-400 hover:text-white p-0.5"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <p className="text-[11px] leading-relaxed text-zinc-200">
                          Hey! The <strong>{missingAppPrompt.service.name}</strong> app is not installed on your phone, so I opened your search in WebView. Would you like to turn off "Open in App" for this chip?
                        </p>
                        <div className="flex items-center gap-2 pt-1">
                          <button
                            onClick={() => {
                              const updated = services.map(s => s.id === missingAppPrompt.service.id ? { ...s, openInApp: false } : s);
                              setServices(updated);
                              saveStoredServices(updated);
                              triggerMascotReaction(`Turned off "Open in App" for ${missingAppPrompt.service.name}!`);
                              setMissingAppPrompt(null);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[10px] transition shadow"
                          >
                            Yes, Turn Off
                          </button>
                          <button
                            onClick={() => {
                              setMissingAppPrompt(null);
                              triggerMascotReaction("Kept Open in App setting.");
                            }}
                            className="px-2 py-1 rounded-lg bg-zinc-700/80 hover:bg-zinc-600 text-zinc-300 font-semibold text-[10px] transition"
                          >
                            No, Keep Setting
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Web View Container: Direct Search vs Google Docs vs AI Chat */}
                {activeAiService.category !== 'ai' ? (
                  <div className="flex-1 p-3 overflow-y-auto space-y-3">
                    <div className="p-3.5 rounded-2xl border space-y-2.5 shadow-sm" style={{ backgroundColor: theme.card, borderColor: theme.border }}>
                      <div className="flex items-center justify-between border-b pb-2" style={{ borderColor: theme.border }}>
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs" style={{ backgroundColor: activeAiService.color || theme.accent, color: '#FFF' }}>
                            {activeAiService.name.slice(0, 2)}
                          </div>
                          <div>
                            <h3 className="font-bold text-xs" style={{ color: theme.text }}>{activeAiService.name} Search Results</h3>
                            <p className="text-[10px] font-mono truncate max-w-xs" style={{ color: theme.muted }}>{currentWebUrl}</p>
                          </div>
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          Direct Query Processed
                        </span>
                      </div>

                      <div className="space-y-2 pt-1">
                        <p className="text-xs font-semibold" style={{ color: theme.text }}>
                          Direct results for: <span className="text-indigo-400 font-mono">"{promptText || 'quantum computing'}"</span>
                        </p>
                        <div className="space-y-2">
                          {[
                            { title: `${activeAiService.name}: Latest Discussions & Highlights`, snippet: `Top verified matching results for your query on ${activeAiService.name}. Direct search parameters loaded immediately without manual typing.` },
                            { title: `Video & Media Highlights - ${activeAiService.name}`, snippet: `Trending streams, uploads, and media matching your circled screen query.` },
                            { title: `Community Knowledge & Reference`, snippet: `Community perspectives, technical breakdowns, and verified citations.` },
                          ].map((res, i) => (
                            <div key={i} className="p-2.5 rounded-xl border text-xs space-y-1 hover:border-indigo-500/50 transition cursor-pointer" style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}>
                              <p className="font-bold text-blue-400 text-xs hover:underline">{res.title}</p>
                              <p className="text-[11px] leading-relaxed" style={{ color: theme.muted }}>{res.snippet}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ) : isExternalDocOpen ? (
                  <div className="flex-1 p-3 overflow-y-auto space-y-3">
                    {/* Google Docs View with Native Light Theme & Fixed Code Inversion */}
                    <div className="p-4 rounded-2xl border space-y-3 shadow-md bg-white text-slate-900 border-slate-300">
                      <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
                            📄
                          </div>
                          <div>
                            <h3 className="font-bold text-xs text-slate-900">Google Docs - Exported AI Notes</h3>
                            <p className="text-[10px] text-slate-500 font-mono">docs.google.com/document/d/export-1a2b3c</p>
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            setIsExternalDocOpen(false);
                            setCurrentWebUrl(baseChatUrl);
                          }}
                          className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 transition"
                        >
                          ← Return to Chat
                        </button>
                      </div>

                      <div className="space-y-2 text-xs leading-relaxed text-slate-800">
                        <p className="font-bold text-sm text-blue-700">Exported Gemini Response Notes</p>
                        <p className="text-[11px] text-slate-600">
                          Google Docs is rendered in its <strong>native default light theme</strong> without forced algorithmic dark inversion. Code blocks and offscreen tables are fully readable!
                        </p>

                        {/* Responsive Table with horizontal scroll */}
                        <div className="overflow-x-auto my-2 border border-slate-200 rounded-lg">
                          <table className="min-w-full text-[11px] text-left">
                            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                              <tr>
                                <th className="p-2">Model</th>
                                <th className="p-2">Fidelity</th>
                                <th className="p-2">Coherence</th>
                                <th className="p-2">Status</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-200">
                              <tr>
                                <td className="p-2 font-semibold">Qubit Array A</td>
                                <td className="p-2">99.92%</td>
                                <td className="p-2">14,200 µs</td>
                                <td className="p-2 text-emerald-600 font-bold">Stable</td>
                              </tr>
                              <tr>
                                <td className="p-2 font-semibold">Qubit Array B</td>
                                <td className="p-2">99.88%</td>
                                <td className="p-2">12,800 µs</td>
                                <td className="p-2 text-blue-600 font-bold">Active</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>

                        {/* Code block with high contrast, not pitch-black */}
                        <div className="p-3 rounded-xl bg-slate-900 text-emerald-400 font-mono text-[11px] overflow-x-auto border border-slate-700">
                          <div className="text-slate-400 text-[10px] pb-1 border-b border-slate-800 mb-1.5 flex justify-between">
                            <span>python_export.py</span>
                            <span>Clean syntax contrast</span>
                          </div>
                          <code>{`import numpy as np\ndef calculate_fidelity(qubits, coherence_time):\n    return np.mean(qubits) * np.exp(-1.0 / coherence_time)`}</code>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Simulated AI Assistant Web Page */
                  <div
                    className="flex-1 p-3 overflow-y-auto space-y-3 transition-colors"
                    style={{ backgroundColor: theme.bg }}
                  >
                    <div
                      className="p-3 rounded-2xl border text-center space-y-1 shadow-xs transition-colors"
                      style={{
                        backgroundColor: isDarkMode ? '#1E2028' : '#F1F5F9',
                        borderColor: theme.border,
                      }}
                    >
                      <div className="flex items-center justify-center gap-1.5 text-xs font-bold" style={{ color: activeAiService.color || theme.accent }}>
                        <Globe className="w-3.5 h-3.5" />
                        <span>{activeAiService.name} Web Assistant</span>
                      </div>
                      <p className="text-[10px]" style={{ color: theme.muted }}>
                        Theme: {isDarkMode ? 'Dark Mode' : 'Light Mode'} • Verified connection
                      </p>
                    </div>

                    {chatMessages.map((msg, idx) => (
                      <div
                        key={idx}
                        className={`flex flex-col ${
                          msg.role === 'user' ? 'items-end' : 'items-start'
                        }`}
                      >
                        <div
                          className="max-w-[88%] rounded-2xl p-2.5 text-xs shadow-xs"
                          style={{
                            backgroundColor:
                              msg.role === 'user'
                                ? theme.accent
                                : theme.card,
                            color:
                              msg.role === 'user'
                                ? theme.onAccent
                                : theme.text,
                            border: msg.role === 'user' ? 'none' : `1px solid ${theme.border}`,
                          }}
                        >
                          {msg.image && (
                            <div className="mb-2 overflow-hidden rounded-lg border border-black/10">
                              <img
                                src={msg.image}
                                alt="Circled screenshot attachment"
                                className="w-full max-h-40 object-cover bg-black"
                              />
                            </div>
                          )}
                          <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>

                          {/* Assistant Message Actions: Copy Response, Listen, & Export to Docs */}
                          {msg.role === 'assistant' && (
                            <div className="flex items-center gap-1.5 mt-2 pt-1 border-t border-black/5 dark:border-white/5 flex-wrap">
                              <button
                                onClick={() => {
                                  navigator.clipboard.writeText(msg.text);
                                  triggerMascotReaction("Copied response to clipboard! ✨");
                                }}
                                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold border transition hover:opacity-80 active:scale-95 cursor-pointer"
                                style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                                title="Copy Response to Clipboard"
                              >
                                <Copy className="w-3 h-3 text-indigo-400" />
                                <span>Copy</span>
                              </button>

                              <button
                                onClick={() => playSpeech(msg.text, true)}
                                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold border transition hover:opacity-80 active:scale-95 text-emerald-400 cursor-pointer"
                                style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}
                                title="Listen to response"
                              >
                                <Volume2 className="w-3 h-3 text-emerald-400" />
                                <span>Listen</span>
                              </button>

                              <button
                                onClick={() => {
                                  setIsExternalDocOpen(true);
                                  setCurrentWebUrl('https://docs.google.com/document/d/export-1a2b3c');
                                  triggerMascotReaction("Opened Google Doc (Base chat URL preserved!)");
                                }}
                                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold border transition hover:opacity-80 active:scale-95 text-blue-400 cursor-pointer"
                                style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}
                                title="Export to Google Docs"
                              >
                                <ExternalLink className="w-3 h-3" />
                                <span>Export Docs</span>
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Floating Audio Controller Bar (Expanded Pill View or Minimized Orb) */}
                {(isPlayingAudio || currentSpeechText) && (
                  !isAudioMinimized ? (
                    <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-30 flex items-center gap-1.5 px-3 py-1.5 rounded-2xl border shadow-xl bg-slate-900/95 border-slate-700/80 backdrop-blur-md text-white select-none animate-in fade-in slide-in-from-bottom duration-200">
                      <div className="flex items-center gap-1.5 pr-1.5 border-r border-slate-700/80">
                        <Volume2 className={`w-3.5 h-3.5 ${isPlayingAudio ? 'text-indigo-400 animate-pulse' : 'text-slate-400'}`} />
                        <span className="text-[10px] font-bold text-slate-200 max-w-[85px] truncate">
                          {audioStatus}
                        </span>
                      </div>
                      <button
                        onClick={togglePlayPauseAudio}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition active:scale-95 cursor-pointer"
                        title={isPlayingAudio ? 'Pause' : 'Play'}
                      >
                        {isPlayingAudio ? <Pause className="w-3.5 h-3.5 text-indigo-300" /> : <Play className="w-3.5 h-3.5 text-indigo-300" />}
                      </button>
                      <button
                        onClick={stopAudioPlayback}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-400 transition active:scale-95 cursor-pointer"
                        title="Stop speech"
                      >
                        <Square className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={cycleSpeechRate}
                        className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-300 font-bold text-[10px] transition active:scale-95 cursor-pointer"
                        title="Playback speed"
                      >
                        {speechRate}x
                      </button>
                      <button
                        onClick={handleToggleMinimizeAudio}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition active:scale-95 ml-0.5 cursor-pointer"
                        title="Minimize audio bar"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={handleToggleMinimizeAudio}
                      className="absolute bottom-3 right-3 z-30 w-10 h-10 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 border border-indigo-400/60 shadow-xl flex items-center justify-center text-white cursor-pointer hover:scale-105 active:scale-95 animate-in fade-in duration-200"
                      title="Expand audio controller"
                    >
                      <Volume2 className={`w-4 h-4 ${isPlayingAudio ? 'animate-bounce' : ''}`} />
                    </button>
                  )
                )}
              </div>
            )}

            {screenMode === 'settings' && (
              <div
                className="flex-1 flex flex-col overflow-y-auto transition-colors"
                style={{ backgroundColor: theme.bg, color: theme.text }}
              >
                {/* Settings Top Bar with Left Hamburger Menu, Center Title & Version, Right About Button */}
                <div
                  className="h-12 px-2.5 flex items-center justify-between border-b transition-colors shrink-0"
                  style={{ backgroundColor: theme.card, borderColor: theme.border }}
                >
                  <div className="flex items-center gap-1.5 min-w-0">
                    <button
                      onClick={() => setScreenMode('overlay')}
                      className="p-1 transition hover:opacity-80 shrink-0"
                      style={{ color: theme.muted }}
                      title="Back to Overlay"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    {/* Hamburger menu button to open full assistant history */}
                    <button
                      onClick={() => setShowFullHistoryModal(true)}
                      className="p-1.5 rounded-lg border transition hover:scale-105 active:scale-95 shrink-0"
                      style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                      title="View Complete AI Query History"
                    >
                      <Menu className="w-3.5 h-3.5" />
                    </button>
                    <div className="flex items-center gap-1.5 min-w-0">
                      <OpenAssistLogo style={logoStyle} size={18} theme={isDarkMode ? 'dark' : 'light'} customIcons={customIcons} />
                      <h2 className="text-xs font-bold truncate" style={{ color: theme.text }}>OpenAssist</h2>
                      <button
                        onClick={() => setShowAboutModal(true)}
                        className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30 hover:scale-105 transition"
                        title="Open About & Updates"
                      >
                        {installedAppVersion}
                      </button>
                    </div>
                  </div>

                  {/* About / Help Button on the right */}
                  <button
                    onClick={() => setShowAboutModal(true)}
                    className="p-1.5 rounded-lg border transition hover:scale-105 active:scale-95 shrink-0"
                    style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                    title="About OpenAssist & Updates"
                  >
                    <HelpCircle className="w-4 h-4 text-blue-400" />
                  </button>
                </div>

                <div className="p-3.5 space-y-3.5 text-xs">
                  {/* 1. Mascot Home Section (Avatar at top + Wholesome greeting at bottom) */}
                  <div
                    className="p-4 rounded-3xl border flex flex-col items-center text-center space-y-2.5 shadow-md transition-all"
                    style={{
                      backgroundColor: isDarkMode ? '#171A26' : '#F8FAFC',
                      borderColor: theme.border
                    }}
                  >
                    <div className="w-16 h-16 rounded-2xl p-1.5 flex items-center justify-center shadow-lg border" style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}>
                      <OpenAssistLogo style={logoStyle} size={52} theme={isDarkMode ? 'dark' : 'light'} customIcons={customIcons} />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm" style={{ color: theme.text }}>
                        {ALL_SIMULATOR_MASCOTS.find(m => m.id === logoStyle)?.name || 'Ozzy Sentinel'}
                      </h3>
                      <p className="text-[11px]" style={{ color: theme.accent }}>
                        Your Faithful Companion &amp; On-Device Guide
                      </p>
                    </div>

                    {/* Wholesome message at the bottom of the mascot */}
                    <div
                      className="w-full p-3 rounded-2xl border text-xs leading-relaxed italic"
                      style={{
                        backgroundColor: theme.card,
                        borderColor: theme.border,
                        color: theme.text
                      }}
                    >
                      "{getWholesomeGreeting(logoStyle)}"
                    </div>

                    <div className="flex items-center gap-2 w-full pt-1">
                      <button
                        onClick={() => setScreenMode('chat')}
                        className="flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition shadow"
                        style={{ backgroundColor: theme.accent, color: theme.onAccent }}
                      >
                        Launch Web Assistant
                      </button>
                      {onOpenSetupWizard && (
                        <button
                          onClick={onOpenSetupWizard}
                          className="py-1.5 px-3 rounded-xl text-xs font-semibold border transition hover:opacity-80"
                          style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                        >
                          Setup Wizard
                        </button>
                      )}
                    </div>
                  </div>

                  {/* 1B. Search & Assistant Chips Manager Card (User Customizable) */}
                  <div
                    className="p-3.5 rounded-2xl border space-y-2.5 shadow-xs"
                    style={{ backgroundColor: theme.card, borderColor: theme.border }}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5" style={{ color: theme.accent }}>
                          <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                          Search &amp; Assistant Chips
                        </p>
                        <p className="text-[10px]" style={{ color: theme.muted }}>
                          {services.filter(s => s.isEnabled).length} active chips • Reorder, toggle, or add any site
                        </p>
                      </div>
                      <button
                        onClick={() => setShowChipManagerModal(true)}
                        className="px-3 py-1.5 rounded-xl text-xs font-bold transition shadow"
                        style={{ backgroundColor: theme.accent, color: theme.onAccent }}
                      >
                        Manage Chips
                      </button>
                    </div>

                    <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none select-none">
                      {services.filter(s => s.isEnabled).slice(0, 10).map((s) => (
                        <span
                          key={s.id}
                          className="px-2 py-0.5 rounded-full text-[10px] font-medium border shrink-0 flex items-center gap-1"
                          style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                        >
                          <span>{s.name}</span>
                          {s.openInApp && <span className="text-[8px] opacity-75">↗</span>}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* 1C. 100% On-Device Local History & Privacy Controls */}
                  <div
                    className="p-3.5 rounded-2xl border space-y-2.5 shadow-xs"
                    style={{ backgroundColor: theme.card, borderColor: theme.border }}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5 text-emerald-400">
                          <Lock className="w-3.5 h-3.5" />
                          Local History (100% On-Device)
                        </p>
                        <p className="text-[10px]" style={{ color: theme.muted }}>
                          Zero cloud telemetry • All data stays in private phone memory
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          const next = !isLocalHistoryEnabled;
                          setIsLocalHistoryEnabled(next);
                          saveStoredHistoryEnabled(next);
                          triggerMascotReaction(`Local history ${next ? 'enabled' : 'disabled'}!`);
                        }}
                        className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                          isLocalHistoryEnabled ? 'bg-emerald-600' : 'bg-zinc-600'
                        }`}
                        title="Toggle 100% On-Device Local History"
                      >
                        <div
                          className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                            isLocalHistoryEnabled ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>

                    <p className="text-[10px] leading-relaxed" style={{ color: theme.muted }}>
                      {isLocalHistoryEnabled
                        ? '✅ History is enabled. Your queries and assistant links are saved strictly on this device.'
                        : '🚫 History is disabled. Zero queries or links are saved.'}
                    </p>

                    <div className="flex items-center justify-between pt-1 border-t text-[11px]" style={{ borderColor: theme.border }}>
                      <span style={{ color: theme.muted }}>Saved queries: {assistantHistory.length}</span>
                      <button
                        onClick={() => {
                          setAssistantHistory([]);
                          triggerMascotReaction("Cleared all local query history!");
                        }}
                        className="text-red-400 hover:underline font-semibold cursor-pointer"
                      >
                        Clear All History
                      </button>
                    </div>
                  </div>

                  {/* 1D. Auto-Read Aloud & Speech Output Controls */}
                  <div
                    className="p-3.5 rounded-2xl border space-y-2.5 shadow-xs"
                    style={{ backgroundColor: theme.card, borderColor: theme.border }}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5 text-indigo-400">
                          <Volume2 className="w-3.5 h-3.5" />
                          Auto-Read Aloud Responses
                        </p>
                        <p className="text-[10px]" style={{ color: theme.muted }}>
                          Hybrid site native audio &amp; on-device TextToSpeech fallback
                        </p>
                      </div>
                      <button
                        onClick={toggleAutoSpeakQuick}
                        className={`w-11 h-6 rounded-full transition-colors relative p-0.5 cursor-pointer ${
                          isAutoSpeakEnabled ? 'bg-indigo-600' : 'bg-zinc-600'
                        }`}
                        title="Toggle Auto-Read Aloud Responses"
                      >
                        <div
                          className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                            isAutoSpeakEnabled ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>

                    <p className="text-[10px] leading-relaxed" style={{ color: theme.muted }}>
                      {isAutoSpeakEnabled
                        ? '✅ Answers are automatically spoken aloud as soon as generation completes, with a floating minimizable audio controller.'
                        : '🚫 Speech readout disabled. Only speaks when the Listen button is tapped.'}
                    </p>

                    <div className="flex items-center justify-between pt-1 border-t text-[11px]" style={{ borderColor: theme.border }}>
                      <span style={{ color: theme.muted }}>Speech Rate / Playback Speed:</span>
                      <button
                        onClick={cycleSpeechRate}
                        className="px-2.5 py-1 rounded-lg text-xs font-bold border transition cursor-pointer"
                        style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.accent }}
                      >
                        {speechRate}x ▾
                      </button>
                    </div>
                  </div>

                  {/* 2. Recent Assistant Queries Section (Top 5 Recent, Removable) */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between px-1">
                      <p className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5" style={{ color: theme.accent }}>
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        Recent Assistant Queries
                      </p>
                      <button
                        onClick={() => setShowFullHistoryModal(true)}
                        className="text-[10px] font-semibold hover:underline"
                        style={{ color: theme.muted }}
                      >
                        View All ({assistantHistory.length})
                      </button>
                    </div>

                    <div
                      className="p-2.5 rounded-2xl border space-y-1.5"
                      style={{ backgroundColor: theme.card, borderColor: theme.border }}
                    >
                      {assistantHistory.length === 0 ? (
                        <p className="text-center py-4 text-[11px]" style={{ color: theme.muted }}>
                          No questions in history yet. Ask anything in Web Assistant to save questions here!
                        </p>
                      ) : (
                        assistantHistory.slice(0, 5).map((item) => (
                          <div
                            key={item.id}
                            className="p-2 rounded-xl border flex items-center justify-between gap-2 transition hover:opacity-90"
                            style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}
                          >
                            <button
                              onClick={() => {
                                setScreenMode('chat');
                                setPromptText(item.query);
                                triggerMascotReaction(`Re-asking: "${item.query.slice(0, 25)}..."`);
                              }}
                              className="text-left min-w-0 flex-1 cursor-pointer"
                            >
                              <p className="font-semibold text-xs truncate" style={{ color: theme.text }}>
                                {item.query}
                              </p>
                              <p className="text-[10px] flex items-center gap-1.5 pt-0.5" style={{ color: theme.muted }}>
                                <span className="px-1.5 py-0.2 rounded font-mono text-[9px] bg-black/10 dark:bg-white/10" style={{ color: theme.accent }}>
                                  {item.serviceName}
                                </span>
                                <span>•</span>
                                <span>{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                              </p>
                            </button>
                            <button
                              onClick={() => {
                                setAssistantHistory(prev => prev.filter(h => h.id !== item.id));
                                triggerMascotReaction("Removed query from history!");
                              }}
                              className="p-1 rounded-lg hover:bg-red-500/10 text-red-400 transition"
                              title="Remove query"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))
                      )}

                      {assistantHistory.length > 0 && (
                        <button
                          onClick={() => setShowFullHistoryModal(true)}
                          className="w-full text-center py-1.5 text-[11px] font-bold rounded-xl transition hover:opacity-80"
                          style={{ color: theme.accent }}
                        >
                          Full Query History ({assistantHistory.length}) →
                        </button>
                      )}
                    </div>
                  </div>

                  {/* 3. Settings Section Below */}
                  <div className="space-y-2.5 pt-1">
                    <p className="text-[11px] font-bold uppercase tracking-wider px-1" style={{ color: theme.muted }}>
                      Settings &amp; Preferences
                    </p>

                    <div
                      className="p-3 rounded-2xl border transition-all"
                      style={{ backgroundColor: theme.card, borderColor: theme.border }}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-semibold text-xs" style={{ color: theme.text }}>Dark Mode</p>
                          <p className="text-[10px]" style={{ color: theme.muted }}>
                            {isDarkMode ? 'Gemini Dark Mode active' : 'Material 3 Light Mode active'}
                          </p>
                        </div>
                        <button
                          onClick={() => handleToggleDarkMode()}
                          className="w-11 h-6 rounded-full transition-colors relative p-0.5"
                          style={{ backgroundColor: isDarkMode ? theme.accent : '#D1D5DB' }}
                        >
                          <div
                            className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                              isDarkMode ? 'translate-x-5' : 'translate-x-0'
                            }`}
                          />
                        </button>
                      </div>
                    </div>

                    <div
                      className="p-3 rounded-2xl border space-y-2.5"
                      style={{ backgroundColor: theme.card, borderColor: theme.border }}
                    >
                      <div className="flex items-center justify-between">
                        <p className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5" style={{ color: theme.accent }}>
                          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                          Active Mascot Companion
                        </p>
                      </div>
                      <div className="flex gap-2 overflow-x-auto pb-2 pt-1 no-scrollbar select-none">
                        {ALL_SIMULATOR_MASCOTS.map((m) => {
                          const isSelected = logoStyle === m.id || (m.id === 'owl-orbital' && (logoStyle === 'default' || !logoStyle));
                          return (
                            <button
                              key={m.id}
                              onClick={() => {
                                onSelectLogo?.(m.id);
                                mascotAudio.playChirp();
                                triggerMascotReaction(`Active companion set to ${m.name}! Restart OpenAssist to update home launcher icon.`);
                              }}
                              className={`flex flex-col items-center justify-center p-2 rounded-xl border shrink-0 w-20 transition-all hover:scale-105 active:scale-95 cursor-pointer text-center relative ${
                                isSelected ? 'ring-2 ring-indigo-500 shadow-md' : ''
                              }`}
                              style={{
                                backgroundColor: isSelected ? (isDarkMode ? '#1E2337' : '#EEF2FF') : theme.surfaceHi,
                                borderColor: isSelected ? theme.accent : theme.border,
                              }}
                            >
                              <div className="w-9 h-9 flex items-center justify-center mb-1">
                                <OpenAssistLogo style={m.id} size={28} theme={isDarkMode ? 'dark' : 'light'} />
                              </div>
                              <span className="text-[10px] font-bold truncate max-w-full" style={{ color: isSelected ? theme.accent : theme.text }}>
                                {m.name}
                              </span>
                            </button>
                          );
                        })}
                      </div>

                      <div className="pt-1 border-t flex items-center justify-between text-[11px]" style={{ borderColor: theme.border }}>
                        <span style={{ color: theme.muted }}>Apply mascot icon to home launcher:</span>
                        <button
                          onClick={() => {
                            triggerMascotReaction("Launcher icon updated! Restart OpenAssist to view changes.");
                          }}
                          className="px-2.5 py-1 rounded-lg text-xs font-bold transition shadow"
                          style={{ backgroundColor: theme.accent, color: theme.onAccent }}
                        >
                          Apply &amp; Restart
                        </button>
                      </div>
                    </div>

                    {/* 4. Local Offline Whisper Models (Import, Switch, & Delete) */}
                    <div
                      className="p-3 rounded-2xl border space-y-2.5"
                      style={{ backgroundColor: theme.card, borderColor: theme.border }}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5" style={{ color: theme.accent }}>
                            <Volume2 className="w-3.5 h-3.5 text-blue-400" />
                            Local Offline Whisper Models
                          </p>
                          <p className="text-[10px]" style={{ color: theme.muted }}>
                            On-device speech recognition models • Switch or remove
                          </p>
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        {whisperModelsList.map((m) => {
                          const isActive = defaultWhisperModelId === m.id;
                          return (
                            <div
                              key={m.id}
                              className="p-2 rounded-xl border flex items-center justify-between gap-2"
                              style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}
                            >
                              <div className="min-w-0 flex-1">
                                <p className="font-semibold text-xs truncate" style={{ color: theme.text }}>
                                  {m.name}
                                </p>
                                <p className="text-[10px]" style={{ color: theme.muted }}>
                                  {m.size} • GGML Quantized
                                </p>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                <button
                                  onClick={() => {
                                    setDefaultWhisperModelId(m.id);
                                    triggerMascotReaction(`Activated model: ${m.name}`);
                                  }}
                                  className={`px-2 py-1 rounded-lg text-[10px] font-bold transition ${
                                    isActive ? 'bg-blue-600 text-white' : 'hover:opacity-80'
                                  }`}
                                  style={{
                                    backgroundColor: isActive ? '#2563EB' : theme.card,
                                    color: isActive ? '#FFFFFF' : theme.text
                                  }}
                                >
                                  {isActive ? 'Active' : 'Select'}
                                </button>
                                <button
                                  onClick={() => {
                                    if (whisperModelsList.length === 1) {
                                      if (!window.confirm(`Delete ${m.name}? This is your only local model.`)) return;
                                    }
                                    const nextList = whisperModelsList.filter(x => x.id !== m.id);
                                    setWhisperModelsList(nextList);
                                    if (defaultWhisperModelId === m.id && nextList.length > 0) {
                                      setDefaultWhisperModelId(nextList[0].id);
                                    }
                                    triggerMascotReaction(`Removed model: ${m.name}`);
                                  }}
                                  className="p-1 rounded-lg hover:bg-red-500/10 text-red-400 transition"
                                  title="Delete Model from Device"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      <button
                        onClick={() => {
                          const name = prompt("Enter model filename (e.g. ggml-medium.bin):", "ggml-medium-q5.bin");
                          if (name && name.trim()) {
                            const newId = name.trim();
                            setWhisperModelsList(prev => [...prev, { id: newId, name: newId, size: '780 MB' }]);
                            setDefaultWhisperModelId(newId);
                            triggerMascotReaction(`Imported model: ${newId}`);
                          }
                        }}
                        className="w-full py-1.5 text-center text-xs font-bold rounded-xl border border-dashed transition hover:opacity-85"
                        style={{ borderColor: theme.border, color: theme.accent }}
                      >
                        + Import Model (.bin)
                      </button>
                    </div>

                    {/* 5. Per-Language Model Binding (Bind, Add, Remove Preexisting/Custom) */}
                    <div
                      className="p-3 rounded-2xl border space-y-2.5"
                      style={{ backgroundColor: theme.card, borderColor: theme.border }}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5" style={{ color: theme.accent }}>
                            <Globe className="w-3.5 h-3.5 text-indigo-400" />
                            Per-Language Model Binding
                          </p>
                          <p className="text-[10px]" style={{ color: theme.muted }}>
                            Assign specific Whisper models to each language
                          </p>
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        {activeLangBindings.map((lb) => {
                          return (
                            <div
                              key={lb.code}
                              className="p-2 rounded-xl border flex items-center justify-between gap-2"
                              style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}
                            >
                              <div className="min-w-0 flex-1">
                                <p className="font-semibold text-xs truncate" style={{ color: theme.text }}>
                                  {lb.name}
                                </p>
                                <p className="text-[10px] text-blue-400 font-mono">
                                  Bound: {lb.modelId}
                                </p>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                <button
                                  onClick={() => {
                                    // Cycle through available models
                                    const currIdx = whisperModelsList.findIndex(m => m.id === lb.modelId);
                                    const nextIdx = (currIdx + 1) % whisperModelsList.length;
                                    const nextModel = whisperModelsList[nextIdx]?.id || 'ggml-tiny.bin';
                                    setActiveLangBindings(prev => prev.map(x => x.code === lb.code ? { ...x, modelId: nextModel } : x));
                                    triggerMascotReaction(`Bound ${lb.name} to ${nextModel}`);
                                  }}
                                  className="px-2 py-1 rounded-lg text-[10px] font-bold transition bg-blue-600 text-white hover:opacity-90"
                                >
                                  Change
                                </button>
                                <button
                                  onClick={() => {
                                    setActiveLangBindings(prev => prev.filter(x => x.code !== lb.code));
                                    triggerMascotReaction(`Removed binding: ${lb.name}`);
                                  }}
                                  className="p-1 rounded-lg hover:bg-red-500/10 text-red-400 transition"
                                  title="Remove Language Binding"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      <div className="flex items-center gap-2 pt-1">
                        <button
                          onClick={() => setShowAddLangModal(true)}
                          className="flex-1 py-1.5 text-center text-xs font-bold rounded-xl border border-dashed transition hover:opacity-85"
                          style={{ borderColor: theme.border, color: theme.accent }}
                        >
                          + Add Language Binding
                        </button>
                        {activeLangBindings.length < 3 && (
                          <button
                            onClick={() => {
                              setActiveLangBindings([
                                { code: 'hinglish', name: 'Hinglish (Default)', isStandard: true, modelId: 'ggml-tiny.bin' },
                                { code: 'hi', name: 'Hindi (Secondary)', isStandard: true, modelId: 'ggml-tiny.bin' },
                                { code: 'en', name: 'English', isStandard: true, modelId: 'ggml-base.bin' },
                              ]);
                              triggerMascotReaction("Restored default languages!");
                            }}
                            className="py-1.5 px-2.5 text-xs font-semibold rounded-xl border transition hover:opacity-80"
                            style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                          >
                            Reset
                          </button>
                        )}
                      </div>
                    </div>

                    {/* 6. Language Switcher & Community Translation Extensions */}
                    <div
                      className="p-3 rounded-2xl border space-y-2.5"
                      style={{ backgroundColor: theme.card, borderColor: theme.border }}
                    >
                      <div>
                        <p className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5" style={{ color: theme.accent }}>
                          <Globe className="w-3.5 h-3.5 text-emerald-400" />
                          App Language &amp; Extensions
                        </p>
                        <p className="text-[10px]" style={{ color: theme.muted }}>
                          App default with per-menu overrides and community translation files
                        </p>
                      </div>

                      {/* App Default Language */}
                      <div className="flex items-center justify-between p-2 rounded-xl border" style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}>
                        <div>
                          <p className="font-semibold text-xs" style={{ color: theme.text }}>App Default Language</p>
                          <p className="text-[10px]" style={{ color: theme.muted }}>Main UI default for all screens</p>
                        </div>
                        <select
                          value={appLanguageSetting}
                          onChange={(e) => {
                            setAppLanguageSetting(e.target.value);
                            triggerMascotReaction(`App default language: ${e.target.value.toUpperCase()}`);
                          }}
                          className="px-2 py-1 rounded-lg text-xs font-bold border"
                          style={{ backgroundColor: theme.card, borderColor: theme.border, color: theme.text }}
                        >
                          {allLanguagesList.map(l => (
                            <option key={l.code} value={l.code}>{l.name}</option>
                          ))}
                        </select>
                      </div>

                      {/* Per-Menu Overrides */}
                      <div className="space-y-1.5 pt-1">
                        <p className="text-[10px] font-bold uppercase tracking-wider" style={{ color: theme.muted }}>
                          Per-Menu Overrides
                        </p>

                        {[
                          { label: 'Settings Menu', val: settingsLangOverride, set: setSettingsLangOverride },
                          { label: 'Overlay Assistant', val: overlayLangOverride, set: setOverlayLangOverride },
                          { label: 'Web UI Assistant', val: webLangOverride, set: setWebLangOverride },
                          { label: 'Mascot Spoken Speech', val: mascotLangOverride, set: setMascotLangOverride },
                        ].map((item, idx) => (
                          <div key={idx} className="flex items-center justify-between px-2 py-1.5 rounded-lg border text-xs" style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}>
                            <span style={{ color: theme.text }}>{item.label}</span>
                            <select
                              value={item.val}
                              onChange={(e) => {
                                item.set(e.target.value);
                                triggerMascotReaction(`${item.label} set to ${e.target.value || 'App Default'}`);
                              }}
                              className="px-1.5 py-0.5 rounded text-[11px] font-semibold border"
                              style={{ backgroundColor: theme.card, borderColor: theme.border, color: theme.accent }}
                            >
                              <option value="">Default ({appLanguageSetting})</option>
                              {allLanguagesList.map(l => (
                                <option key={l.code} value={l.code}>{l.name}</option>
                              ))}
                            </select>
                          </div>
                        ))}
                      </div>

                      {/* Mascot AI Translation Tip Banner */}
                      <div className="p-2.5 rounded-xl border flex items-start gap-2 bg-gradient-to-r from-amber-500/10 to-indigo-500/10" style={{ borderColor: theme.border }}>
                        <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <p className="text-[10px] leading-relaxed" style={{ color: theme.text }}>
                          <span className="font-bold text-amber-400">Tip from Ozzy:</span> You can export our simple translation template below, paste it into Gemini or ChatGPT with prompt: <span className="italic font-mono text-[9px] bg-black/20 px-1 rounded">"Translate line 2 of each pair to [Language]"</span>, then import it right back!
                        </p>
                      </div>

                      {/* Community Translation Extension Buttons */}
                      <div className="flex items-center gap-1.5 pt-1">
                        <button
                          onClick={() => setShowExportLangModal(true)}
                          className="flex-1 py-1.5 px-2 rounded-xl text-[11px] font-semibold border flex items-center justify-center gap-1 transition hover:opacity-80"
                          style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                        >
                          <Download className="w-3 h-3 text-blue-400" />
                          <span>Export .txt</span>
                        </button>
                        <button
                          onClick={() => setShowImportLangModal(true)}
                          className="flex-1 py-1.5 px-2 rounded-xl text-[11px] font-semibold border flex items-center justify-center gap-1 transition hover:opacity-80"
                          style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                        >
                          <Upload className="w-3 h-3 text-emerald-400" />
                          <span>Import .txt</span>
                        </button>
                        <button
                          onClick={() => setShowEditorLangModal(true)}
                          className="flex-1 py-1.5 px-2 rounded-xl text-[11px] font-bold text-white transition hover:opacity-90 flex items-center justify-center gap-1"
                          style={{ backgroundColor: '#4F46E5' }}
                        >
                          <span>In-App Editor</span>
                        </button>
                      </div>
                    </div>

                    {/* 7. Mascot Speech & Dialogue Studio */}
                    <div
                      className="p-3 rounded-2xl border space-y-2.5"
                      style={{ backgroundColor: theme.card, borderColor: theme.border }}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5" style={{ color: theme.accent }}>
                            <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                            Mascot Speech &amp; Dialogue Studio
                          </p>
                          <p className="text-[10px]" style={{ color: theme.muted }}>
                            Customize &amp; add phrases for Ozzy, Pip, Echo &amp; friends
                          </p>
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        {mascotDialogueList.slice(0, 4).map((phrase, idx) => (
                          <div
                            key={idx}
                            className="p-2 rounded-xl border flex items-center justify-between gap-2"
                            style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}
                          >
                            <span className="text-xs truncate flex-1" style={{ color: theme.text }}>
                              "{phrase}"
                            </span>
                            <button
                              onClick={() => {
                                setMascotDialogueList(prev => prev.filter((_, i) => i !== idx));
                                triggerMascotReaction("Phrase removed!");
                              }}
                              className="p-1 rounded-lg hover:bg-red-500/10 text-red-400 transition"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>

                      <div className="flex items-center gap-2 pt-1">
                        <button
                          onClick={() => setShowMascotStudioModal(true)}
                          className="flex-1 py-1.5 px-3 rounded-xl text-xs font-bold text-white transition hover:opacity-90"
                          style={{ backgroundColor: '#059669' }}
                        >
                          Mascot Dialogue Studio
                        </button>
                        <button
                          onClick={() => {
                            const template = mascotDialogueList.map(p => `ENGLISH:\n${p}\n\nTRANSLATION:\n${p}\n\n---\n`).join('\n');
                            navigator.clipboard.writeText(template);
                            triggerMascotReaction("Copied Mascot Dialogue template to clipboard!");
                          }}
                          className="py-1.5 px-2.5 rounded-xl text-xs font-semibold border transition hover:opacity-80"
                          style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                        >
                          Export Dialogue
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {navType === '3-button' ? (
              <div className="h-7 flex items-center justify-around px-12 bg-black/90 border-t border-white/5 select-none z-40">
                <button
                  onClick={() => setScreenMode('chat')}
                  className="text-zinc-400 hover:text-white p-1 text-sm font-bold transition"
                >
                  ◀
                </button>
                <button
                  onClick={() => setScreenMode('overlay')}
                  className="text-zinc-400 hover:text-white p-1 text-base font-bold transition"
                >
                  ●
                </button>
                <button
                  onClick={() => setScreenMode('settings')}
                  className="text-zinc-400 hover:text-white p-1 text-xs font-bold transition"
                >
                  ■
                </button>
              </div>
            ) : (
              <div className="h-5 flex items-center justify-center bg-black/60 select-none z-40">
                <div
                  onClick={() => setScreenMode('overlay')}
                  className="w-28 h-1 bg-white/40 rounded-full hover:bg-white/80 cursor-pointer transition"
                />
              </div>
            )}
          </div>
        </div>

        {/* Modal 1: Add Language Binding */}
        {showAddLangModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div
              className="w-full max-w-sm rounded-2xl p-4 border shadow-2xl space-y-3"
              style={{ backgroundColor: theme.card, borderColor: theme.border }}
            >
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm" style={{ color: theme.text }}>Add Language Binding</h3>
                <button onClick={() => setShowAddLangModal(false)} className="p-1 rounded-full text-zinc-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-[11px]" style={{ color: theme.muted }}>
                Bind a specific language to a local Whisper model:
              </p>
              <div className="space-y-2">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-wider" style={{ color: theme.muted }}>Language Code</label>
                  <input
                    type="text"
                    placeholder="e.g. es, fr, de, ja"
                    value={newLangCode}
                    onChange={(e) => setNewLangCode(e.target.value)}
                    className="w-full p-2 rounded-xl text-xs border bg-transparent mt-0.5"
                    style={{ borderColor: theme.border, color: theme.text }}
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-wider" style={{ color: theme.muted }}>Language Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Spanish, French"
                    value={newLangName}
                    onChange={(e) => setNewLangName(e.target.value)}
                    className="w-full p-2 rounded-xl text-xs border bg-transparent mt-0.5"
                    style={{ borderColor: theme.border, color: theme.text }}
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setShowAddLangModal(false)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold border"
                  style={{ borderColor: theme.border, color: theme.text }}
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    const c = newLangCode.trim().toLowerCase();
                    const n = newLangName.trim() || c.toUpperCase();
                    if (c) {
                      setActiveLangBindings(prev => [...prev.filter(x => x.code !== c), {
                        code: c,
                        name: n,
                        isStandard: false,
                        modelId: defaultWhisperModelId
                      }]);
                      setAllLanguagesList(prev => prev.some(x => x.code === c) ? prev : [...prev, { code: c, name: n }]);
                      setShowAddLangModal(false);
                      setNewLangCode('');
                      setNewLangName('');
                      triggerMascotReaction(`Added language binding for ${n}!`);
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-white shadow"
                  style={{ backgroundColor: theme.accent }}
                >
                  Add Binding
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal 2: Export Translation Template (.txt) */}
        {showExportLangModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div
              className="w-full max-w-md rounded-2xl p-4 border shadow-2xl space-y-3"
              style={{ backgroundColor: theme.card, borderColor: theme.border }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Download className="w-4 h-4 text-blue-400" />
                  <h3 className="font-bold text-sm" style={{ color: theme.text }}>Export Translation File (.txt)</h3>
                </div>
                <button onClick={() => setShowExportLangModal(false)} className="p-1 rounded-full text-zinc-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-[11px] leading-relaxed" style={{ color: theme.muted }}>
                Extensible community translation format: <span className="font-bold text-zinc-200">Line 1 is English</span>, <span className="font-bold text-zinc-200">Line 2 is Translation</span>, with <span className="font-bold text-zinc-200">1 empty line gap</span>. Empty translated lines automatically fallback to English!
              </p>
              <textarea
                readOnly
                value={[
                  "Digital assistant\nDigital assistant\n",
                  "Choose default assistant\nChoose default assistant\n",
                  "Local Offline Whisper Models\nLocal Offline Whisper Models\n",
                  "Import Model (.bin)\nImport Model (.bin)\n",
                  "Per-Language Model Binding\nPer-Language Model Binding\n",
                  "Test Voice Dictation & Transcription\nTest Voice Dictation & Transcription\n",
                  "Mascot Companion Chip\nMascot Companion Chip\n",
                  "Universal Circle to Search\nUniversal Circle to Search\n"
                ].join('\n')}
                className="w-full h-44 p-2 rounded-xl text-[11px] font-mono border bg-black/40 focus:outline-none"
                style={{ borderColor: theme.border, color: theme.text }}
              />
              <div className="flex justify-between items-center pt-1">
                <span className="text-[10px]" style={{ color: theme.muted }}>Format: Community extensible (.txt)</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const text = [
                        "Digital assistant\nDigital assistant\n",
                        "Choose default assistant\nChoose default assistant\n",
                        "Local Offline Whisper Models\nLocal Offline Whisper Models\n",
                        "Import Model (.bin)\nImport Model (.bin)\n",
                        "Per-Language Model Binding\nPer-Language Model Binding\n",
                        "Test Voice Dictation & Transcription\nTest Voice Dictation & Transcription\n",
                        "Mascot Companion Chip\nMascot Companion Chip\n",
                        "Universal Circle to Search\nUniversal Circle to Search\n"
                      ].join('\n');
                      navigator.clipboard.writeText(text);
                      triggerMascotReaction("Copied translation template to clipboard!");
                      setShowExportLangModal(false);
                    }}
                    className="px-3 py-1.5 rounded-xl text-xs font-bold text-white shadow"
                    style={{ backgroundColor: theme.accent }}
                  >
                    Copy to Clipboard
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal 3: Import Translation File (.txt) */}
        {showImportLangModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div
              className="w-full max-w-md rounded-2xl p-4 border shadow-2xl space-y-3"
              style={{ backgroundColor: theme.card, borderColor: theme.border }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Upload className="w-4 h-4 text-emerald-400" />
                  <h3 className="font-bold text-sm" style={{ color: theme.text }}>Import Translation File (.txt)</h3>
                </div>
                <button onClick={() => setShowImportLangModal(false)} className="p-1 rounded-full text-zinc-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-[11px]" style={{ color: theme.muted }}>
                Paste the contents of your community translated .txt file:
              </p>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="Language Code (e.g. es)"
                  value={newLangCode}
                  onChange={(e) => setNewLangCode(e.target.value)}
                  className="p-1.5 rounded-xl text-xs border bg-transparent"
                  style={{ borderColor: theme.border, color: theme.text }}
                />
                <input
                  type="text"
                  placeholder="Language Name (e.g. Spanish)"
                  value={newLangName}
                  onChange={(e) => setNewLangName(e.target.value)}
                  className="p-1.5 rounded-xl text-xs border bg-transparent"
                  style={{ borderColor: theme.border, color: theme.text }}
                />
              </div>
              <textarea
                placeholder="Paste translated text here (English line, Translated line, empty line)..."
                value={importLangText}
                onChange={(e) => setImportLangText(e.target.value)}
                className="w-full h-36 p-2 rounded-xl text-[11px] font-mono border bg-black/40 focus:outline-none"
                style={{ borderColor: theme.border, color: theme.text }}
              />
              <div className="flex justify-end gap-2 pt-1">
                <button
                  onClick={() => setShowImportLangModal(false)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold border"
                  style={{ borderColor: theme.border, color: theme.text }}
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    const c = newLangCode.trim().toLowerCase() || 'custom';
                    const n = newLangName.trim() || c.toUpperCase();
                    setAllLanguagesList(prev => prev.some(x => x.code === c) ? prev : [...prev, { code: c, name: n }]);
                    setAppLanguageSetting(c);
                    setShowImportLangModal(false);
                    setNewLangCode('');
                    setNewLangName('');
                    setImportLangText('');
                    triggerMascotReaction(`Imported and activated ${n}!`);
                  }}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-white shadow"
                  style={{ backgroundColor: '#059669' }}
                >
                  Import &amp; Apply
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal 4: In-App Quick Translation Editor */}
        {showEditorLangModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div
              className="w-full max-w-md rounded-2xl p-4 border shadow-2xl space-y-3 max-h-[85vh] flex flex-col"
              style={{ backgroundColor: theme.card, borderColor: theme.border }}
            >
              <div className="flex items-center justify-between shrink-0">
                <h3 className="font-bold text-sm" style={{ color: theme.text }}>In-App Translation Editor</h3>
                <button onClick={() => setShowEditorLangModal(false)} className="p-1 rounded-full text-zinc-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-[11px] shrink-0" style={{ color: theme.muted }}>
                Quickly edit or customize app labels. Leave blank to fallback to English:
              </p>
              <div className="flex-1 overflow-y-auto space-y-2 pr-1">
                {[
                  { en: "Digital assistant", key: "st_assistant" },
                  { en: "Choose default assistant", key: "st_set_assistant" },
                  { en: "Local Offline Whisper Models", key: "st_whisper_models" },
                  { en: "Per-Language Model Binding", key: "st_model_binding" },
                  { en: "Test Voice Dictation & Transcription", key: "st_test_voice" },
                  { en: "Mascot Speech Bubbles & Petting", key: "st_mascot_bubbles" },
                  { en: "Universal Circle to Search", key: "st_circle_search" },
                ].map((item, idx) => (
                  <div key={idx} className="p-2 rounded-xl border text-xs space-y-1" style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}>
                    <p className="font-semibold" style={{ color: theme.accent }}>{item.en}</p>
                    <input
                      type="text"
                      placeholder={`Translated text (defaults to "${item.en}")`}
                      defaultValue={item.en}
                      className="w-full p-1.5 rounded-lg border text-xs bg-black/30"
                      style={{ borderColor: theme.border, color: theme.text }}
                    />
                  </div>
                ))}
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t shrink-0" style={{ borderColor: theme.border }}>
                <button
                  onClick={() => setShowEditorLangModal(false)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold border"
                  style={{ borderColor: theme.border, color: theme.text }}
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    setShowEditorLangModal(false);
                    triggerMascotReaction("Saved translations!");
                  }}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-white shadow"
                  style={{ backgroundColor: theme.accent }}
                >
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal 5: Mascot Speech & Dialogue Studio */}
        {showMascotStudioModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div
              className="w-full max-w-md rounded-2xl p-4 border shadow-2xl space-y-3 max-h-[85vh] flex flex-col"
              style={{ backgroundColor: theme.card, borderColor: theme.border }}
            >
              <div className="flex items-center justify-between shrink-0">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-pink-400" />
                  <h3 className="font-bold text-sm" style={{ color: theme.text }}>Mascot Dialogue Studio</h3>
                </div>
                <button onClick={() => setShowMascotStudioModal(false)} className="p-1 rounded-full text-zinc-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="flex items-center justify-between shrink-0 text-xs">
                <span style={{ color: theme.muted }}>Filter companion:</span>
                <select
                  value={selectedStudioMascot}
                  onChange={(e) => setSelectedStudioMascot(e.target.value)}
                  className="p-1 rounded-lg border text-xs font-semibold"
                  style={{ backgroundColor: theme.card, borderColor: theme.border, color: theme.text }}
                >
                  <option value="all">All Mascots</option>
                  <option value="owl">Ozzy (Owl)</option>
                  <option value="fox">Pip (Fox)</option>
                  <option value="bat">Echo (Bat)</option>
                  <option value="otter">Nova (Otter)</option>
                </select>
              </div>

              {/* Add Phrase Input */}
              <div className="flex gap-1.5 shrink-0">
                <input
                  type="text"
                  placeholder="Enter cute greeting or prompt tip..."
                  value={newMascotPhrase}
                  onChange={(e) => setNewMascotPhrase(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && newMascotPhrase.trim()) {
                      setMascotDialogueList(prev => [...prev, newMascotPhrase.trim()]);
                      setNewMascotPhrase('');
                      triggerMascotReaction("Added new mascot phrase!");
                    }
                  }}
                  className="flex-1 p-2 rounded-xl text-xs border bg-transparent"
                  style={{ borderColor: theme.border, color: theme.text }}
                />
                <button
                  onClick={() => {
                    if (newMascotPhrase.trim()) {
                      setMascotDialogueList(prev => [...prev, newMascotPhrase.trim()]);
                      setNewMascotPhrase('');
                      triggerMascotReaction("Added new mascot phrase!");
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-white shadow"
                  style={{ backgroundColor: '#059669' }}
                >
                  + Add
                </button>
              </div>

              {/* List of Dialogue Phrases */}
              <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
                {mascotDialogueList.map((phrase, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl border flex items-center justify-between gap-2 text-xs"
                    style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}
                  >
                    <span style={{ color: theme.text }} className="flex-1">
                      "{phrase}"
                    </span>
                    <button
                      onClick={() => {
                        setMascotDialogueList(prev => prev.filter((_, i) => i !== idx));
                        triggerMascotReaction("Removed phrase!");
                      }}
                      className="p-1 rounded-lg hover:bg-red-500/10 text-red-400 transition"
                      title="Remove Phrase"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              <div className="flex justify-end pt-2 border-t shrink-0" style={{ borderColor: theme.border }}>
                <button
                  onClick={() => setShowMascotStudioModal(false)}
                  className="px-4 py-1.5 rounded-xl text-xs font-bold text-white shadow"
                  style={{ backgroundColor: theme.accent }}
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal 6: Complete AI Query History with Tooltip Card */}
        {showFullHistoryModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div
              className="w-full max-w-md rounded-2xl p-4 border shadow-2xl space-y-3 max-h-[85vh] flex flex-col"
              style={{ backgroundColor: theme.card, borderColor: theme.border }}
            >
              <div className="flex items-center justify-between shrink-0">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <h3 className="font-bold text-sm" style={{ color: theme.text }}>
                    Complete AI Query History ({assistantHistory.length})
                  </h3>
                </div>
                <button onClick={() => setShowFullHistoryModal(false)} className="p-1 rounded-full text-zinc-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Informative Tooltip Card */}
              <div
                className="p-3 rounded-xl border flex items-start gap-2.5 shrink-0"
                style={{
                  backgroundColor: isDarkMode ? '#1E293B' : '#EFF6FF',
                  borderColor: isDarkMode ? '#334155' : '#BFDBFE'
                }}
              >
                <Sparkles className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <p
                  className="text-[11px] leading-relaxed"
                  style={{ color: isDarkMode ? '#93C5FD' : '#1D4ED8' }}
                >
                  💡 <strong>Quick Tip:</strong> Swipe right from the left screen edge in Settings to open this history anytime! Tap any past question below to re-ask your active assistant.
                </p>
              </div>

              {/* History Items List */}
              <div className="flex-1 overflow-y-auto space-y-2 pr-1">
                {assistantHistory.length === 0 ? (
                  <p className="text-center py-8 text-xs" style={{ color: theme.muted }}>
                    No questions in history yet. Dictate or circle anything to record queries!
                  </p>
                ) : (
                  assistantHistory.map((item) => (
                    <div
                      key={item.id}
                      className="p-2.5 rounded-xl border flex items-center justify-between gap-2 text-xs transition hover:opacity-90"
                      style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}
                    >
                      <button
                        onClick={() => {
                          setShowFullHistoryModal(false);
                          setScreenMode('chat');
                          setPromptText(item.query);
                          triggerMascotReaction(`Re-asking: "${item.query.slice(0, 25)}..."`);
                        }}
                        className="text-left min-w-0 flex-1 cursor-pointer"
                      >
                        <p className="font-semibold text-xs truncate" style={{ color: theme.text }}>
                          {item.query}
                        </p>
                        <p className="text-[10px] flex items-center gap-1.5 pt-0.5" style={{ color: theme.muted }}>
                          <span className="px-1.5 py-0.2 rounded font-mono text-[9px] bg-black/10 dark:bg-white/10" style={{ color: theme.accent }}>
                            {item.serviceName}
                          </span>
                          <span>•</span>
                          <span>{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </p>
                      </button>
                      <button
                        onClick={() => {
                          setAssistantHistory(prev => prev.filter(h => h.id !== item.id));
                        }}
                        className="p-1 rounded-lg hover:bg-red-500/10 text-red-400 transition"
                        title="Delete question"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>

              {assistantHistory.length > 0 && (
                <div className="flex justify-between items-center pt-2 border-t shrink-0" style={{ borderColor: theme.border }}>
                  <button
                    onClick={() => {
                      setAssistantHistory([]);
                      triggerMascotReaction("Cleared all query history!");
                    }}
                    className="text-xs text-red-400 hover:underline font-semibold"
                  >
                    Clear All History
                  </button>
                  <button
                    onClick={() => setShowFullHistoryModal(false)}
                    className="px-4 py-1.5 rounded-xl text-xs font-bold text-white shadow"
                    style={{ backgroundColor: theme.accent }}
                  >
                    Close
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Modal 7: About OpenAssist & GitHub Update Manager */}
        {showAboutModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div
              className="w-full max-w-md rounded-2xl p-4 border shadow-2xl space-y-3.5 max-h-[88vh] flex flex-col"
              style={{ backgroundColor: theme.card, borderColor: theme.border }}
            >
              {/* Header */}
              <div className="flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2.5">
                  <OpenAssistLogo style={logoStyle} size={32} theme={isDarkMode ? 'dark' : 'light'} customIcons={customIcons} />
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-base" style={{ color: theme.text }}>OpenAssist</h3>
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30">
                        {installedAppVersion}
                      </span>
                    </div>
                    <p className="text-[10px]" style={{ color: theme.muted }}>
                      Open-Source AI Assistant &amp; Circle-to-Search
                    </p>
                  </div>
                </div>
                <button onClick={() => setShowAboutModal(false)} className="p-1 rounded-full text-zinc-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Scrollable Body */}
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                {/* Features Highlights Card */}
                <div
                  className="p-3 rounded-xl border space-y-2 text-xs"
                  style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border }}
                >
                  <div className="flex items-start gap-2">
                    <span className="text-sm">⭕</span>
                    <div>
                      <p className="font-semibold" style={{ color: theme.text }}>Circle to Search</p>
                      <p className="text-[11px]" style={{ color: theme.muted }}>Circle, lasso, or crop any equation, math problem, image, or text on screen.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-sm">🎙️</span>
                    <div>
                      <p className="font-semibold" style={{ color: theme.text }}>On-Device Whisper Speech</p>
                      <p className="text-[11px]" style={{ color: theme.muted }}>100% private neural voice typing powered by local Whisper GGML models.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-sm">🤖</span>
                    <div>
                      <p className="font-semibold" style={{ color: theme.text }}>Multi-Service Web AI</p>
                      <p className="text-[11px]" style={{ color: theme.muted }}>Connects to Gemini, ChatGPT, Claude, Perplexity, Mistral, and custom endpoints.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-sm">🔒</span>
                    <div>
                      <p className="font-semibold" style={{ color: theme.text }}>100% Private &amp; Open Source</p>
                      <p className="text-[11px]" style={{ color: theme.muted }}>Zero telemetry, zero ads, zero user tracking. All code is public and transparent.</p>
                    </div>
                  </div>
                </div>

                {/* In-App GitHub Update Manager */}
                <div
                  className="p-3 rounded-xl border space-y-2.5 text-left"
                  style={{
                    backgroundColor: isDarkMode ? '#1E293B' : '#F1F5F9',
                    borderColor: theme.border
                  }}
                >
                  <div>
                    <h4 className="font-bold text-xs" style={{ color: theme.text }}>App Updates &amp; Releases</h4>
                    <p className="text-[11px] leading-relaxed pt-0.5" style={{ color: theme.muted }}>
                      Installed version: <span className="font-semibold text-blue-400">{installedAppVersion}</span>
                      <br />
                      Checks against official public releases on GitHub.
                    </p>
                  </div>

                  {updateCheckStatus && (
                    <div
                      className="p-2 rounded-lg text-xs leading-relaxed"
                      style={{
                        backgroundColor: isDarkMode ? '#0F172A' : '#FFFFFF',
                        border: `1px solid ${theme.border}`,
                        color: updateCheckStatus.includes('up to date') ? '#3B82F6' : '#10B981'
                      }}
                    >
                      {updateCheckStatus}
                    </div>
                  )}

                  {/* Real-time In-App Progress Bar during APK Download */}
                  {isDownloadingUpdate && (
                    <div
                      className="p-2.5 rounded-xl border space-y-1.5 animate-fadeIn"
                      style={{
                        backgroundColor: isDarkMode ? '#0F172A' : '#FFFFFF',
                        borderColor: '#10B981'
                      }}
                    >
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-bold" style={{ color: theme.text }}>
                          Downloading {discoveredRelease?.tag} update...
                        </span>
                        <span className="font-mono font-bold text-emerald-400">{downloadProgress}%</span>
                      </div>
                      <div className="w-full bg-slate-700/40 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-500 h-full transition-all duration-150 rounded-full"
                          style={{ width: `${downloadProgress}%` }}
                        />
                      </div>
                      <div className="flex items-center justify-between text-[10px]" style={{ color: theme.muted }}>
                        <span>
                          {((downloadBytes.total * (downloadProgress / 100)) / (1024 * 1024)).toFixed(1)} MB / {(downloadBytes.total / (1024 * 1024)).toFixed(1)} MB
                        </span>
                        <span>Direct background APK fetch</span>
                      </div>
                    </div>
                  )}

                  {/* Fallback & Prompt "Install Now" Banner when Download is Complete */}
                  {downloadCompletedApk && !isDownloadingUpdate && (
                    <div
                      className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 space-y-1.5 animate-fadeIn"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5" />
                          Update APK Ready
                        </span>
                        <span className="text-[10px] text-zinc-400 font-mono">{downloadCompletedApk}</span>
                      </div>
                      <p className="text-[11px] text-zinc-300">
                        Package downloaded! Tap below if the automatic installer prompt did not appear.
                      </p>
                      <button
                        onClick={() => setShowInstallPromptModal(true)}
                        className="w-full py-1.5 px-3 rounded-xl text-xs font-bold text-white bg-emerald-500 hover:bg-emerald-400 transition shadow flex items-center justify-center gap-1.5"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Install Now ({downloadCompletedApk})</span>
                      </button>
                    </div>
                  )}

                  <div className="space-y-1.5 pt-1">
                    {/* Instant Download & Update button if newer release discovered and not yet downloaded */}
                    {discoveredRelease && !downloadCompletedApk && !isDownloadingUpdate && (
                      <button
                        onClick={() => {
                          setIsDownloadingUpdate(true);
                          setDownloadProgress(0);
                          let current = 0;
                          const interval = setInterval(() => {
                            current += 10;
                            if (current >= 100) {
                              current = 100;
                              clearInterval(interval);
                              setDownloadProgress(100);
                              setIsDownloadingUpdate(false);
                              setDownloadCompletedApk(discoveredRelease.tag);
                              setShowInstallPromptModal(true);
                              triggerMascotReaction(`Update Downloaded! Opening installer...`);
                            } else {
                              setDownloadProgress(current);
                            }
                          }, 100);
                        }}
                        className="w-full py-2 px-3 rounded-xl text-xs font-bold text-white transition shadow flex items-center justify-center gap-1.5 bg-emerald-500 hover:bg-emerald-400 active:scale-98"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>⚡ Instant Download &amp; Update ({discoveredRelease.tag})</span>
                      </button>
                    )}

                    <button
                      onClick={async () => {
                        setIsCheckingUpdate(true);
                        setUpdateCheckStatus(`Querying GitHub API (${APP_VERSION.githubRepo})...`);
                        try {
                          const res = await fetch(`https://api.github.com/repos/${APP_VERSION.githubRepo}/releases/latest`);
                          if (res.ok) {
                            const data = await res.json();
                            const tag = data.tag_name || APP_VERSION.versionTag;
                            const isNewer = isNewerVersion(tag, installedAppVersion);
                            if (isNewer) {
                              const apkAsset = data.assets?.find((a: any) => a.name?.toLowerCase().endsWith('.apk'));
                              setDiscoveredRelease({
                                tag,
                                name: data.name || tag,
                                body: data.body || '',
                                apkUrl: apkAsset?.browser_download_url || null
                              });
                              setUpdateCheckStatus(`🎉 New release available: ${data.name || tag} (${tag})\n${data.body?.slice(0, 110) || 'Bug fixes and improvements'}`);
                            } else {
                              setDiscoveredRelease(null);
                              setUpdateCheckStatus(`✅ OpenAssist is up to date! (${installedAppVersion})\nYou have the latest version installed.`);
                            }
                          } else {
                            setDiscoveredRelease(null);
                            setUpdateCheckStatus(`✅ OpenAssist is up to date! (${installedAppVersion})\nOfficial repository: github.com/${APP_VERSION.githubRepo}`);
                          }
                        } catch {
                          setDiscoveredRelease(null);
                          setUpdateCheckStatus(`✅ OpenAssist is up to date! (${installedAppVersion})\nOfficial repository: github.com/${APP_VERSION.githubRepo}`);
                        } finally {
                          setIsCheckingUpdate(false);
                        }
                      }}
                      disabled={isCheckingUpdate || isDownloadingUpdate}
                      className="w-full py-1.5 px-3 rounded-xl text-xs font-bold text-white transition shadow flex items-center justify-center gap-1.5 disabled:opacity-50"
                      style={{ backgroundColor: theme.accent }}
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isCheckingUpdate ? 'animate-spin' : ''}`} />
                      <span>{isCheckingUpdate ? 'Checking GitHub...' : 'Check for Updates'}</span>
                    </button>

                    <a
                      href={`https://github.com/${APP_VERSION.githubRepo}/releases`}
                      target="_blank"
                      rel="noreferrer"
                      className="w-full py-1 px-3 rounded-xl text-[11px] font-semibold border flex items-center justify-center gap-1 transition hover:opacity-80"
                      style={{ backgroundColor: theme.surfaceHi, borderColor: theme.border, color: theme.text }}
                    >
                      <Globe className="w-3 h-3 text-blue-400" />
                      <span>View Releases on GitHub →</span>
                    </a>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="flex justify-end pt-2 border-t shrink-0" style={{ borderColor: theme.border }}>
                <button
                  onClick={() => setShowAboutModal(false)}
                  className="px-4 py-1.5 rounded-xl text-xs font-bold text-white shadow"
                  style={{ backgroundColor: theme.accent }}
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Simulated Android Package Installer Dialog */}
        {showInstallPromptModal && discoveredRelease && (
          <div className="absolute inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-3 animate-fadeIn">
            <div
              className="w-full max-w-xs rounded-2xl p-4 shadow-2xl border space-y-3.5 text-left"
              style={{
                backgroundColor: isDarkMode ? '#1E293B' : '#FFFFFF',
                borderColor: theme.border
              }}
            >
              <div className="flex items-center gap-2.5 pb-2 border-b" style={{ borderColor: theme.border }}>
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center shrink-0">
                  <Download className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <h4 className="font-bold text-xs" style={{ color: theme.text }}>Android Package Installer</h4>
                  <p className="text-[10px]" style={{ color: theme.muted }}>com.openassist.app</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <OpenAssistLogo style={logoStyle} size={28} theme={isDarkMode ? 'dark' : 'light'} customIcons={customIcons} />
                <div className="space-y-1">
                  <p className="text-xs font-bold" style={{ color: theme.text }}>
                    Update OpenAssist to {discoveredRelease.tag}?
                  </p>
                  <p className="text-[11px] leading-relaxed" style={{ color: theme.muted }}>
                    Do you want to update this application? An existing application will be updated without losing data.
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t" style={{ borderColor: theme.border }}>
                <button
                  onClick={() => setShowInstallPromptModal(false)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold hover:opacity-80 transition"
                  style={{ color: theme.muted }}
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    const newVer = discoveredRelease.tag;
                    setInstalledAppVersion(newVer);
                    setShowInstallPromptModal(false);
                    setDownloadCompletedApk(null);
                    setDiscoveredRelease(null);
                    setUpdateCheckStatus(`✅ OpenAssist is up to date! (${newVer})\nYou have the latest version installed.`);
                    triggerMascotReaction(`Updated to ${newVer}! 🎉`);
                    mascotAudio.playSuccess();
                  }}
                  className="px-4 py-1.5 rounded-xl text-xs font-bold text-white shadow hover:opacity-90 active:scale-95 transition flex items-center gap-1.5"
                  style={{ backgroundColor: '#10B981' }}
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Update</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
