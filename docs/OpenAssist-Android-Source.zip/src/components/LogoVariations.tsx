import React from 'react';
import { PROJECT_FILES } from '../data/projectFiles';

export type LogoStyle =
  | 'owl'
  | 'owl-orbital'
  | 'owl-cosmic'
  | 'owl-talons'
  | 'owl-radar'
  | 'owl-wings'
  | 'owl-monocle'
  | 'owl-minimal'
  | 'fox'
  | 'fox-orbital'
  | 'fox-cyber'
  | 'fox-paws'
  | 'fox-firefly'
  | 'fox-halo'
  | 'fox-headset'
  | 'fox-monocle'
  | 'fox-minimal'
  | 'bat'
  | 'otter'
  | 'chameleon'
  | 'tanuki'
  | 'sprite'
  | 'kitten'
  | 'firefly'
  | 'axolotl'
  | 'orbital'
  | 'whale'
  | (string & {});

export interface CustomIconItem {
  id: string;
  name: string;
  dataUrl: string;
  fileType: string;
  isSvg?: boolean;
  svgText?: string;
  createdAt: number;
}

export interface LogoProps {
  style?: LogoStyle;
  size?: number | string;
  className?: string;
  theme?: 'dark' | 'light' | 'mono-white' | 'mono-black';
  customIcon?: CustomIconItem;
  customIcons?: CustomIconItem[];
}

/**
 * Universal OpenAssist Mascot & Logo Component
 * Renders the authentic, high-quality vector mascot artwork directly
 * from canonical vector assets in assets/mascots/*.svg.
 */
export const OpenAssistLogo: React.FC<LogoProps> = ({
  style = 'owl-orbital',
  size = 64,
  className = '',
  theme = 'dark',
  customIcon,
  customIcons = [],
}) => {
  // Check for custom icon match
  const matchedCustom =
    customIcon ||
    (typeof style === 'string' && style.startsWith('custom:')
      ? customIcons.find((c) => c.id === style.replace('custom:', ''))
      : undefined);

  if (matchedCustom) {
    return (
      <div
        className={`inline-flex items-center justify-center overflow-hidden rounded-xl ${className}`}
        style={{ width: size, height: size }}
        title={matchedCustom.name}
      >
        {matchedCustom.isSvg && matchedCustom.svgText ? (
          <div
            className="w-full h-full flex items-center justify-center [&>svg]:w-full [&>svg]:h-full"
            dangerouslySetInnerHTML={{ __html: matchedCustom.svgText }}
          />
        ) : (
          <img
            src={matchedCustom.dataUrl}
            alt={matchedCustom.name}
            className="w-full h-full object-contain"
          />
        )}
      </div>
    );
  }

  // Canonical alias resolution
  const rawStyle = (style || 'owl-orbital').toString().toLowerCase().trim();
  const aliasMap: Record<string, string> = {
    default: 'owl-orbital',
    ozzy: 'owl-orbital',
    'owl-default': 'owl',
    pip: 'fox',
    fennec: 'fox',
    cat: 'kitten',
    byte: 'kitten',
    luna: 'kitten',
    echo: 'bat',
    'bat-ultrasonic': 'bat',
    'echo-bat': 'bat',
    nova: 'otter',
    'otter-cosmic': 'otter',
    'nova-otter': 'otter',
    pico: 'chameleon',
    'chameleon-lens': 'chameleon',
    'pico-chameleon': 'chameleon',
    taro: 'tanuki',
    'tanuki-vault': 'tanuki',
    'taro-tanuki': 'tanuki',
    momo: 'tanuki',
    ollie: 'sprite',
    bolt: 'sprite',
    'ollie-sprite': 'sprite',
    lumi: 'firefly',
    'lumi-firefly': 'firefly',
    kiko: 'axolotl',
    'kiko-axolotl': 'axolotl',
    iris: 'orbital',
    'iris-loop': 'orbital',
    'kube-loop': 'orbital',
    moby: 'whale',
    'moby-ray': 'whale',
  };

  let canonicalId = aliasMap[rawStyle] || rawStyle;

  // If canonicalId doesn't directly map to an existing SVG in PROJECT_FILES, perform intelligent substring resolution
  const hasSvg = (id: string) =>
    !!(
      PROJECT_FILES[`assets/mascots/${id}.svg`] ||
      PROJECT_FILES[`/assets/mascots/${id}.svg`] ||
      PROJECT_FILES[`${id}.svg`] ||
      PROJECT_FILES[id]
    );

  if (!hasSvg(canonicalId)) {
    if (canonicalId.includes('bat') || canonicalId.includes('echo')) canonicalId = 'bat';
    else if (canonicalId.includes('otter') || canonicalId.includes('nova')) canonicalId = 'otter';
    else if (canonicalId.includes('chameleon') || canonicalId.includes('pico')) canonicalId = 'chameleon';
    else if (canonicalId.includes('tanuki') || canonicalId.includes('taro') || canonicalId.includes('momo')) canonicalId = 'tanuki';
    else if (canonicalId.includes('kitten') || canonicalId.includes('byte') || canonicalId.includes('cat') || canonicalId.includes('luna')) canonicalId = 'kitten';
    else if (canonicalId.includes('sprite') || canonicalId.includes('ollie') || canonicalId.includes('bolt')) canonicalId = 'sprite';
    else if (canonicalId.includes('firefly') || canonicalId.includes('lumi')) canonicalId = 'firefly';
    else if (canonicalId.includes('axolotl') || canonicalId.includes('kiko')) canonicalId = 'axolotl';
    else if (canonicalId.includes('orbital') || canonicalId.includes('iris') || canonicalId.includes('kube')) canonicalId = 'orbital';
    else if (canonicalId.includes('whale') || canonicalId.includes('moby')) canonicalId = 'whale';
    else if (canonicalId.startsWith('fox')) canonicalId = 'fox';
    else if (canonicalId.startsWith('owl')) canonicalId = 'owl-orbital';
  }

  const projectKey = `assets/mascots/${canonicalId}.svg`;
  const defaultKey = 'assets/mascots/owl-orbital.svg';

  const svgRaw =
    PROJECT_FILES[projectKey] ||
    PROJECT_FILES[`/assets/mascots/${canonicalId}.svg`] ||
    PROJECT_FILES[`${canonicalId}.svg`] ||
    PROJECT_FILES[canonicalId] ||
    PROJECT_FILES[defaultKey] ||
    '';

  const filterStyle =
    theme === 'mono-white'
      ? 'brightness(0) invert(1)'
      : theme === 'mono-black'
      ? 'brightness(0)'
      : undefined;

  return (
    <div
      className={`inline-flex items-center justify-center shrink-0 select-none overflow-hidden ${className}`}
      style={{
        width: size,
        height: size,
        filter: filterStyle,
      }}
      title={`OpenAssist Mascot ${canonicalId}`}
    >
      {svgRaw ? (
        <div
          className="w-full h-full flex items-center justify-center [&>svg]:w-full [&>svg]:h-full [&>svg]:max-w-full [&>svg]:max-h-full [&>svg]:object-contain pointer-events-none select-none transition-transform duration-200"
          dangerouslySetInnerHTML={{ __html: svgRaw }}
        />
      ) : (
        <img
          src={`/assets/mascots/${canonicalId}.svg`}
          alt={`OpenAssist Mascot ${canonicalId}`}
          className="w-full h-full object-contain pointer-events-none select-none transition-transform duration-200"
          loading="lazy"
        />
      )}
    </div>
  );
};

// Convenience component wrappers that all resolve to canonical mascots
export const LogoOwlOrbital: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="owl-orbital" {...props} />
);
export const LogoOwl: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="owl" {...props} />
);
export const LogoOwlCosmic: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="owl-cosmic" {...props} />
);
export const LogoOwlTalons: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="owl-talons" {...props} />
);
export const LogoOwlRadar: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="owl-radar" {...props} />
);
export const LogoOwlWings: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="owl-wings" {...props} />
);
export const LogoOwlMonocle: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="owl-monocle" {...props} />
);
export const LogoOwlMinimal: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="owl-minimal" {...props} />
);

export const LogoFox: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="fox" {...props} />
);
export const LogoFoxOrbital: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="fox-orbital" {...props} />
);
export const LogoFoxCyber: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="fox-cyber" {...props} />
);
export const LogoFoxPaws: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="fox-paws" {...props} />
);
export const LogoFoxFirefly: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="fox-firefly" {...props} />
);
export const LogoFoxHalo: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="fox-halo" {...props} />
);
export const LogoFoxHeadset: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="fox-headset" {...props} />
);
export const LogoFoxMonocle: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="fox-monocle" {...props} />
);
export const LogoFoxMinimal: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="fox-minimal" {...props} />
);

export const LogoBat: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="bat" {...props} />
);
export const LogoOtter: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="otter" {...props} />
);
export const LogoChameleon: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="chameleon" {...props} />
);
export const LogoTanuki: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="tanuki" {...props} />
);
export const LogoSprite: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="sprite" {...props} />
);
export const LogoKitten: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="kitten" {...props} />
);
export const LogoFirefly: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="firefly" {...props} />
);
export const LogoAxolotl: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="axolotl" {...props} />
);
export const LogoOrbital: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="orbital" {...props} />
);
export const LogoWhale: React.FC<Omit<LogoProps, 'style'>> = (props) => (
  <OpenAssistLogo style="whale" {...props} />
);
