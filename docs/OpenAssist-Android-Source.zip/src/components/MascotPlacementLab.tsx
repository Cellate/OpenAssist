import React from 'react';
import {
  Sparkles, ToggleLeft, ToggleRight, Check, X,
  Layout, Smartphone, MessageSquare, Mic,
  Eye, Cpu, Bell, HelpCircle
} from 'lucide-react';
import { LogoStyle, CustomIconItem, OpenAssistLogo } from './LogoVariations';

export type MascotEmotion = 'idle' | 'scanning' | 'listening' | 'thinking' | 'celebrate';

export interface MascotPlacementConfig {
  floatingEdge: boolean;
  promptBarAnchor: boolean;
  imeDictationBar: boolean;
  emptyStateGuide: boolean;
  qsTile: boolean;
  homescreenWidget: boolean;
  dynamicPunchHole: boolean;
  reactiveEmotions: boolean;
  cicdBanner: boolean;
}

export const DEFAULT_PLACEMENT_CONFIG: MascotPlacementConfig = {
  floatingEdge: true,
  promptBarAnchor: true,
  imeDictationBar: true,
  emptyStateGuide: true,
  qsTile: true,
  homescreenWidget: true,
  dynamicPunchHole: true,
  reactiveEmotions: true,
  cicdBanner: true,
};

export const ALL_OFF_CONFIG: MascotPlacementConfig = {
  floatingEdge: false,
  promptBarAnchor: false,
  imeDictationBar: false,
  emptyStateGuide: false,
  qsTile: false,
  homescreenWidget: false,
  dynamicPunchHole: false,
  reactiveEmotions: false,
  cicdBanner: false,
};

interface MascotPlacementLabProps {
  config: MascotPlacementConfig;
  onChangeConfig: (newConfig: MascotPlacementConfig) => void;
  activeEmotion: MascotEmotion;
  onChangeEmotion: (emotion: MascotEmotion) => void;
  currentLogo: LogoStyle;
  customIcons?: CustomIconItem[];
  mascotName?: string;
}

export const MascotPlacementLab: React.FC<MascotPlacementLabProps> = ({
  config,
  onChangeConfig,
  activeEmotion,
  onChangeEmotion,
  currentLogo,
  customIcons = [],
  mascotName = 'Ozzy',
}) => {
  const activeCount = Object.values(config).filter(Boolean).length;
  const totalCount = Object.keys(config).length;
  const allOn = activeCount === totalCount;
  const allOff = activeCount === 0;

  const toggleSingle = (key: keyof MascotPlacementConfig) => {
    onChangeConfig({
      ...config,
      [key]: !config[key],
    });
  };

  const setAll = (enabled: boolean) => {
    onChangeConfig({
      floatingEdge: enabled,
      promptBarAnchor: enabled,
      imeDictationBar: enabled,
      emptyStateGuide: enabled,
      qsTile: enabled,
      homescreenWidget: enabled,
      dynamicPunchHole: enabled,
      reactiveEmotions: enabled,
      cicdBanner: enabled,
    });
  };

  const applyPreset = (preset: 'os_native' | 'in_overlay' | 'all') => {
    if (preset === 'all') {
      setAll(true);
    } else if (preset === 'os_native') {
      onChangeConfig({
        floatingEdge: true,
        promptBarAnchor: false,
        imeDictationBar: true,
        emptyStateGuide: false,
        qsTile: true,
        homescreenWidget: true,
        dynamicPunchHole: true,
        reactiveEmotions: true,
        cicdBanner: true,
      });
    } else if (preset === 'in_overlay') {
      onChangeConfig({
        floatingEdge: true,
        promptBarAnchor: true,
        imeDictationBar: true,
        emptyStateGuide: true,
        qsTile: false,
        homescreenWidget: false,
        dynamicPunchHole: true,
        reactiveEmotions: true,
        cicdBanner: false,
      });
    }
  };

  const PROTOTYPE_ITEMS: {
    key: keyof MascotPlacementConfig;
    number: number;
    title: string;
    subtitle: string;
    icon: React.ReactNode;
    category: 'System' | 'Overlay' | 'Input & Audio' | 'CI & Docs';
    badge: string;
  }[] = [
    {
      key: 'floatingEdge',
      number: 1,
      title: 'Floating Edge Pill / Handle',
      subtitle: 'Persistent dockable bubble on phone edge with resting & active states',
      icon: <Layout className="w-3.5 h-3.5" />,
      category: 'Overlay',
      badge: 'Screen Margin',
    },
    {
      key: 'promptBarAnchor',
      number: 2,
      title: 'In-Prompt Bar Anchor',
      subtitle: 'Interactive mascot badge next to input that opens quick AI model switcher',
      icon: <MessageSquare className="w-3.5 h-3.5" />,
      category: 'Overlay',
      badge: 'Input Bar',
    },
    {
      key: 'imeDictationBar',
      number: 3,
      title: 'IME Keyboard Audio Bar',
      subtitle: 'Android keyboard dictation header with pulsing soundwave ears & live waveform',
      icon: <Mic className="w-3.5 h-3.5" />,
      category: 'Input & Audio',
      badge: 'Voice IME',
    },
    {
      key: 'emptyStateGuide',
      number: 4,
      title: 'First-Run Calibration Guide',
      subtitle: 'Friendly mascot card holding search lasso with 1-click test circle button',
      icon: <HelpCircle className="w-3.5 h-3.5" />,
      category: 'Overlay',
      badge: 'Empty State',
    },
    {
      key: 'qsTile',
      number: 5,
      title: 'Quick Settings (QS) Tile Shade',
      subtitle: 'Android 14 pull-down notification shade tile with mascot adaptive icon',
      icon: <Bell className="w-3.5 h-3.5" />,
      category: 'System',
      badge: 'System QS',
    },
    {
      key: 'homescreenWidget',
      number: 6,
      title: 'Homescreen Glance Widget',
      subtitle: 'Material You 2x2 assistant clock & instant search widget on phone home',
      icon: <Smartphone className="w-3.5 h-3.5" />,
      category: 'System',
      badge: 'Widget',
    },
    {
      key: 'dynamicPunchHole',
      number: 7,
      title: 'Punch-Hole Dynamic Island',
      subtitle: 'Camera cutout morphs into an audio pill with mascot peeking out',
      icon: <Eye className="w-3.5 h-3.5" />,
      category: 'System',
      badge: 'Camera Island',
    },
    {
      key: 'reactiveEmotions',
      number: 8,
      title: 'Reactive Mascot Moods',
      subtitle: 'Interactive mood switcher: Idle, Scanning, Listening, Thinking, Celebrate',
      icon: <Sparkles className="w-3.5 h-3.5" />,
      category: 'Overlay',
      badge: 'Moods',
    },
    {
      key: 'cicdBanner',
      number: 9,
      title: 'CI/CD Build Engineer Bot',
      subtitle: 'Engineer mascot badge in Download tab verifying Gradle 8.7 & cloud runner',
      icon: <Cpu className="w-3.5 h-3.5" />,
      category: 'CI & Docs',
      badge: 'Build Tab',
    },
  ];

  return (
    <div className="bg-[#14161D] border border-[#2B2E3D] rounded-3xl p-4 sm:p-5 shadow-2xl mb-6 text-left transition-all">
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#1C1F2B] border border-indigo-500/30 flex items-center justify-center p-1.5 shadow-md shadow-indigo-500/10 shrink-0">
            <OpenAssistLogo style={currentLogo} size={28} theme="dark" customIcons={customIcons} />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                Mascot Placement Lab &amp; Interactive Prototypes
              </h2>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold">
                {activeCount} of {totalCount} Active
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              Live interactive prototypes for every suggested placement of <strong className="text-zinc-200">{mascotName}</strong> across Android OS &amp; overlay.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-stretch lg:self-auto">
          <div className="flex items-center bg-[#1B1D26] p-1 rounded-2xl border border-white/10 shadow-inner">
            <button
              onClick={() => setAll(true)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                allOn
                  ? 'bg-emerald-500 text-emerald-950 shadow-md scale-[1.02]'
                  : 'text-zinc-300 hover:text-white hover:bg-white/5'
              }`}
              title="Turn all 9 prototypes ON simultaneously"
            >
              <Check className="w-3.5 h-3.5" />
              <span>All ON</span>
            </button>
            <button
              onClick={() => setAll(false)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                allOff
                  ? 'bg-rose-500 text-white shadow-md scale-[1.02]'
                  : 'text-zinc-300 hover:text-white hover:bg-white/5'
              }`}
              title="Turn all prototypes OFF (Clean stock view)"
            >
              <X className="w-3.5 h-3.5" />
              <span>All OFF</span>
            </button>
          </div>

          <div className="hidden sm:flex items-center gap-1 bg-[#181A22] p-1 rounded-2xl border border-white/5 text-[11px]">
            <span className="text-zinc-400 px-2 font-mono text-[10px] uppercase font-bold">Presets:</span>
            <button
              onClick={() => applyPreset('os_native')}
              className="px-2.5 py-1 rounded-lg text-zinc-300 hover:text-white hover:bg-white/10 transition"
              title="Showcase OS-level integrations: Edge Handle + QS Tile + Homescreen Widget + IME Bar"
            >
              Android OS
            </button>
            <button
              onClick={() => applyPreset('in_overlay')}
              className="px-2.5 py-1 rounded-lg text-zinc-300 hover:text-white hover:bg-white/10 transition"
              title="Showcase Search Overlay integrations: Prompt Bar + Calibration Guide + Dynamic Island"
            >
              In-Overlay
            </button>
          </div>
        </div>
      </div>

      {config.reactiveEmotions && (
        <div className="pt-3 pb-3 flex flex-wrap items-center justify-between gap-3 border-b border-white/5 text-xs">
          <div className="flex items-center gap-2 text-zinc-300">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span className="font-semibold text-zinc-200">Test Mascot Emotion:</span>
            <span className="text-zinc-400 text-[11px] hidden sm:inline">(Controls all live mascot reactions)</span>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {(
              [
                { id: 'idle', label: 'Idle / Float', desc: 'Calm resting' },
                { id: 'scanning', label: 'Scanning', desc: 'Radar lenses active' },
                { id: 'listening', label: 'Listening', desc: 'Soundwaves pulsing' },
                { id: 'thinking', label: 'Thinking', desc: 'AI Spark firing' },
                { id: 'celebrate', label: 'Celebrate', desc: 'Happy win wink' },
              ] as const
            ).map((em) => (
              <button
                key={em.id}
                onClick={() => onChangeEmotion(em.id)}
                className={`px-2.5 py-1 rounded-xl text-[11px] font-semibold transition-all ${
                  activeEmotion === em.id
                    ? 'bg-[#8AB4F8] text-[#0A1835] shadow-md scale-105'
                    : 'bg-[#1C1E28] text-zinc-300 hover:text-white border border-white/5'
                }`}
                title={em.desc}
              >
                {em.label}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2.5 pt-3">
        {PROTOTYPE_ITEMS.map((item) => {
          const isEnabled = config[item.key];
          return (
            <div
              key={item.key}
              onClick={() => toggleSingle(item.key)}
              className={`p-3 rounded-2xl border cursor-pointer select-none transition-all flex items-start justify-between gap-3 group ${
                isEnabled
                  ? 'bg-[#1C1F2C] border-indigo-500/40 shadow-md shadow-indigo-500/5'
                  : 'bg-[#16171F] border-white/5 hover:border-white/10 opacity-70 hover:opacity-90'
              }`}
            >
              <div className="flex items-start gap-2.5 min-w-0">
                <div
                  className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                    isEnabled
                      ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                      : 'bg-zinc-800 text-zinc-500 border border-zinc-700'
                  }`}
                >
                  {item.icon}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[10px] font-mono font-bold text-zinc-400">
                      #{item.number}
                    </span>
                    <h3 className={`text-xs font-bold tracking-tight truncate ${isEnabled ? 'text-white' : 'text-zinc-400'}`}>
                      {item.title}
                    </h3>
                  </div>
                  <p className="text-[11px] text-zinc-400 line-clamp-2 mt-0.5 leading-snug">
                    {item.subtitle}
                  </p>
                  <span className="inline-block mt-1 text-[9px] font-mono px-1.5 py-0.2 rounded bg-white/5 text-zinc-400 border border-white/5">
                    {item.badge}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  toggleSingle(item.key);
                }}
                className={`p-1 rounded-xl transition shrink-0 ${
                  isEnabled ? 'text-indigo-400' : 'text-zinc-600 group-hover:text-zinc-400'
                }`}
                title={isEnabled ? 'Click to disable' : 'Click to enable'}
              >
                {isEnabled ? (
                  <ToggleRight className="w-6 h-6 text-indigo-400" />
                ) : (
                  <ToggleLeft className="w-6 h-6 text-zinc-600" />
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
