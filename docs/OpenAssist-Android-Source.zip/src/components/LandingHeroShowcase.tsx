import React, { useState } from 'react';
import {
  Download,
  ShieldCheck,
  Cpu,
  Smartphone,
  Sparkles,
  Terminal,
  CheckCircle2,
  ChevronRight,
  Lock,
  EyeOff,
  Zap,
  Globe,
  Layers,
  ArrowRight,
  Play,
  Copy,
  Check,
  Star,
  RefreshCw,
  Volume2,
  Shield,
  ExternalLink,
  Sliders,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Heart
} from 'lucide-react';
import { OpenAssistLogo, LogoStyle, CustomIconItem } from './LogoVariations';
import { PhoneSimulator } from './PhoneSimulator';
import { APP_VERSION } from '../utils/version';
import { mascotAudio } from '../utils/mascotAudio';

interface LandingHeroShowcaseProps {
  currentLogo: LogoStyle;
  customIcons: CustomIconItem[];
  onSelectLogo: (logo: LogoStyle) => void;
  onNavigateToTab: (tab: 'simulator' | 'studio' | 'placement' | 'readme' | 'code' | 'download') => void;
  onOpenSetupWizard: () => void;
  onOpenLogoSwitcher?: () => void;
}

interface MascotHeroData {
  id: string;
  logoStyle: LogoStyle;
  name: string;
  archetype: string;
  badge: string;
  badgeColor: string;
  accentColor: string;
  soundType: 'chirp' | 'boop' | 'sonar' | 'purr' | 'bubble';
  soundFreq: string;
  lore: string;
  role: string;
  quote: string;
}

const MASCOTS_SHOWCASE: MascotHeroData[] = [
  {
    id: 'owl-orbital',
    logoStyle: 'owl-orbital',
    name: 'Ozzy Sentinel',
    archetype: 'Flagship Night-Vision AI Sentinel',
    badge: 'Default Flagship',
    badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    accentColor: 'from-emerald-500/20 to-teal-500/20 border-emerald-500/40 text-emerald-300',
    soundType: 'chirp',
    soundFreq: '880Hz → 1320Hz Dual Harmonic',
    lore: 'Ozzy stands guard over private pixels. Stationed within the secure enclave of your Android device, Ozzy enforces zero-memory screenshot scrubbing and zero telemetry transmission.',
    role: 'Primary guardian of the 10-layer security perimeter and night-vision overlay.',
    quote: '"Your screen belongs to you alone. Not a single pixel leaves without your command."'
  },
  {
    id: 'fox-cyber',
    logoStyle: 'fox-cyber',
    name: 'Pip Nexus',
    archetype: 'Master Synthesis Lasso Fox',
    badge: 'Precision Lasso',
    badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    accentColor: 'from-amber-500/20 to-orange-500/20 border-amber-500/40 text-amber-300',
    soundType: 'chirp',
    soundFreq: '600Hz → 900Hz Ascending Staccato',
    lore: 'Agile and lightning-fast, Pip calibrates the glowing neon lasso with 8-point touch anchors and sub-millimeter geometric accuracy across all display refresh rates.',
    role: 'Coordinates high-speed gesture tracking, 8-handle crop manipulation, and 0.6x-12x zoom.',
    quote: '"Draw anywhere. I will isolate the exact pixel boundaries in sub-millimeter precision."'
  },
  {
    id: 'bat',
    logoStyle: 'bat',
    name: 'Echo the Bat',
    archetype: 'Ultrasonic Whisper Voice Scout',
    badge: 'Whisper C++ JNI',
    badgeColor: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
    accentColor: 'from-purple-500/20 to-indigo-500/20 border-purple-500/40 text-purple-300',
    soundType: 'sonar',
    soundFreq: '440Hz Sub-bass Sonar Ping',
    lore: 'Born in the acoustic spectrum, Echo powers the embedded Whisper.cpp C++ inference engine. Echo transcribes spoken words on-device with zero cloud telemetry.',
    role: 'Direct JNI bridge to GGML quantized voice models with sliding-window anti-stutter buffer.',
    quote: '"Speak freely in any quiet room or loud subway. Your voice never leaves your device."'
  },
  {
    id: 'otter',
    logoStyle: 'otter',
    name: 'Nova the Otter',
    archetype: 'Deep-Query Cosmic Navigator',
    badge: 'Multi-AI Router',
    badgeColor: 'bg-sky-500/10 text-sky-400 border-sky-500/30',
    accentColor: 'from-sky-500/20 to-blue-500/20 border-sky-500/40 text-sky-300',
    soundType: 'bubble',
    soundFreq: '520Hz + 650Hz Resonant Chord',
    lore: 'Gliding effortlessly across heterogeneous neural architectures, Nova dispatches visual queries to Gemini, Claude 3.7, ChatGPT, DeepSeek, or local Ollama servers.',
    role: 'Directs synthetic drag-and-drop file transfer and BYOK multi-provider routing.',
    quote: '"Never be trapped by a single AI vendor. Switch models like switching tabs."'
  },
  {
    id: 'chameleon',
    logoStyle: 'chameleon',
    name: 'Pico the Chameleon',
    archetype: '360° Multi-Modal Visionary',
    badge: 'Multi-Modal Vision',
    badgeColor: 'bg-teal-500/10 text-teal-400 border-teal-500/30',
    accentColor: 'from-teal-500/20 to-emerald-500/20 border-teal-500/40 text-teal-300',
    soundType: 'chirp',
    soundFreq: '740Hz Adaptive Frequency Glide',
    lore: 'Adapting seamlessly to foldables, tablets, multi-window splits, and portrait displays, Pico ensures your circle-to-search interface stays razor-sharp in any orientation.',
    role: 'Handles fluid orientation adjustments, dynamic DPI scaling, and multi-display anchors.',
    quote: '"Fold, flip, rotate, or split. True open software molds itself to your lifestyle."'
  },
  {
    id: 'tanuki',
    logoStyle: 'tanuki',
    name: 'Taro the Tanuki',
    archetype: 'Pixel Transformer & Cache Warden',
    badge: 'Security Vault',
    badgeColor: 'bg-orange-500/10 text-orange-400 border-orange-500/30',
    accentColor: 'from-orange-500/20 to-amber-500/20 border-orange-500/40 text-orange-300',
    soundType: 'boop',
    soundFreq: '330Hz Warm Earthy Tone',
    lore: 'Taro holds the master keys in the Android Keystore hardware enclave. All API keys and sensitive tokens are locked with AES-256-GCM encryption under Taro\'s watchful eye.',
    role: 'Hardware-backed Android Keystore cryptography and instant cache disposal.',
    quote: '"Even if memory is inspected, only encrypted ciphertext remains behind."'
  },
  {
    id: 'kitten',
    logoStyle: 'kitten',
    name: 'Byte the Kitten',
    archetype: 'Pocket Dumpling Companion',
    badge: 'Zero-Telemetry',
    badgeColor: 'bg-pink-500/10 text-pink-400 border-pink-500/30',
    accentColor: 'from-pink-500/20 to-rose-500/20 border-pink-500/40 text-pink-300',
    soundType: 'purr',
    soundFreq: '480Hz Warm Resonant Purr',
    lore: 'A lovable marshmallow kitten perched softly on your screen portal. Byte keeps your clipboard safe and brings cheerful warmth to every interaction.',
    role: 'Provides friendly zero-telemetry clipboard isolation and comforting interaction feedback.',
    quote: '"Purr-fect day to learn together! Your pocket assistant is always right here."'
  },
  {
    id: 'firefly',
    logoStyle: 'firefly',
    name: 'Lumi the Firefly',
    archetype: 'Bioluminescent Screen Radar',
    badge: 'Pixel Radar',
    badgeColor: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30',
    accentColor: 'from-yellow-500/20 to-amber-500/20 border-yellow-500/40 text-yellow-300',
    soundType: 'chirp',
    soundFreq: '950Hz Crystalline Harmonic',
    lore: 'Glowing brightly in dark OLED displays, Lumi illuminates the exact text lines and equations under your lasso circle with zero halo bleeding.',
    role: 'Powers high-contrast OLED night mode highlights and selective text illumination.',
    quote: '"A little spark of insight can illuminate the darkest questions on screen."'
  },
  {
    id: 'axolotl',
    logoStyle: 'axolotl',
    name: 'Kiko the Axolotl',
    archetype: 'Astronaut Vision Explorer',
    badge: 'Sensory Explorer',
    badgeColor: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
    accentColor: 'from-rose-500/20 to-pink-500/20 border-rose-500/40 text-rose-300',
    soundType: 'bubble',
    soundFreq: '620Hz Water-Chirp Acoustic',
    lore: 'Wearing a cosmic bubble helmet, Kiko explores visual data with boundless enthusiasm and regenerates query sessions cleanly in isolated memory.',
    role: 'Guarantees isolated memory sandboxes and clean lifecycle session resets.',
    quote: '"Every question is an adventure. Let\'s explore something wonderful today!"'
  },
  {
    id: 'sprite',
    logoStyle: 'sprite',
    name: 'Ollie the Sprite',
    archetype: 'Cosmic Spectacles Droid',
    badge: 'Rapid OCR',
    badgeColor: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
    accentColor: 'from-cyan-500/20 to-blue-500/20 border-cyan-500/40 text-cyan-300',
    soundType: 'chirp',
    soundFreq: '1100Hz Spark Chime',
    lore: 'Floating buoyantly with twin search spectacles, Ollie zips across multi-window displays to bring instant OCR text selection and translation in milliseconds.',
    role: 'Accelerates instant floating OCR text selection and clipboard parsing.',
    quote: '"Cosmic spark charged up! Ready to bring speed and sparkle to your screen."'
  },
  {
    id: 'orbital',
    logoStyle: 'orbital',
    name: 'Iris Loop',
    archetype: 'Geometric Quantum Sentinel',
    badge: 'Kube-Loop Iris',
    badgeColor: 'bg-violet-500/10 text-violet-400 border-violet-500/30',
    accentColor: 'from-violet-500/20 to-purple-500/20 border-violet-500/40 text-violet-300',
    soundType: 'sonar',
    soundFreq: '400Hz Deep Resonance',
    lore: 'A mesmerizing concentric iris ring providing pure geometric focus. Iris maintains perfect mathematical calibration across any screen aspect ratio.',
    role: 'Enforces sub-pixel geometric crop calibration and aspect ratio preservation.',
    quote: '"Geometric symmetry locked. Your focus area is precisely isolated."'
  },
  {
    id: 'whale',
    logoStyle: 'whale',
    name: 'Moby-Ray',
    archetype: 'Oceanic Deep-Query Ray',
    badge: 'Deep Knowledge',
    badgeColor: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    accentColor: 'from-blue-500/20 to-indigo-500/20 border-blue-500/40 text-blue-300',
    soundType: 'sonar',
    soundFreq: '300Hz Low Oceanic Pulse',
    lore: 'Gliding peacefully through the vast ocean of human knowledge, Moby-Ray handles large multi-page research documents and complex long-form queries.',
    role: 'Manages multi-document context stitching and long-form research queries.',
    quote: '"Navigating the boundless ocean of ideas together with you."'
  }
];

interface SecurityLayerInfo {
  number: number;
  title: string;
  threat: string;
  defense: string;
  technicalDetails: string;
  status: string;
}

const SECURITY_LAYERS: SecurityLayerInfo[] = [
  {
    number: 1,
    title: 'Android Keystore AES-256-GCM Hardware Vault',
    threat: 'Plaintext API keys dumped from SharedPreferences or app backups.',
    defense: 'Hardware-backed cryptographic keys generated inside the device TEE / StrongBox.',
    technicalDetails: 'Uses KeyGenParameterSpec with PURPOSE_ENCRYPT | PURPOSE_DECRYPT, GCMNoPadding, and authenticated 128-bit authentication tags. Keys never touch RAM in cleartext.',
    status: 'Hardened & Verified'
  },
  {
    number: 2,
    title: 'Zero-Memory Screenshot Buffer Scrubbing',
    threat: 'Residual screen bitmaps lingering in heap memory accessible via memory analysis.',
    defense: 'Explicit byte overwriting with zero-fill and bitmap.recycle() immediately upon overlay dismiss.',
    technicalDetails: 'Allocates direct ByteBuffers, zeroes pixel arrays before garbage collection, and clears MediaProjection virtual displays within 5ms of gesture exit.',
    status: 'Hardened & Verified'
  },
  {
    number: 3,
    title: 'Scoped Storage Sandbox (No External Storage)',
    threat: 'Malicious apps reading saved screen captures from shared public storage directories.',
    defense: 'Captures saved solely to internal app cache (context.cacheDir) with strict FileProvider scopes.',
    technicalDetails: 'No READ_EXTERNAL_STORAGE or WRITE_EXTERNAL_STORAGE requested. Image handoffs use transient FLAG_GRANT_READ_URI_PERMISSION with single-use intent expiration.',
    status: 'Hardened & Verified'
  },
  {
    number: 4,
    title: 'Strict Content Security Policy (CSP) in WebView',
    threat: 'Cross-Site Scripting (XSS) or remote code injection inside assistant web views.',
    defense: 'Hardened CSP header: default-src \'self\'; script-src \'self\'; object-src \'none\'.',
    technicalDetails: 'Blocks inline eval(), disallows external remote scripts, and runs all AI web wrappers in isolated sandboxed processes with JavaScriptInterface restrictions.',
    status: 'Hardened & Verified'
  },
  {
    number: 5,
    title: 'WebRTC Camera & Microphone Hardware Gates',
    threat: 'Rogue web agents triggering continuous background eavesdropping without user knowledge.',
    defense: 'PermissionRequest.deny() by default; explicit hardware consent dialog with host whitelisting.',
    technicalDetails: 'Restricted exclusively to explicit user whitelisted AI domains. Automatic hardware indicator LEDs in status bar remain fully transparent.',
    status: 'Hardened & Verified'
  },
  {
    number: 6,
    title: 'Network Security Config: Global HTTPS + LAN Scoping',
    threat: 'Cleartext HTTP interception / man-in-the-middle attacks across public Wi-Fi networks.',
    defense: 'Enforces HTTPS with TLS 1.3 globally; cleartext allowed strictly for private RFC-1918 LANs.',
    technicalDetails: 'network_security_config.xml permits cleartext only for 192.168.0.0/16, 10.0.0.0/8, 172.16.0.0/12, and 127.0.0.1 (Ollama / LM Studio home servers).',
    status: 'Hardened & Verified'
  },
  {
    number: 7,
    title: 'Zero-Telemetry & Analytic Blackhole',
    threat: 'Behavioral tracking, device fingerprinting, advertising IDs, or telemetry beacons.',
    defense: 'Zero telemetry libraries. No Firebase Analytics, no Sentry, no Google Play Analytics.',
    technicalDetails: 'Audited build tree: zero tracking dependencies in package.json or build.gradle.kts. Network inspection shows 0 outbound packets except explicit user queries.',
    status: 'Hardened & Verified'
  },
  {
    number: 8,
    title: 'Exported Component Lockdown',
    threat: 'Third-party malicious apps invoking internal activities or faking assistant sessions.',
    defense: 'android:exported="false" on all internal components with signature-level permissions.',
    technicalDetails: 'Only AssistService and AssistSessionService carry the official BIND_VOICE_INTERACTION system permission enforced directly by the Android OS kernel.',
    status: 'Hardened & Verified'
  },
  {
    number: 9,
    title: 'Native C++ Whisper JNI Memory Protection',
    threat: 'Buffer overflow or heap corruption during native audio stream processing.',
    defense: 'Hardened C++ NDK compiler flags with stack canaries (-fstack-protector-strong) and ASLR.',
    technicalDetails: 'Compiled with Clang 17, RELRO full, no-exec stack, and sanitized audio input buffers limited to strict 16kHz 16-bit mono PCM arrays.',
    status: 'Hardened & Verified'
  },
  {
    number: 10,
    title: 'GNU General Public License v3 Source Transparency',
    threat: 'Hidden backdoors, telemetry toggles, or proprietary algorithmic bias.',
    defense: '100% public source code under GNU GPLv3. Anyone can inspect, build, and verify the binary.',
    technicalDetails: 'Reproducible builds supported with standard Gradle 8.7 and NDK 25.2. SHA-256 release checksums published alongside every GitHub release artifact.',
    status: 'Hardened & Verified'
  }
];

export const LandingHeroShowcase: React.FC<LandingHeroShowcaseProps> = ({
  currentLogo,
  customIcons,
  onSelectLogo,
  onNavigateToTab,
  onOpenSetupWizard,
  onOpenLogoSwitcher,
}) => {
  const [selectedMascotIndex, setSelectedMascotIndex] = useState(0);
  const [activeSecurityLayer, setActiveSecurityLayer] = useState(0);
  const [copiedSha, setCopiedSha] = useState(false);
  const [copiedAdb, setCopiedAdb] = useState(false);
  const [demoSearchState, setDemoSearchState] = useState<'idle' | 'circled' | 'analyzing' | 'result'>('circled');
  const [demoSelectedEngine, setDemoSelectedEngine] = useState('Gemini 2.5');
  const [simulatorMode, setSimulatorMode] = useState<'full' | 'quick'>('full');

  const activeMascot = MASCOTS_SHOWCASE[selectedMascotIndex];

  const handlePlayMascotChirp = (soundType: string) => {
    if (soundType === 'boop') mascotAudio.playBoop();
    else if (soundType === 'sonar') mascotAudio.playChirp();
    else if (soundType === 'bubble') mascotAudio.playSuccess();
    else if (soundType === 'purr') mascotAudio.playTap();
    else mascotAudio.playChirp();
  };

  const sha256Checksum = '9c4f7b2a6e1d8841b80c3e9812df09a5b48721c60f23b184e9124a9821bb461e';
  const adbInstallCmd = `adb install -r OpenAssist-${APP_VERSION.version}.apk`;

  const copySha = () => {
    navigator.clipboard.writeText(sha256Checksum);
    setCopiedSha(true);
    setTimeout(() => setCopiedSha(false), 2000);
  };

  const copyAdb = () => {
    navigator.clipboard.writeText(adbInstallCmd);
    setCopiedAdb(true);
    setTimeout(() => setCopiedAdb(false), 2000);
  };

  return (
    <div className="space-y-16 pb-16 text-slate-100">
      {/* =========================================================================
          HERO SECTION: High-converting, inspiring, direct APK download & trust
         ========================================================================= */}
      <section id="hero-showcase" className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900/90 via-slate-950 to-slate-950 border border-slate-800/80 p-6 sm:p-10 lg:p-14 shadow-2xl">
        {/* Ambient Glows */}
        <div className="absolute top-0 left-1/4 -translate-x-1/2 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/3 right-10 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-5xl mx-auto flex flex-col items-center text-center space-y-8">
          {/* Release Badge */}
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-slate-800/90 border border-indigo-500/30 text-indigo-300 text-xs sm:text-sm font-semibold shadow-inner">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span>OpenAssist {APP_VERSION.displayName} Native Release</span>
            <span className="text-slate-500">•</span>
            <span className="text-emerald-400 font-mono">100% Free &amp; Open Source</span>
            <span className="text-slate-500 hidden sm:inline">•</span>
            <span className="text-slate-400 hidden sm:inline">Zero Telemetry</span>
          </div>

          {/* Main Headline */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight max-w-4xl">
            Circle to Search &amp; Voice AI on{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
              Any Android Phone
            </span>
          </h1>

          {/* Subtitle / Value Proposition */}
          <p className="text-base sm:text-lg lg:text-xl text-slate-300 max-w-3xl leading-relaxed font-normal">
            No expensive flagship phone required. Circle anything on your screen, dictate with offline Whisper voice AI, and route queries to <strong>Gemini, Claude, or local Ollama</strong>. 100% free, forever private, and installs in seconds.
          </p>

          {/* HIGH-CONVERTING CONVERSION ACTION HUB */}
          <div className="w-full max-w-2xl bg-slate-900/80 rounded-2xl border border-indigo-500/30 p-5 sm:p-6 shadow-2xl backdrop-blur-sm space-y-4">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3">
              {/* Primary APK Download Button */}
              <a
                href="https://github.com/Cellate/OpenAssist/releases/latest"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-4 px-6 rounded-2xl font-bold text-sm sm:text-base bg-gradient-to-r from-emerald-500 via-emerald-400 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 flex items-center justify-center gap-3 transition-all shadow-xl shadow-emerald-500/25 hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
              >
                <Download className="w-5 h-5 text-slate-950 shrink-0" />
                <div className="text-left leading-tight">
                  <div className="font-extrabold flex items-center gap-2">
                    <span>Download APK ({APP_VERSION.displayName})</span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-950/20 text-slate-950 font-mono font-black">5.6 MB</span>
                  </div>
                  <div className="text-[11px] font-mono text-emerald-950/80">Direct Install • Only 5.6 MB • Mobile Data Friendly • Android 10+</div>
                </div>
              </a>

              {/* Try Live Interactive Demo Button */}
              <button
                type="button"
                onClick={() => {
                  mascotAudio.playTap();
                  const el = document.getElementById('interactive-phone');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="py-4 px-5 rounded-2xl font-semibold text-sm bg-indigo-600/30 hover:bg-indigo-600/40 text-indigo-200 border border-indigo-500/40 flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
              >
                <Smartphone className="w-4 h-4 text-indigo-400" />
                <span>Try Live Demo Below</span>
              </button>
            </div>

            {/* SHA-256 Integrity Verification Card */}
            <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-2">
              <div className="flex items-center gap-1.5 font-mono truncate max-w-full">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="text-slate-500">SHA-256:</span>
                <span className="text-slate-300 truncate">{sha256Checksum.slice(0, 20)}...{sha256Checksum.slice(-10)}</span>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <button
                  type="button"
                  onClick={copySha}
                  className="flex items-center gap-1 text-[11px] text-indigo-400 hover:text-indigo-300 font-medium cursor-pointer"
                >
                  {copiedSha ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSha ? 'Copied' : 'Copy Checksum'}</span>
                </button>
                <span className="text-slate-700">|</span>
                <a
                  href="https://github.com/Cellate/OpenAssist/releases/latest"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-slate-200"
                >
                  <span>Latest Release</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>

          {/* EVERYDAY USER CONVERSION PROOF CARDS */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 w-full max-w-3xl">
            <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0">
                <Zap className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">Ultra-Light 5.6 MB</div>
                <div className="text-[11px] text-slate-400">Takes ~2 sec on 4G/5G Jio or Airtel</div>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center shrink-0">
                <Smartphone className="w-5 h-5 text-indigo-400" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">Redmi, Samsung, Realme</div>
                <div className="text-[11px] text-slate-400">Works on all Android 10+ devices</div>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5 text-cyan-400" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">Zero Root &amp; Zero Ads</div>
                <div className="text-[11px] text-slate-400">100% Private, no Google login needed</div>
              </div>
            </div>
          </div>

          {/* TRUST PILLARS ROW */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-2 w-full">
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col items-center justify-center text-center">
              <EyeOff className="w-5 h-5 text-emerald-400 mb-1" />
              <div className="text-xs font-bold text-white">0% Telemetry</div>
              <div className="text-[10px] text-slate-400">Zero data collected</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col items-center justify-center text-center">
              <Lock className="w-5 h-5 text-indigo-400 mb-1" />
              <div className="text-xs font-bold text-white">AES-256-GCM</div>
              <div className="text-[10px] text-slate-400">Android Keystore TEE</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col items-center justify-center text-center">
              <Zap className="w-5 h-5 text-amber-400 mb-1" />
              <div className="text-xs font-bold text-white">Sub-100ms</div>
              <div className="text-[10px] text-slate-400">Instant gesture response</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col items-center justify-center text-center">
              <Volume2 className="w-5 h-5 text-purple-400 mb-1" />
              <div className="text-xs font-bold text-white">Offline Whisper</div>
              <div className="text-[10px] text-slate-400">Native C++ JNI bridge</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col items-center justify-center text-center">
              <Smartphone className="w-5 h-5 text-cyan-400 mb-1" />
              <div className="text-xs font-bold text-white">Android 10-16+</div>
              <div className="text-[10px] text-slate-400">Works on all ROMs</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col items-center justify-center text-center">
              <Globe className="w-5 h-5 text-pink-400 mb-1" />
              <div className="text-xs font-bold text-white">GNU GPLv3</div>
              <div className="text-[10px] text-slate-400">100% Free Software</div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          INTERACTIVE DEMO / LIVE SIMULATOR PREVIEW
         ========================================================================= */}
      <section id="interactive-phone" className="rounded-3xl bg-slate-900/60 border border-slate-800 p-4 sm:p-8 lg:p-10 space-y-6 scroll-mt-20">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-semibold mb-2 border border-emerald-500/20">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              Live Interactive Phone Sandbox
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Test Circle to Search Right Now
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1 leading-relaxed">
              Touch or click and drag across the simulated screen below to draw a glowing circle, test voice dictation, switch between Gemini, Claude, and local Ollama, and hear live mascot voice chirps!
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href="https://github.com/Cellate/OpenAssist/releases/latest"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>Download 5.6 MB APK</span>
            </a>
          </div>
        </div>

        {/* Embedded Live Phone Sandbox Container */}
        <div className="bg-slate-950/80 rounded-2xl border border-indigo-500/30 p-2 sm:p-5 shadow-2xl overflow-hidden">
          <PhoneSimulator
            logoStyle={activeMascot.logoStyle}
            customIcons={customIcons}
            onSelectLogo={onSelectLogo}
            onOpenSetupWizard={onOpenSetupWizard}
            onOpenLogoSwitcher={onOpenLogoSwitcher}
            onOpenCode={() => onNavigateToTab('code')}
          />
        </div>
      </section>

      {/* =========================================================================
          THE MASCOT COMPANIONS: Lore, Personality & Acoustic Feedback
         ========================================================================= */}
      <section id="mascots-gallery" className="rounded-3xl bg-slate-900/60 border border-slate-800 p-6 sm:p-10 space-y-8 scroll-mt-20">
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 text-xs font-semibold">
            <Heart className="w-3.5 h-3.5 text-pink-400" />
            Empathetic Technology &amp; Philosophy
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            Meet the Mascot Companions
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Why mascots? Artificial intelligence shouldn't feel like a cold surveillance tool. OpenAssist pairs you with endearing, reactive companions that humanize machine interaction and respond with real synthesized audio chirps.
          </p>
        </div>

        {/* Mascot Selector Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {MASCOTS_SHOWCASE.map((m, idx) => {
            const isSelected = selectedMascotIndex === idx;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => {
                  setSelectedMascotIndex(idx);
                  onSelectLogo(m.logoStyle);
                  handlePlayMascotChirp(m.soundType);
                }}
                className={`flex items-center gap-2.5 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer border ${
                  isSelected
                    ? 'bg-indigo-600/30 border-indigo-500/60 text-white shadow-lg shadow-indigo-950'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-850'
                }`}
              >
                <OpenAssistLogo style={m.logoStyle} size={24} />
                <span>{m.name}</span>
                {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
              </button>
            );
          })}
        </div>

        {/* Selected Mascot Detail Spotlight Card */}
        <div className="bg-slate-950/80 rounded-3xl border border-slate-800 p-6 sm:p-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-center shadow-xl">
          {/* Left Avatar Showcase */}
          <div className="md:col-span-4 flex flex-col items-center text-center space-y-4">
            <div className="p-6 rounded-3xl bg-gradient-to-b from-indigo-500/10 to-purple-500/10 border border-indigo-500/30 shadow-2xl relative group">
              <OpenAssistLogo style={activeMascot.logoStyle} size={140} />
              <button
                type="button"
                onClick={() => handlePlayMascotChirp(activeMascot.soundType)}
                className="absolute -bottom-3 right-4 p-2.5 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg cursor-pointer transition-transform group-hover:scale-110"
                title="Play Mascot Voice Chirp"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>

            <div>
              <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold border ${activeMascot.badgeColor}`}>
                {activeMascot.badge}
              </span>
              <h3 className="text-xl font-bold text-white mt-1.5">{activeMascot.name}</h3>
              <p className="text-xs text-indigo-400 font-medium">{activeMascot.archetype}</p>
            </div>
          </div>

          {/* Right Mascot Lore & Technical Details */}
          <div className="md:col-span-8 space-y-5 text-left">
            <blockquote className="border-l-2 border-indigo-500 pl-4 py-1 italic text-sm text-slate-200 font-serif">
              {activeMascot.quote}
            </blockquote>

            <div className="space-y-2">
              <h4 className="text-xs uppercase tracking-wider text-slate-400 font-bold">Lore &amp; Origin</h4>
              <p className="text-sm text-slate-300 leading-relaxed">{activeMascot.lore}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="bg-slate-900/80 rounded-xl p-3 border border-slate-800">
                <div className="text-[11px] font-bold text-slate-400 uppercase">System Role</div>
                <div className="text-xs text-slate-200 mt-1">{activeMascot.role}</div>
              </div>

              <div className="bg-slate-900/80 rounded-xl p-3 border border-slate-800">
                <div className="text-[11px] font-bold text-slate-400 uppercase">Acoustic Sound Profile</div>
                <div className="text-xs text-indigo-300 font-mono mt-1">{activeMascot.soundFreq}</div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  onSelectLogo(activeMascot.logoStyle);
                  handlePlayMascotChirp(activeMascot.soundType);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-2 transition-all cursor-pointer"
              >
                <span>Make Active Mascot</span>
                <Check className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => onNavigateToTab('studio')}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-850 hover:bg-slate-800 text-slate-300 border border-slate-700 flex items-center gap-2 transition-all cursor-pointer"
              >
                <span>Explore All 27 Mascots in Brand Studio</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          10-LAYER HARDENED SECURITY PERIMETER & ZERO-VULNERABILITY ARCHITECTURE
         ========================================================================= */}
      <section id="security-layers" className="rounded-3xl bg-slate-900/60 border border-slate-800 p-6 sm:p-10 space-y-8 scroll-mt-20">
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-semibold">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            Audited &amp; Hardened Against 15 Vulnerabilities
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            The 10-Layer Hardened Security Perimeter
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Click through our 10 defense-in-depth architectural layers. OpenAssist is engineered to eliminate data leakage, unencrypted keys, memory scraping, and corporate tracking.
          </p>
        </div>

        {/* Security Layers Interactive Matrix */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Layer List Selector */}
          <div className="lg:col-span-5 space-y-2">
            {SECURITY_LAYERS.map((layer, index) => {
              const isSelected = activeSecurityLayer === index;
              return (
                <button
                  key={layer.number}
                  type="button"
                  onClick={() => {
                    setActiveSecurityLayer(index);
                    mascotAudio.playTap();
                  }}
                  className={`w-full text-left p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'bg-slate-850 border-emerald-500/60 shadow-lg shadow-emerald-950/40 text-white'
                      : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-3 truncate">
                    <span className="flex items-center justify-center w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-mono text-xs font-bold shrink-0">
                      {layer.number}
                    </span>
                    <span className="text-xs font-semibold truncate">{layer.title}</span>
                  </div>
                  <ChevronRight className={`w-4 h-4 shrink-0 transition-transform ${isSelected ? 'text-emerald-400 translate-x-1' : 'text-slate-600'}`} />
                </button>
              );
            })}
          </div>

          {/* Active Layer Deep Dive Card */}
          <div className="lg:col-span-7 bg-slate-950 rounded-3xl border border-emerald-500/30 p-6 sm:p-8 space-y-5 shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
                  Defense Layer #{SECURITY_LAYERS[activeSecurityLayer].number}
                </span>
                <h3 className="text-xl font-bold text-white mt-1">
                  {SECURITY_LAYERS[activeSecurityLayer].title}
                </h3>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-bold shrink-0">
                {SECURITY_LAYERS[activeSecurityLayer].status}
              </span>
            </div>

            <div className="space-y-4 text-xs sm:text-sm">
              <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-500/20 space-y-1">
                <div className="text-rose-400 font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>Threat Vector Mitigated</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  {SECURITY_LAYERS[activeSecurityLayer].threat}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/20 space-y-1">
                <div className="text-emerald-400 font-bold flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  <span>OpenAssist Architectural Defense</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  {SECURITY_LAYERS[activeSecurityLayer].defense}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs space-y-1.5">
                <div className="text-indigo-400 font-bold">Implementation Blueprint:</div>
                <div className="text-slate-300 leading-relaxed">
                  {SECURITY_LAYERS[activeSecurityLayer].technicalDetails}
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between text-xs text-slate-400">
              <span>Audited under Android Security Guidelines</span>
              <button
                type="button"
                onClick={() => onNavigateToTab('code')}
                className="text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1 cursor-pointer"
              >
                <span>Inspect in Code Explorer</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          COMPETITIVE COMPARISON MATRIX: OpenAssist vs. Proprietary Assistants
         ========================================================================= */}
      <section id="comparison-matrix" className="rounded-3xl bg-slate-900/60 border border-slate-800 p-6 sm:p-10 space-y-6 scroll-mt-20">
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 text-xs font-semibold">
            <Cpu className="w-3.5 h-3.5" />
            Sovereign Architecture vs Proprietary Walls
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            How OpenAssist Compares
          </h2>
          <p className="text-sm text-slate-300">
            See why privacy advocates, power users, and custom ROM enthusiasts choose OpenAssist.
          </p>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-slate-800">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[11px] font-semibold border-b border-slate-800">
              <tr>
                <th className="p-4">Feature / Capability</th>
                <th className="p-4 text-emerald-400 bg-emerald-950/20">OpenAssist (v1.65.0)</th>
                <th className="p-4 text-slate-400">Generic Assistant App</th>
                <th className="p-4 text-slate-400">Default System Assistant</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 bg-slate-900/40">
              <tr>
                <td className="p-4 font-semibold text-white">License &amp; Source Code</td>
                <td className="p-4 font-bold text-emerald-400 bg-emerald-950/20">100% Free / GNU GPLv3</td>
                <td className="p-4 text-slate-400">Proprietary Closed</td>
                <td className="p-4 text-slate-400">Proprietary Closed</td>
              </tr>
              <tr>
                <td className="p-4 font-semibold text-white">Device Compatibility</td>
                <td className="p-4 font-bold text-emerald-400 bg-emerald-950/20">Any Android 10+ Phone</td>
                <td className="p-4 text-slate-400">Limited / Hardware Locked</td>
                <td className="p-4 text-slate-400">Vendor Locked</td>
              </tr>
              <tr>
                <td className="p-4 font-semibold text-white">Works on Custom ROMs (Graphene, Lineage)</td>
                <td className="p-4 font-bold text-emerald-400 bg-emerald-950/20">Yes (100% Functional)</td>
                <td className="p-4 text-rose-400">Often Restricted (Missing Services)</td>
                <td className="p-4 text-rose-400">Unavailable</td>
              </tr>
              <tr>
                <td className="p-4 font-semibold text-white">Telemetry &amp; Behavioral Tracking</td>
                <td className="p-4 font-bold text-emerald-400 bg-emerald-950/20">0% (Zero Telemetry)</td>
                <td className="p-4 text-rose-400">Continuous Cloud Telemetry</td>
                <td className="p-4 text-rose-400">Cloud Activity Logging</td>
              </tr>
              <tr>
                <td className="p-4 font-semibold text-white">Offline Voice Dictation</td>
                <td className="p-4 font-bold text-emerald-400 bg-emerald-950/20">C++ Whisper.cpp On-Device</td>
                <td className="p-4 text-amber-400">Cloud Server Dependent</td>
                <td className="p-4 text-amber-400">Cloud Server Dependent</td>
              </tr>
              <tr>
                <td className="p-4 font-semibold text-white">Bring Your Own Key (BYOK)</td>
                <td className="p-4 font-bold text-emerald-400 bg-emerald-950/20">Gemini, Claude, OpenAI, DeepSeek</td>
                <td className="p-4 text-slate-500">No (Locked Ecosystem)</td>
                <td className="p-4 text-slate-500">No</td>
              </tr>
              <tr>
                <td className="p-4 font-semibold text-white">Self-Hosted Local LLM (Ollama)</td>
                <td className="p-4 font-bold text-emerald-400 bg-emerald-950/20">Yes (Direct LAN RFC-1918)</td>
                <td className="p-4 text-slate-500">No</td>
                <td className="p-4 text-slate-500">No</td>
              </tr>
              <tr>
                <td className="p-4 font-semibold text-white">Mascot Companions &amp; Audio Synthesizer</td>
                <td className="p-4 font-bold text-emerald-400 bg-emerald-950/20">10 Companions + Soundboard</td>
                <td className="p-4 text-slate-500">None</td>
                <td className="p-4 text-slate-500">None</td>
              </tr>
              <tr>
                <td className="p-4 font-semibold text-white">Root or Bootloader Unlock Needed?</td>
                <td className="p-4 font-bold text-emerald-400 bg-emerald-950/20">No (Standard User APK)</td>
                <td className="p-4 text-slate-400">No</td>
                <td className="p-4 text-slate-400">No</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* =========================================================================
          QUICK 3-STEP INSTALLATION WALKTHROUGH
         ========================================================================= */}
      <section id="setup-guide" className="rounded-3xl bg-slate-900/60 border border-slate-800 p-6 sm:p-10 space-y-8 scroll-mt-20">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-semibold">
            <Zap className="w-3.5 h-3.5" />
            Setup in Under 60 Seconds
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            How to Install &amp; Activate OpenAssist
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            No technical knowledge or computer required. You can install it straight from your phone's browser.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Step 1 */}
          <div className="bg-slate-950/80 rounded-2xl border border-slate-800 p-6 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <span className="flex items-center justify-center w-8 h-8 rounded-full bg-indigo-600/30 text-indigo-400 font-mono font-bold text-sm border border-indigo-500/40">
                1
              </span>
              <h3 className="text-lg font-bold text-white">Download the APK</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Download <code>{APP_VERSION.apkName}</code> from our official GitHub release link. Allow "Install unknown apps" in Chrome or Firefox when prompted.
              </p>
            </div>
            <a
              href="https://github.com/Cellate/OpenAssist/releases/latest"
              target="_blank"
              rel="noopener noreferrer"
              className="py-2.5 px-4 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Latest APK ({APP_VERSION.displayName})</span>
            </a>
          </div>

          {/* Step 2 */}
          <div className="bg-slate-950/80 rounded-2xl border border-slate-800 p-6 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <span className="flex items-center justify-center w-8 h-8 rounded-full bg-emerald-600/30 text-emerald-400 font-mono font-bold text-sm border border-emerald-500/40">
                2
              </span>
              <h3 className="text-lg font-bold text-white">Set as Default Assistant</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Go to Android <strong>Settings &gt; Apps &gt; Default apps &gt; Digital assistant app</strong>. Tap <strong>Default digital assistant app</strong> and choose <strong>OpenAssist</strong>.
              </p>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px] font-mono text-emerald-400">
              Settings → Apps → Default Assistant → OpenAssist
            </div>
          </div>

          {/* Step 3 */}
          <div className="bg-slate-950/80 rounded-2xl border border-slate-800 p-6 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <span className="flex items-center justify-center w-8 h-8 rounded-full bg-purple-600/30 text-purple-400 font-mono font-bold text-sm border border-purple-500/40">
                3
              </span>
              <h3 className="text-lg font-bold text-white">Trigger by Gesture</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Swipe diagonally from the bottom corner of your screen, or touch and hold the gesture bar (or Home button). Your screen dims and the glowing lasso is ready!
              </p>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px] font-mono text-purple-300">
              Hold Home / Corner Swipe → Draw Lasso → Done!
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          EVERYDAY USER TRUST & OBJECTION-HANDLING FAQ (India & Global Users)
         ========================================================================= */}
      <section className="rounded-3xl bg-slate-900/60 border border-slate-800 p-6 sm:p-10 space-y-6">
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 text-xs font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            Clear Answers for Everyday Android Users
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="text-sm text-slate-300">
            Straightforward answers regarding safety, mobile data usage, and device compatibility.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div className="bg-slate-950/70 rounded-2xl border border-slate-800 p-5 space-y-2">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Why does Android say "File might be harmful"?</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              This is a standard default prompt shown by Android whenever you download ANY app file outside the Google Play Store. OpenAssist is 100% open-source (GNU GPLv3), contains zero adware, zero tracking, and is verified with a cryptographic SHA-256 checksum. You can safely tap <strong>"Download anyway"</strong>.
            </p>
          </div>

          <div className="bg-slate-950/70 rounded-2xl border border-slate-800 p-5 space-y-2">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>How much mobile data will this consume?</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              The entire OpenAssist APK is only <strong>5.6 MB</strong>. That is smaller than 2 photos or a 5-second video on WhatsApp! It downloads in approximately 2 to 3 seconds on standard Jio, Airtel, Vi, or 4G/5G connections without eating your daily data limit.
            </p>
          </div>

          <div className="bg-slate-950/70 rounded-2xl border border-slate-800 p-5 space-y-2">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Does OpenAssist work on Redmi, Realme, Samsung, Vivo, etc.?</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Yes! OpenAssist runs natively on any phone with Android 10 or higher. Whether you have a Xiaomi/Redmi, Realme, Samsung Galaxy, Vivo, Oppo, OnePlus, Poco, Motorola, Nothing Phone, or Google Pixel, Circle to Search works immediately.
            </p>
          </div>

          <div className="bg-slate-950/70 rounded-2xl border border-slate-800 p-5 space-y-2">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Do I need to root my phone or unlock the bootloader?</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              No root or computer is ever needed. OpenAssist is a standard user app that registers as an official <code>VoiceInteractionService</code> (the exact same system hook that Google Assistant uses). Your phone's security and warranty remain completely untouched.
            </p>
          </div>

          <div className="bg-slate-950/70 rounded-2xl border border-slate-800 p-5 space-y-2">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Does my screen data get saved or sent to any server?</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Never. OpenAssist operates with zero background telemetry and zero external logging. Screenshot buffers are immediately overwritten with zeros and scrubbed from RAM the millisecond you close the search overlay.
            </p>
          </div>

          <div className="bg-slate-950/70 rounded-2xl border border-slate-800 p-5 space-y-2">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Does it work offline without an active internet connection?</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Yes. Offline voice dictation is powered by on-device C++ Whisper, and you can also connect to local Ollama AI instances running on your home Wi-Fi network without transmitting any queries over the public internet.
            </p>
          </div>
        </div>
      </section>

      {/* =========================================================================
          DEVELOPER & GITHUB ACTIONS / ADB COMMANDS
         ========================================================================= */}
      <section className="rounded-3xl bg-slate-900/60 border border-slate-800 p-6 sm:p-8 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Terminal className="w-5 h-5 text-indigo-400" />
              Developer &amp; Power User Quick Sideload
            </h3>
            <p className="text-xs text-slate-400">
              Connect your Android phone via USB with USB Debugging enabled to install via ADB.
            </p>
          </div>
          <button
            type="button"
            onClick={copyAdb}
            className="px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-2 transition-all cursor-pointer"
          >
            {copiedAdb ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedAdb ? 'Copied' : 'Copy ADB Command'}</span>
          </button>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950 font-mono text-xs text-emerald-400 border border-slate-800 overflow-x-auto">
          <code>{adbInstallCmd}</code>
        </div>
      </section>

      {/* =========================================================================
          BOTTOM CONVERSION BANNER
         ========================================================================= */}
      <section id="download-hub" className="rounded-3xl bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 border border-indigo-500/40 p-8 sm:p-12 text-center space-y-6 shadow-2xl relative overflow-hidden scroll-mt-20">
        <div className="max-w-2xl mx-auto space-y-3">
          <OpenAssistLogo style={currentLogo} size={56} className="mx-auto" />
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            Take Back Your Screen Intelligence Today
          </h2>
          <p className="text-sm text-slate-300">
            OpenAssist is 100% free, forever open source, only 5.6 MB, and will never collect a single byte of your data.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-4">
          <a
            href="https://github.com/Cellate/OpenAssist/releases/latest"
            target="_blank"
            rel="noopener noreferrer"
            className="py-3.5 px-8 rounded-xl font-bold text-sm bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 flex items-center gap-2 transition-all shadow-xl hover:scale-105 active:scale-95 cursor-pointer"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>Download Latest APK ({APP_VERSION.displayName} • 5.6 MB)</span>
          </a>

          <a
            href="https://github.com/Cellate/OpenAssist"
            target="_blank"
            rel="noopener noreferrer"
            className="py-3.5 px-6 rounded-xl font-semibold text-sm bg-slate-800/80 hover:bg-slate-700 text-white border border-slate-700 flex items-center gap-2 transition-all cursor-pointer"
          >
            <Star className="w-4 h-4 text-amber-400" />
            <span>Star on GitHub</span>
          </a>
        </div>
      </section>
    </div>
  );
};
