import React, { useState } from 'react';
import {
  X, Check, Plus, Trash2, ArrowUp, ArrowDown, ExternalLink,
  RotateCcw, Search, Globe, Sliders, Smartphone
} from 'lucide-react';
import {
  AssistService,
  ServiceCategory,
  CATEGORY_LABELS,
  BUILT_IN_SERVICES,
  saveStoredServices
} from '../data/servicesCatalog';

interface ChipManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  services: AssistService[];
  onUpdateServices: (services: AssistService[]) => void;
  isDarkMode: boolean;
  onMascotReact?: (msg: string) => void;
}

export const ChipManagerModal: React.FC<ChipManagerModalProps> = ({
  isOpen,
  onClose,
  services,
  onUpdateServices,
  isDarkMode,
  onMascotReact
}) => {
  const [activeCategory, setActiveCategory] = useState<ServiceCategory>('all');
  const [searchFilter, setSearchFilter] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  // New site form fields
  const [newName, setNewName] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [newCategory, setNewCategory] = useState<ServiceCategory>('search');
  const [newOpenInApp, setNewOpenInApp] = useState(false);
  const [newPackageName, setNewPackageName] = useState('');

  if (!isOpen) return null;

  const handleToggleEnable = (id: string) => {
    const updated = services.map(s => s.id === id ? { ...s, isEnabled: !s.isEnabled } : s);
    onUpdateServices(updated);
    saveStoredServices(updated);
  };

  const handleToggleOpenInApp = (id: string) => {
    const updated = services.map(s => {
      if (s.id === id) {
        const next = !s.openInApp;
        onMascotReact?.(`${s.name} will now open in ${next ? 'native app' : 'in-app WebView'}`);
        return { ...s, openInApp: next };
      }
      return s;
    });
    onUpdateServices(updated);
    saveStoredServices(updated);
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= services.length) return;
    const next = [...services];
    const temp = next[index];
    next[index] = next[targetIndex];
    next[targetIndex] = temp;
    onUpdateServices(next);
    saveStoredServices(next);
  };

  const handleDelete = (id: string) => {
    const target = services.find(s => s.id === id);
    const updated = services.filter(s => s.id !== id);
    onUpdateServices(updated);
    saveStoredServices(updated);
    onMascotReact?.(`Removed ${target?.name || 'chip'}`);
  };

  const handleResetDefaults = () => {
    if (window.confirm('Reset all service chips and ordering back to built-in defaults?')) {
      onUpdateServices([...BUILT_IN_SERVICES]);
      saveStoredServices([...BUILT_IN_SERVICES]);
      onMascotReact?.('Restored 35+ chips to original defaults!');
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newUrl.trim()) return;

    let norm = newUrl.trim();
    if (!norm.startsWith('http://') && !norm.startsWith('https://')) {
      norm = 'https://' + norm;
    }
    if (!norm.includes('{q}') && !norm.includes('?')) {
      norm = norm + '/search?q={q}';
    }

    const newService: AssistService = {
      id: 'custom_' + Date.now(),
      name: newName.trim(),
      url: norm,
      category: newCategory === 'all' ? 'custom' : newCategory,
      isCustom: true,
      isEnabled: true,
      openInApp: newOpenInApp,
      packageName: newPackageName.trim() || undefined,
      searchUrlTemplate: norm.includes('{q}') ? norm : `${norm}?q={q}`
    };

    const updated = [newService, ...services];
    onUpdateServices(updated);
    saveStoredServices(updated);
    onMascotReact?.(`Added "${newService.name}" chip!`);

    setNewName('');
    setNewUrl('');
    setNewPackageName('');
    setShowAddForm(false);
  };

  const filtered = services.filter(s => {
    if (activeCategory !== 'all' && s.category !== activeCategory) return false;
    if (searchFilter.trim()) {
      const q = searchFilter.toLowerCase();
      return s.name.toLowerCase().includes(q) || s.url.toLowerCase().includes(q);
    }
    return true;
  });

  const c = {
    modal: isDarkMode ? 'bg-[#151722] border-white/10 text-white' : 'bg-white border-slate-300 text-slate-900 shadow-2xl',
    header: isDarkMode ? 'bg-[#181B26] border-white/10 text-white' : 'bg-slate-100 border-slate-200 text-slate-900',
    cardBox: isDarkMode ? 'bg-[#1A1D2B] border-white/10' : 'bg-slate-50 border-slate-200 shadow-xs',
    subText: isDarkMode ? 'text-zinc-400' : 'text-slate-600',
    title: isDarkMode ? 'text-white' : 'text-slate-900 font-bold',
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-left font-sans">
      <div className={`${c.modal} rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl border overflow-hidden`}>
        {/* Header */}
        <div className={`px-5 py-4 border-b flex items-center justify-between ${c.header}`}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className={`text-sm font-bold tracking-tight ${c.title}`}>Manage Search &amp; Assistant Chips</h3>
              <p className={`text-[11px] ${c.subText}`}>Reorder, toggle, or add any website / app to Circle to Search</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-full transition ${c.subText} hover:opacity-100`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Controls & Category Tabs */}
        <div className="p-4 border-b space-y-3 shrink-0" style={{ borderColor: isDarkMode ? 'rgba(255,255,255,0.08)' : '#E2E8F0' }}>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            {/* Search filter input */}
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Search services (e.g. YouTube, Gemini, Reddit)..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className={`w-full pl-8 pr-3 py-1.5 rounded-xl border text-xs ${
                  isDarkMode ? 'bg-zinc-900/90 border-zinc-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
                }`}
              />
            </div>

            {/* Buttons */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setShowAddForm(!showAddForm)}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-1.5 transition shadow"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Website / App</span>
              </button>
              <button
                onClick={handleResetDefaults}
                className="p-1.5 rounded-xl border transition hover:opacity-80 text-zinc-400 hover:text-white"
                title="Reset to Defaults"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            {(['all', 'ai', 'search', 'social', 'productivity', 'custom'] as ServiceCategory[]).map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap transition ${
                  activeCategory === cat
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : isDarkMode
                    ? 'bg-zinc-800/80 text-zinc-300 hover:bg-zinc-700'
                    : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                }`}
              >
                {CATEGORY_LABELS[cat]}
              </button>
            ))}
          </div>
        </div>

        {/* Add Form Accordion */}
        {showAddForm && (
          <form
            onSubmit={handleAddSubmit}
            className={`p-4 border-b space-y-3 animate-in fade-in duration-150 ${c.cardBox}`}
          >
            <div className="flex items-center justify-between">
              <h4 className={`text-xs font-bold ${c.title}`}>Add Custom Website or Search Engine</h4>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="text-xs text-zinc-400 hover:text-white"
              >
                Cancel
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Service Name</label>
                <input
                  type="text"
                  placeholder="e.g. Hacker News, Pinterest, Spotify"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className={`w-full px-2.5 py-1.5 rounded-xl border ${
                    isDarkMode ? 'bg-zinc-900 border-zinc-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                  }`}
                  required
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Search URL Template ({'{q}'} will be replaced)</label>
                <input
                  type="text"
                  placeholder="https://news.ycombinator.com/item?id={q}"
                  value={newUrl}
                  onChange={(e) => setNewUrl(e.target.value)}
                  className={`w-full px-2.5 py-1.5 rounded-xl border ${
                    isDarkMode ? 'bg-zinc-900 border-zinc-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                  }`}
                  required
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as ServiceCategory)}
                  className={`w-full px-2.5 py-1.5 rounded-xl border text-xs ${
                    isDarkMode ? 'bg-zinc-900 border-zinc-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                  }`}
                >
                  <option value="search">Search & Knowledge</option>
                  <option value="ai">AI Models</option>
                  <option value="social">Social & Media</option>
                  <option value="productivity">Productivity & Shopping</option>
                  <option value="custom">Custom</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Optional Android Package Name</label>
                <input
                  type="text"
                  placeholder="e.g. com.google.android.youtube"
                  value={newPackageName}
                  onChange={(e) => setNewPackageName(e.target.value)}
                  className={`w-full px-2.5 py-1.5 rounded-xl border ${
                    isDarkMode ? 'bg-zinc-900 border-zinc-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                  }`}
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 text-xs text-zinc-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newOpenInApp}
                  onChange={(e) => setNewOpenInApp(e.target.checked)}
                  className="rounded accent-indigo-600"
                />
                <span>Open in native app if installed</span>
              </label>

              <button
                type="submit"
                className="px-4 py-1.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition shadow"
              >
                Save Chip
              </button>
            </div>
          </form>
        )}

        {/* Scrollable List of Chips */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {filtered.length === 0 ? (
            <div className="text-center py-8 text-xs text-zinc-400">
              No matching chips found.
            </div>
          ) : (
            filtered.map((service, index) => {
              const actualIndex = services.findIndex(s => s.id === service.id);
              return (
                <div
                  key={service.id}
                  className={`p-2.5 rounded-2xl border flex items-center justify-between gap-3 text-xs transition-all ${
                    service.isEnabled ? c.cardBox : 'opacity-50 ' + c.cardBox
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <input
                      type="checkbox"
                      checked={service.isEnabled}
                      onChange={() => handleToggleEnable(service.id)}
                      className="w-4 h-4 rounded accent-indigo-600 cursor-pointer shrink-0"
                      title={service.isEnabled ? 'Enabled (Click to disable)' : 'Disabled (Click to enable)'}
                    />

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className={`font-bold truncate ${c.title}`}>{service.name}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded-full font-mono font-medium border"
                          style={{
                            backgroundColor: isDarkMode ? '#222638' : '#E2E8F0',
                            borderColor: isDarkMode ? 'rgba(255,255,255,0.1)' : '#CBD5E1',
                            color: service.color || (isDarkMode ? '#8AB4F8' : '#2563EB')
                          }}>
                          {CATEGORY_LABELS[service.category]}
                        </span>
                        {service.isCustom && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-semibold">
                            Custom
                          </span>
                        )}
                      </div>
                      <p className={`text-[10px] truncate max-w-xs sm:max-w-md ${c.subText}`}>
                        {service.url}
                      </p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    {/* Open In App Toggle Button */}
                    <button
                      type="button"
                      onClick={() => handleToggleOpenInApp(service.id)}
                      className={`px-2.5 py-1 rounded-xl text-[10px] font-bold border flex items-center gap-1 transition ${
                        service.openInApp
                          ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                          : isDarkMode
                          ? 'bg-zinc-800 border-zinc-700 text-zinc-400'
                          : 'bg-slate-200 border-slate-300 text-slate-600'
                      }`}
                      title={service.openInApp ? 'Opens in installed native app' : 'Opens in in-app WebView'}
                    >
                      <ExternalLink className="w-2.5 h-2.5" />
                      <span>{service.openInApp ? 'App ↗' : 'Web'}</span>
                    </button>

                    {/* Move Up */}
                    <button
                      type="button"
                      disabled={actualIndex === 0}
                      onClick={() => handleMove(actualIndex, 'up')}
                      className="p-1 rounded-lg hover:bg-zinc-700/50 disabled:opacity-20 text-zinc-300 transition"
                      title="Move Up"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>

                    {/* Move Down */}
                    <button
                      type="button"
                      disabled={actualIndex === services.length - 1}
                      onClick={() => handleMove(actualIndex, 'down')}
                      className="p-1 rounded-lg hover:bg-zinc-700/50 disabled:opacity-20 text-zinc-300 transition"
                      title="Move Down"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete button (for custom services) */}
                    {service.isCustom && (
                      <button
                        type="button"
                        onClick={() => handleDelete(service.id)}
                        className="p-1 rounded-lg hover:bg-red-500/20 text-red-400 transition"
                        title="Delete custom website"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className={`px-5 py-3 border-t flex items-center justify-between text-xs ${c.header}`}>
          <span className={c.subText}>
            {services.filter(s => s.isEnabled).length} of {services.length} chips active in top search bar
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition shadow"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
