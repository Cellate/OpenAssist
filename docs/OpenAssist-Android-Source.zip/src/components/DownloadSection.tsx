import React, { useState } from 'react';
import JSZip from 'jszip';
import {
  Download, Github, CheckCircle2, Terminal, FileArchive,
  Cpu, Sparkles, AlertCircle, Copy, Check, Wrench, Layers
} from 'lucide-react';
import { PROJECT_FILES } from '../data/projectFiles';
import { OpenAssistLogo, LogoStyle, CustomIconItem } from './LogoVariations';
import { APP_VERSION } from '../utils/version';

interface DownloadSectionProps {
  showCicdMascot?: boolean;
  logoStyle?: LogoStyle;
  customIcons?: CustomIconItem[];
}

export const DownloadSection: React.FC<DownloadSectionProps> = ({
  showCicdMascot = true,
  logoStyle = 'owl-orbital',
  customIcons = [],
}) => {
  const [isZippingBuild, setIsZippingBuild] = useState(false);
  const [isZippingFull, setIsZippingFull] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const totalFiles = Object.keys(PROJECT_FILES).length;

  const downloadFileUrl = async (url: string, filename: string): Promise<boolean> => {
    try {
      const resp = await fetch(url);
      if (resp.ok) {
        const blob = await resp.blob();
        const objUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = objUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(objUrl);
        return true;
      }
    } catch {
      // Fallback
    }
    return false;
  };

  /**
   * Package 1: Download Pure Android Build ZIP (OpenAssist_v.1.63.0.zip)
   * Only includes files needed by GitHub Actions to build the APK.
   */
  const handleDownloadBuildZip = async () => {
    const filename = APP_VERSION.buildPackage;
    try {
      setIsZippingBuild(true);
      setDownloadSuccess(null);
      setDownloadError(null);

      const fetched = await downloadFileUrl(`/${filename}`, filename);
      if (fetched) {
        setIsZippingBuild(false);
        setDownloadSuccess(filename);
        setTimeout(() => setDownloadSuccess(null), 4000);
        return;
      }

      // Dynamic fallback via JSZip using PROJECT_FILES
      const zip = new JSZip();
      Object.entries(PROJECT_FILES).forEach(([filePath, content]) => {
        // Exclude web companion src files if any
        if (!filePath.startsWith('src/') && !filePath.startsWith('node_modules/')) {
          zip.file(filePath, content);
        }
      });

      const blob = await zip.generateAsync({
        type: 'blob',
        compression: 'DEFLATE',
        compressionOptions: { level: 9 },
      });

      const objUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = objUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(objUrl);

      setIsZippingBuild(false);
      setDownloadSuccess(filename);
      setTimeout(() => setDownloadSuccess(null), 4000);
    } catch (err) {
      console.error('Failed to create build zip:', err);
      setIsZippingBuild(false);
      setDownloadError('Error creating build zip archive.');
      setTimeout(() => setDownloadError(null), 4000);
    }
  };

  /**
   * Package 2: Download Full Project Migration ZIP (OpenAssist-Full-Project.zip)
   * Complete repository with Android + React/Vite web companion.
   */
  const handleDownloadFullZip = async () => {
    const filename = 'OpenAssist-Full-Project.zip';
    try {
      setIsZippingFull(true);
      setDownloadSuccess(null);
      setDownloadError(null);

      const fetched = await downloadFileUrl(`/${filename}`, filename) ||
                      await downloadFileUrl('/OpenAssist-Android-Source.zip', filename);
      if (fetched) {
        setIsZippingFull(false);
        setDownloadSuccess(filename);
        setTimeout(() => setDownloadSuccess(null), 4000);
        return;
      }

      setIsZippingFull(false);
      setDownloadError('Could not locate migration zip archive.');
      setTimeout(() => setDownloadError(null), 4000);
    } catch (err) {
      console.error('Failed to download full project zip:', err);
      setIsZippingFull(false);
      setDownloadError('Error creating migration archive.');
      setTimeout(() => setDownloadError(null), 4000);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const gitPushScript = `# 1. Extract the build zip directly into your repo root:
unzip -o ${APP_VERSION.buildPackage}

# 2. Add and commit all files (including .github/workflows/main.yml):
git add .
git commit -m "OpenAssist ${APP_VERSION.displayName} release update"

# 3. Push to your GitHub repository:
git push origin main
# (If new repo: git remote add origin https://github.com/<USER>/<REPO>.git && git branch -M main && git push -u origin main)`;

  return (
    <div className="max-w-5xl mx-auto p-4 space-y-8 text-left">
      {/* Official GitHub Release Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-emerald-950/40 via-[#1A261D] to-[#121316] border border-emerald-500/30 rounded-3xl p-6 md:p-7 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Pre-built Official Release Available
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              No need to build! Download the official APK directly
            </h2>
            <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed max-w-2xl">
              You can grab the pre-compiled Android APK directly from GitHub Releases. Install it on any Android 10+ phone (Pixel, Samsung, ColorOS, LineageOS, GrapheneOS) and start using Circle to Search immediately without any build setup.
            </p>
          </div>
          <div className="shrink-0 w-full sm:w-auto">
            <a
              href="https://github.com/Cellate/OpenAssist/releases/latest"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl font-bold text-sm bg-emerald-400 hover:bg-emerald-300 text-emerald-950 flex items-center justify-center gap-2.5 transition-all shadow-lg hover:scale-[1.02] active:scale-[0.98]"
            >
              <Download className="w-4 h-4" />
              Download APK (Latest Release)
            </a>
          </div>
        </div>
      </div>

      {/* DUAL EXPORT PACKAGES SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* PACKAGE 1: PURE ANDROID BUILD ZIP */}
        <div className="relative overflow-hidden bg-gradient-to-br from-[#1A2030] via-[#151922] to-[#111216] border-2 border-indigo-500/50 rounded-3xl p-6 md:p-7 shadow-2xl flex flex-col justify-between space-y-5">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-bold border border-indigo-500/40">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                Package 1: Pure Android Build ZIP (Most Common)
              </span>
              <span className="text-[11px] font-mono font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-md">
                {APP_VERSION.displayName}
              </span>
            </div>

            <h3 className="text-xl font-bold text-white tracking-tight">
              {APP_VERSION.buildPackage}
            </h3>

            <p className="text-xs text-zinc-300 leading-relaxed">
              Contains <strong>strictly the Android APK source and GitHub Actions workflow</strong> needed to compile the app. Upload directly to GitHub to build your APK via GitHub Actions.
            </p>

            <div className="bg-black/30 rounded-xl p-3 border border-white/5 space-y-1.5 text-[11px] font-mono text-zinc-300">
              <div className="text-indigo-300 font-semibold">📁 Naming Scheme: v.1.&lt;iteration&gt;.&lt;bugfix&gt;</div>
              <div>• <strong>{APP_VERSION.version.split('.')[0] || '1'}</strong>: Major Android version</div>
              <div>• <strong>{APP_VERSION.version.split('.')[1] || '63'}</strong>: Iteration count ({APP_VERSION.version.split('.')[1]}rd generation)</div>
              <div>• <strong>{APP_VERSION.version.split('.')[2] || '0'}</strong>: Bug fix increment ({APP_VERSION.version})</div>
            </div>

            <ul className="text-xs text-zinc-300 space-y-1.5 pt-1">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Ready for GitHub Actions (.github/workflows/main.yml)</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Clean root: settings.gradle.kts, gradlew, and 43KB wrapper jar</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>35+ customizable service chips, Kotlin SDK 34, C++ Whisper JNI</span>
              </li>
            </ul>
          </div>

          <div className="space-y-2 pt-2">
            <button
              onClick={handleDownloadBuildZip}
              disabled={isZippingBuild}
              className={`w-full py-3.5 px-5 rounded-2xl font-bold text-sm flex items-center justify-center gap-2.5 transition-all shadow-lg ${
                isZippingBuild
                  ? 'bg-zinc-700 text-zinc-400 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30 hover:scale-[1.01] active:scale-[0.99]'
              }`}
            >
              {isZippingBuild ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/40 border-t-transparent rounded-full animate-spin" />
                  Generating Android Build Zip...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  Download {APP_VERSION.buildPackage}
                </>
              )}
            </button>
            <div className="flex items-center justify-between text-[11px] text-zinc-400 px-1">
              <span>Size: ~247 KB (Pure APK source)</span>
              <a
                href={`/${APP_VERSION.buildPackage}`}
                download={APP_VERSION.buildPackage}
                className="text-indigo-400 hover:underline"
              >
                Direct Link
              </a>
            </div>
          </div>
        </div>

        {/* PACKAGE 2: FULL AI STUDIO MIGRATION ZIP */}
        <div className="relative overflow-hidden bg-gradient-to-br from-[#1E222B] via-[#16171C] to-[#121316] border border-[#2D3342] rounded-3xl p-6 md:p-7 shadow-xl flex flex-col justify-between space-y-5">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 text-xs font-bold border border-cyan-500/20">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                Package 2: Full Project &amp; AI Studio Migration ZIP
              </span>
              <span className="text-[11px] font-mono text-zinc-400 bg-white/5 px-2 py-0.5 rounded-md">
                Full Workspace
              </span>
            </div>

            <h3 className="text-xl font-bold text-white tracking-tight">
              OpenAssist-Full-Project.zip
            </h3>

            <p className="text-xs text-zinc-300 leading-relaxed">
              Contains the <strong>entire project workspace</strong>: native Android source, C++ Whisper bridge, mascot SVGs, and the React/Vite Web Companion (Phone Simulator, Brand Studio, docs).
            </p>

            <div className="bg-black/30 rounded-xl p-3 border border-white/5 space-y-1.5 text-[11px] text-zinc-300">
              <div className="text-cyan-300 font-semibold">🔄 Zero-Token AI Studio Transfer Method:</div>
              <p className="text-[11px] text-zinc-400 leading-normal">
                Upload this zip into a new AI Studio session. Use the 1-click prompt below to unpack everything in 1 second without wasting any reasoning tokens.
              </p>
            </div>

            <ul className="text-xs text-zinc-300 space-y-1.5 pt-1">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Complete dual-target workspace (Android + React/Vite web)</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Includes all setup scripts, AI directives, and CLAUDE.md</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>100% preserves file structure with zero modifications</span>
              </li>
            </ul>
          </div>

          <div className="space-y-2 pt-2">
            <button
              onClick={handleDownloadFullZip}
              disabled={isZippingFull}
              className={`w-full py-3.5 px-5 rounded-2xl font-bold text-sm flex items-center justify-center gap-2.5 transition-all shadow-lg ${
                isZippingFull
                  ? 'bg-zinc-700 text-zinc-400 cursor-not-allowed'
                  : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-cyan-600/30 hover:scale-[1.01] active:scale-[0.99]'
              }`}
            >
              {isZippingFull ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/40 border-t-transparent rounded-full animate-spin" />
                  Downloading Migration Zip...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  Download Full Migration ZIP
                </>
              )}
            </button>
            <div className="flex items-center justify-between text-[11px] text-zinc-400 px-1">
              <span>Size: ~256 KB (Entire project)</span>
              <a
                href="/OpenAssist-Full-Project.zip"
                download="OpenAssist-Full-Project.zip"
                className="text-cyan-400 hover:underline"
              >
                Direct Link
              </a>
            </div>
          </div>
        </div>
      </div>

      {downloadSuccess && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-2xl flex items-center gap-2 text-xs text-emerald-300 font-semibold animate-fade-in">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>Successfully downloaded {downloadSuccess}!</span>
        </div>
      )}

      {downloadError && (
        <div className="p-3 bg-rose-950/60 border border-rose-500/40 rounded-2xl flex items-center gap-2 text-xs text-rose-300 font-semibold animate-fade-in">
          <AlertCircle className="w-4 h-4 text-rose-400" />
          <span>{downloadError}</span>
        </div>
      )}

      {/* AI Studio Transfer Card (Zero-Token Prompt) */}
      <div className="relative overflow-hidden bg-gradient-to-r from-indigo-950/50 via-[#181A28] to-[#121318] border border-indigo-500/40 rounded-3xl p-6 md:p-7 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-bold border border-indigo-500/30">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              Transfer to Another AI Studio Session (Zero Tokens)
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Moving this project to a new session?
            </h2>
            <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed max-w-2xl">
              Don&apos;t copy-paste raw code dumps into the chat. Download <strong>OpenAssist-Full-Project.zip</strong> above, upload it to your new AI Studio session, and give the AI this 1-sentence prompt. The AI will extract all 70+ files in 1 second without wasting any reasoning tokens!
            </p>
          </div>
          <div className="shrink-0 w-full md:w-auto flex flex-col gap-2">
            <button
              onClick={() => copyToClipboard(
                'I have uploaded OpenAssist-Full-Project.zip. Please run `unzip -o OpenAssist-Full-Project.zip`, install packages `jszip` and `@types/jszip`, ensure `chmod +x gradlew`, and run `compile_applet`. Keep all dual Android and web companion code intact without changing any lines.',
                'transfer_prompt'
              )}
              className="w-full md:w-auto px-5 py-3 rounded-2xl font-bold text-xs bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center gap-2 transition-all shadow-md active:scale-95"
            >
              {copiedCmd === 'transfer_prompt' ? (
                <>
                  <Check className="w-4 h-4 text-emerald-300" />
                  Copied 1-Click Prompt!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-indigo-200" />
                  Copy AI Studio Prompt
                </>
              )}
            </button>
            <span className="text-[10px] text-zinc-400 text-center">See TRANSFER_INSTRUCTIONS.md</span>
          </div>
        </div>
      </div>

      {/* GitHub Actions Instructions */}
      <div className="bg-[#1A1B20] border border-[#2D2F36] rounded-2xl p-6 md:p-8 space-y-6">
        {showCicdMascot && (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-950/60 via-[#1F2232] to-[#161824] border border-indigo-500/30 flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center p-1.5 shadow-md shrink-0 relative">
                <OpenAssistLogo style={logoStyle} size={32} theme="dark" customIcons={customIcons} />
                <span className="absolute -bottom-1 -right-1 text-xs"> </span>
              </div>
              <div className="text-left">
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-bold text-white tracking-tight">CI/CD Build Automation Pipeline</h4>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
                    Gradle 8.7 Ready
                  </span>
                </div>
                <p className="text-[11px] text-zinc-300 mt-0.5">
                  Pre-configured with Ubuntu 22.04 LTS runner, Java 17 Temurin, CMake 3.22, NDK Whisper bridge, and auto-signing.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-indigo-300 bg-black/40 px-3 py-1.5 rounded-xl border border-white/5">
              <Wrench className="w-3.5 h-3.5 text-indigo-400" />
              <span>Self-Healing Build Action</span>
            </div>
          </div>
        )}

        <div>
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Github className="w-5 h-5 text-white" />
            How to Build the APK in 2 Minutes via GitHub Actions
          </h3>
          <p className="text-xs text-zinc-400 mt-1">
            GitHub Actions provides free Linux cloud runners with Java 17 and Gradle already configured. No local SDK needed.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-[#202126] border border-white/5 rounded-xl p-4 flex flex-col justify-between space-y-2">
            <div>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#8AB4F8]/10 text-[#8AB4F8] font-bold">
                Step 1
              </span>
              <h4 className="text-xs font-bold text-white mt-2">Download Build Zip</h4>
              <p className="text-[11px] text-zinc-400 mt-1 leading-normal">
                Click Download on <code className="text-indigo-300 font-semibold">OpenAssist_v.1.54.0.zip</code> above.
              </p>
            </div>
            <FileArchive className="w-6 h-6 text-[#8AB4F8] self-end opacity-40" />
          </div>
          <div className="bg-[#202126] border border-white/5 rounded-xl p-4 flex flex-col justify-between space-y-2">
            <div>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#8AB4F8]/10 text-[#8AB4F8] font-bold">
                Step 2
              </span>
              <h4 className="text-xs font-bold text-white mt-2">Create GitHub Repo</h4>
              <p className="text-[11px] text-zinc-400 mt-1 leading-normal">
                Create a new repository on GitHub named e.g. <code className="text-zinc-200">openassist</code>.
              </p>
            </div>
            <Github className="w-6 h-6 text-[#8AB4F8] self-end opacity-40" />
          </div>
          <div className="bg-[#202126] border border-white/5 rounded-xl p-4 flex flex-col justify-between space-y-2">
            <div>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#8AB4F8]/10 text-[#8AB4F8] font-bold">
                Step 3
              </span>
              <h4 className="text-xs font-bold text-white mt-2">Push Code</h4>
              <p className="text-[11px] text-zinc-400 mt-1 leading-normal">
                Push all files into the <code className="text-zinc-200">main</code> branch using git or GitHub web upload.
              </p>
            </div>
            <Terminal className="w-6 h-6 text-[#8AB4F8] self-end opacity-40" />
          </div>
          <div className="bg-[#202126] border border-white/5 rounded-xl p-4 flex flex-col justify-between space-y-2">
            <div>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-bold">
                Step 4
              </span>
              <h4 className="text-xs font-bold text-white mt-2">Download APK</h4>
              <p className="text-[11px] text-zinc-400 mt-1 leading-normal">
                Go to the <strong>Actions</strong> tab on your repo. Select the completed build, and download the <code className="text-emerald-300">OpenAssist-apk</code> artifact!
              </p>
            </div>
            <Download className="w-6 h-6 text-emerald-400 self-end opacity-40" />
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-[#8AB4F8]" />
              Terminal Commands to Push to GitHub
            </span>
            <button
              onClick={() => copyToClipboard(gitPushScript, 'git_push')}
              className="text-xs text-[#8AB4F8] hover:text-white flex items-center gap-1"
            >
              {copiedCmd === 'git_push' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  Copy Commands
                </>
              )}
            </button>
          </div>
          <pre className="bg-[#121316] border border-white/10 rounded-xl p-4 text-xs font-mono text-zinc-300 overflow-x-auto leading-relaxed">
            {gitPushScript}
          </pre>
        </div>
      </div>
    </div>
  );
};
