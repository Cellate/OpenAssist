import React, { useState, useRef } from 'react';
import {
  X, Check, Sparkles, Upload, Trash2, Search,
  RotateCcw, AlertCircle
} from 'lucide-react';
import {
  OpenAssistLogo,
  LogoStyle,
  CustomIconItem
} from './LogoVariations';
import { processIconFile, DEFAULT_LOGO } from '../utils/customIcons';

interface MascotItem {
  id: LogoStyle;
  name: string;
  tagline: string;
  category: 'flagship' | 'independent' | 'owl' | 'fox' | 'other';
  badge: string;
}

const ALL_MASCOTS: MascotItem[] = [
  {
    id: 'owl-orbital',
    name: 'Ozzy',
    tagline: 'Flagship Circle-to-Search Sentinel (Default)',
    category: 'flagship',
    badge: 'Flagship Default',
  },
  {
    id: 'owl',
    name: 'Ozzy Classic',
    tagline: 'Classic Night-Vision Sentinel',
    category: 'owl',
    badge: 'Classic',
  },
  {
    id: 'fox',
    name: 'Pip Nexus',
    tagline: 'The Master Synthesis Circle-to-Search Fox',
    category: 'flagship',
    badge: 'Master Synthesis',
  },
  {
    id: 'bat',
    name: 'Echo the Sonic Bat',
    tagline: 'Ultrasonic Acoustic & Whisper Voice Scout',
    category: 'independent',
    badge: 'Audio Radar',
  },
  {
    id: 'otter',
    name: 'Nova the Star Otter',
    tagline: 'Zero-Gravity Deep-Query Navigator & AI Pearl',
    category: 'independent',
    badge: 'Cosmic Diver',
  },
  {
    id: 'chameleon',
    name: 'Pico the Chameleon',
    tagline: 'Dual-Focal 360 Degree Multi-Modal Vision Turrets',
    category: 'independent',
    badge: 'Dual-Focus',
  },
  {
    id: 'tanuki',
    name: 'Taro the Quantum Tanuki',
    tagline: 'On-Device Pixel Transformer & Shape-Shifter',
    category: 'independent',
    badge: 'Transformer',
  },
  {
    id: 'sprite',
    name: 'Ollie the Cosmic Sprite',
    tagline: 'Chubby Floating Droid with Search Spectacles',
    category: 'independent',
    badge: 'Cosmic Droid',
  },
  {
    id: 'kitten',
    name: 'Byte the Dumpling Kitten',
    tagline: 'Squishy Robo-Kitten with Paws on Portal',
    category: 'independent',
    badge: 'Squishy Kitten',
  },
  {
    id: 'firefly',
    name: 'Lumi the Cyber-Firefly',
    tagline: 'Bioluminescent Spotlight & Screen Radar',
    category: 'independent',
    badge: 'Bioluminescent',
  },
  {
    id: 'axolotl',
    name: 'Kiko the Cosmic Axolotl',
    tagline: 'Bubble-Helmet Astronaut Vision Explorer',
    category: 'independent',
    badge: 'Space Axolotl',
  },
  {
    id: 'owl-cosmic',
    name: 'Ozzy Cosmic Orbit',
    tagline: 'Planetary Aura & Star Spark Sentinel',
    category: 'owl',
    badge: 'Cosmic Orbit',
  },
  {
    id: 'owl-talons',
    name: 'Ozzy Kawaii Perch',
    tagline: 'Irresistibly Chubby Owl with Talons on Lens Rim',
    category: 'owl',
    badge: 'Kawaii Perch',
  },
  {
    id: 'owl-radar',
    name: 'Ozzy Screen Scanner',
    tagline: 'Holographic Targeting Reticles & Crosshair HUD',
    category: 'owl',
    badge: 'Screen Radar',
  },
  {
    id: 'owl-wings',
    name: 'Ozzy Privacy Shield',
    tagline: 'Aerodynamic Wing Embrace for Zero Telemetry',
    category: 'owl',
    badge: 'Privacy Shield',
  },
  {
    id: 'owl-monocle',
    name: 'Ozzy Scholar Loupe',
    tagline: 'Single-Lens Magnifier Loupe & Inquisitive Wink',
    category: 'owl',
    badge: 'Scholar Loupe',
  },
  {
    id: 'owl-minimal',
    name: 'Ozzy Pure-Minimal',
    tagline: 'DeepSeek Bauhaus Silhouette for 16px Favicons',
    category: 'owl',
    badge: 'Minimal Vector',
  },
  {
    id: 'fox-orbital',
    name: 'Pip Astro-Lasso',
    tagline: 'Continuous Gesture Track Loop & 3 Nodes',
    category: 'fox',
    badge: 'Astro-Lasso',
  },
  {
    id: 'fox-cyber',
    name: 'Pip Cyber-Visor',
    tagline: 'Ozzy Connected Visor & Voice Acoustic Facets',
    category: 'fox',
    badge: 'Cyber-Visor',
  },
  {
    id: 'fox-paws',
    name: 'Pip Paws-on-Lens',
    tagline: 'Two Tiny White Paws Resting on Search Glasses',
    category: 'fox',
    badge: 'Kawaii Paws',
  },
  {
    id: 'fox-firefly',
    name: 'Pip Radar-Lens',
    tagline: 'Bioluminescent Screen Targeting HUD Reticle',
    category: 'fox',
    badge: 'Radar HUD',
  },
  {
    id: 'fox-halo',
    name: 'Pip Cosmic-Halo',
    tagline: 'Planetary Floating Orbital Ring & Star Sparks',
    category: 'fox',
    badge: 'Planetary Halo',
  },
  {
    id: 'fox-headset',
    name: 'Pip Voice-Sentinel',
    tagline: 'Acoustic Communicator Earcups & Waveform Pulse',
    category: 'fox',
    badge: 'Voice Headset',
  },
  {
    id: 'fox-monocle',
    name: 'Pip Scout-Loupe',
    tagline: 'Magnifying Loupe Glass & Curious Anime Wink',
    category: 'fox',
    badge: 'Scout Loupe',
  },
  {
    id: 'fox-minimal',
    name: 'Pip Pure-Minimal',
    tagline: 'Modernist High-Contrast Aerodynamic Contour',
    category: 'fox',
    badge: 'Pure Minimal',
  },
  {
    id: 'orbital',
    name: 'Kube-Loop Iris',
    tagline: 'Pure Geometric Gesture Continuity Ring',
    category: 'other',
    badge: 'Geometric',
  },
  {
    id: 'whale',
    name: 'Moby-Ray',
    tagline: 'Oceanic Deep-Assist Looping Cetacean',
    category: 'other',
    badge: 'Oceanic',
  },
];

interface LogoSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLogo: LogoStyle;
  onSelectLogo: (style: LogoStyle) => void;
  customIcons: CustomIconItem[];
  onAddCustomIcon: (icon: CustomIconItem) => void;
  onDeleteCustomIcon: (id: string) => void;
  isDarkMode?: boolean;
}

export const LogoSwitcherModal: React.FC<LogoSwitcherModalProps> = ({
  isOpen,
  onClose,
  currentLogo,
  onSelectLogo,
  customIcons,
  onAddCustomIcon,
  onDeleteCustomIcon,
  isDarkMode: propDarkMode,
}) => {
  const isDark = propDarkMode ?? (typeof window !== 'undefined' && window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)').matches : true);
  const [filter, setFilter] = useState<'all' | 'flagship' | 'independent' | 'owl' | 'fox' | 'custom'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [customName, setCustomName] = useState('');
  const [previewDataUrl, setPreviewDataUrl] = useState<string | null>(null);
  const [previewIsSvg, setPreviewIsSvg] = useState(false);
  const [previewSvgText, setPreviewSvgText] = useState<string | undefined>();
  const [previewFileType, setPreviewFileType] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const activeCustom = customIcons.find((c) => `custom:${c.id}` === currentLogo);
  const activeBuiltIn = ALL_MASCOTS.find((m) => m.id === currentLogo);
  const isDefaultActive = currentLogo === DEFAULT_LOGO;

  const handleFileProcess = async (file: File) => {
    try {
      setUploadError(null);
      const res = await processIconFile(file);
      setPreviewDataUrl(res.dataUrl);
      setPreviewIsSvg(res.isSvg);
      setPreviewSvgText(res.svgText);
      setPreviewFileType(res.fileType);
      setCustomName(res.name);
    } catch (err: any) {
      setUploadError(err.message || 'Could not load icon file.');
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileProcess(e.target.files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };

  const handleSaveCustom = () => {
    if (!previewDataUrl) return;
    const newId = `icon_${Date.now()}`;
    const newIcon: CustomIconItem = {
      id: newId,
      name: customName.trim() || 'My Custom Mascot',
      dataUrl: previewDataUrl,
      fileType: previewFileType || 'image/png',
      isSvg: previewIsSvg,
      svgText: previewSvgText,
      createdAt: Date.now(),
    };
    onAddCustomIcon(newIcon);
    onSelectLogo(`custom:${newId}` as LogoStyle);
    setPreviewDataUrl(null);
    setCustomName('');
    setPreviewSvgText(undefined);
  };

  const filteredMascots = ALL_MASCOTS.filter((item) => {
    const matchesFilter =
      filter === 'all' ||
      (filter === 'flagship' && item.category === 'flagship') ||
      (filter === 'independent' && item.category === 'independent') ||
      (filter === 'owl' && (item.category === 'owl' || item.id === 'owl')) ||
      (filter === 'fox' && (item.category === 'fox' || item.id === 'fox'));

    const matchesSearch =
      !searchQuery.trim() ||
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.tagline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.badge.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  const filteredCustomIcons = customIcons.filter((item) => {
    return (
      !searchQuery.trim() ||
      item.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className={`${
          isDark
            ? 'bg-[#121318] border-white/10 text-white shadow-indigo-950/40'
            : 'bg-white border-slate-300 text-slate-900 shadow-2xl'
        } border rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className={`p-5 sm:px-6 border-b flex items-start justify-between gap-4 ${
          isDark ? 'border-white/10 bg-[#161822]' : 'border-slate-200 bg-slate-100'
        }`}>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xl"> </span>
              <h2 className={`text-xl font-bold tracking-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                Mascot &amp; Logo Switcher
              </h2>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-semibold border ${
                isDark ? 'bg-indigo-500/15 text-indigo-400 border-indigo-500/25' : 'bg-blue-100 text-blue-800 border-blue-300'
              }`}>
                Default: Ozzy Sentinel
              </span>
            </div>
            <p className={`text-xs ${isDark ? 'text-zinc-400' : 'text-slate-600'}`}>
              Select your favorite mascot companion or upload a custom SVG/image to customize OpenAssist across the entire app.
            </p>
          </div>
          <button
            onClick={onClose}
            className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors ${
              isDark ? 'bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white' : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
            }`}
            title="Close switcher"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className={`px-5 sm:px-6 py-3.5 border-b flex flex-wrap items-center justify-between gap-3 text-xs ${
          isDark ? 'bg-gradient-to-r from-[#171926] via-[#141620] to-[#171926] border-white/5' : 'bg-slate-50 border-slate-200 text-slate-900'
        }`}>
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl border p-1 flex items-center justify-center shrink-0 shadow ${
              isDark ? 'bg-[#0F1016] border-white/15' : 'bg-white border-slate-200'
            }`}>
              <OpenAssistLogo
                style={currentLogo}
                size={34}
                theme={isDark ? 'dark' : 'light'}
                customIcons={customIcons}
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className={`text-[11px] font-bold uppercase tracking-wider ${isDark ? 'text-zinc-400' : 'text-slate-600'}`}>
                  Active Logo:
                </span>
                <span className={`font-bold text-sm ${isDark ? 'text-white' : 'text-slate-900'}`}>
                  {activeCustom
                    ? activeCustom.name
                    : activeBuiltIn?.name || 'Ozzy Sentinel'}
                </span>
                {isDefaultActive && (
                  <span className="text-[10px] bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 px-2 py-0.2 rounded-full font-semibold border border-emerald-500/25">
                    Recommended Default
                  </span>
                )}
              </div>
              <p className={`text-[11px] line-clamp-1 ${isDark ? 'text-zinc-400' : 'text-slate-600'}`}>
                {activeCustom
                  ? 'Custom Uploaded Mascot'
                  : activeBuiltIn?.tagline || 'OpenAssist Flagship'}
              </p>
            </div>
          </div>
          {!isDefaultActive && (
            <button
              onClick={() => onSelectLogo(DEFAULT_LOGO)}
              className="px-3 py-1.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset to Ozzy Sentinel
            </button>
          )}
        </div>

        <div className="p-4 sm:px-6 border-b border-white/5 bg-[#14151C] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition ${
                filter === 'all'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10'
              }`}
            >
              All ({ALL_MASCOTS.length + customIcons.length})
            </button>
            <button
              onClick={() => setFilter('flagship')}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition flex items-center gap-1 ${
                filter === 'flagship'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <span> </span> Flagships (2)
            </button>
            <button
              onClick={() => setFilter('independent')}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition flex items-center gap-1 ${
                filter === 'independent'
                  ? 'bg-cyan-600 text-white shadow-md'
                  : 'bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <Sparkles className="w-3 h-3 text-amber-300" /> Independent (8)
            </button>
            <button
              onClick={() => setFilter('owl')}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition flex items-center gap-1 ${
                filter === 'owl'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <span> </span> Ozzy Family (7)
            </button>
            <button
              onClick={() => setFilter('fox')}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition flex items-center gap-1 ${
                filter === 'fox'
                  ? 'bg-orange-600 text-white shadow-md'
                  : 'bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <span> </span> Pip Family (9)
            </button>
            <button
              onClick={() => setFilter('custom')}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition flex items-center gap-1 ${
                filter === 'custom'
                  ? 'bg-pink-600 text-white shadow-md'
                  : 'bg-white/5 text-zinc-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <Upload className="w-3 h-3" /> Custom ({customIcons.length})
            </button>
          </div>
          <div className="relative min-w-[180px]">
            <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search mascots..."
              className="w-full bg-[#1C1E2A] border border-white/10 rounded-xl pl-8 pr-3 py-1 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          <div
            className={`rounded-2xl border transition-all p-4 ${
              isDragging
                ? 'border-indigo-400 bg-indigo-500/10'
                : 'border-white/10 bg-[#161722]/80 hover:border-white/20'
            }`}
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".svg,.png,.jpg,.jpeg,.webp,.gif,image/*"
              className="hidden"
              onChange={handleFileInputChange}
            />
            {!previewDataUrl ? (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      Upload Custom Mascot / Logo
                      <span className="text-[10px] font-normal px-2 py-0.5 rounded-full bg-white/5 text-zinc-400 border border-white/10">
                        SVG, PNG, JPG, WebP
                      </span>
                    </h4>
                    <p className="text-xs text-zinc-400 mt-0.5">
                      Drag &amp; drop an icon file here, or browse from your computer.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md flex items-center gap-1.5 transition active:scale-95 shrink-0"
                >
                  <Upload className="w-3.5 h-3.5" />
                  Browse Icon File
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#111218] p-3.5 rounded-xl border border-white/5">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-xl bg-[#0D0E13] border border-white/15 p-1 flex items-center justify-center overflow-hidden shrink-0">
                      {previewIsSvg && previewSvgText ? (
                        <div
                          className="w-full h-full flex items-center justify-center [&>svg]:w-full [&>svg]:h-full"
                          dangerouslySetInnerHTML={{ __html: previewSvgText }}
                        />
                      ) : (
                        <img
                          src={previewDataUrl}
                          alt="Preview"
                          className="w-full h-full object-contain"
                        />
                      )}
                    </div>
                    <div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/25">
                        {previewIsSvg ? 'Vector SVG' : previewFileType || 'Raster Image'}
                      </span>
                      <div className="mt-1 flex items-center gap-2">
                        <label className="text-xs text-zinc-400">Name:</label>
                        <input
                          type="text"
                          value={customName}
                          onChange={(e) => setCustomName(e.target.value)}
                          placeholder="Mascot Name"
                          className="bg-[#1C1E2A] border border-white/10 rounded-lg px-2.5 py-1 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                    <button
                      type="button"
                      onClick={() => setPreviewDataUrl(null)}
                      className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white text-xs font-medium transition"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveCustom}
                      className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Save &amp; Apply as Logo
                    </button>
                  </div>
                </div>
              </div>
            )}
            {uploadError && (
              <p className="text-xs text-rose-400 flex items-center gap-1 mt-2">
                <AlertCircle className="w-3.5 h-3.5" />
                {uploadError}
              </p>
            )}
          </div>

          {customIcons.length > 0 && (filter === 'all' || filter === 'custom') && (
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                <Upload className="w-3.5 h-3.5 text-pink-400" />
                Your Custom Uploaded Icons ({customIcons.length})
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {filteredCustomIcons.map((custom) => {
                  const isActive = currentLogo === `custom:${custom.id}`;
                  return (
                    <div
                      key={custom.id}
                      onClick={() => onSelectLogo(`custom:${custom.id}` as LogoStyle)}
                      className={`relative rounded-2xl p-3.5 border cursor-pointer transition-all flex flex-col justify-between ${
                        isActive
                          ? 'bg-[#181A28] border-indigo-500 ring-2 ring-indigo-500/30 scale-[1.02]'
                          : 'bg-[#151620] border-white/5 hover:border-white/20 hover:bg-[#181924]'
                      }`}
                    >
                      {isActive && (
                        <span className="absolute top-2.5 right-2.5 w-5 h-5 rounded-full bg-emerald-500 text-black flex items-center justify-center text-xs font-bold shadow">
                          ✓
                        </span>
                      )}
                      <div className="w-full h-24 rounded-xl bg-[#0C0D12] border border-white/5 flex items-center justify-center p-2 mb-2.5">
                        <OpenAssistLogo
                          style={`custom:${custom.id}` as LogoStyle}
                          size={64}
                          customIcon={custom}
                        />
                      </div>
                      <div className="flex items-center justify-between gap-1">
                        <div className="overflow-hidden">
                          <p className="text-xs font-bold text-white truncate">
                            {custom.name}
                          </p>
                          <span className="text-[10px] text-zinc-400 font-mono">
                            {custom.isSvg ? 'SVG' : 'Image'}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (window.confirm(`Delete custom mascot "${custom.name}"?`)) {
                              onDeleteCustomIcon(custom.id);
                              if (isActive) {
                                onSelectLogo(DEFAULT_LOGO);
                              }
                            }
                          }}
                          className="w-6 h-6 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 flex items-center justify-center transition shrink-0"
                          title="Delete custom icon"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                OpenAssist Mascot Family ({filteredMascots.length})
              </h3>
              <span className="text-[11px] text-zinc-400">
                Click any mascot to activate
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {filteredMascots.map((item) => {
                const isActive = currentLogo === item.id;
                const isDefault = item.id === DEFAULT_LOGO;
                return (
                  <div
                    key={item.id}
                    onClick={() => onSelectLogo(item.id)}
                    className={`relative rounded-2xl p-3.5 border cursor-pointer transition-all duration-200 flex flex-col justify-between group ${
                      isActive
                        ? 'bg-[#181A28] border-indigo-500 shadow-lg shadow-indigo-500/20 ring-2 ring-indigo-500/40 scale-[1.02]'
                        : 'bg-[#151620] border-white/5 hover:border-white/20 hover:bg-[#181924]'
                    }`}
                  >
                    {isActive ? (
                      <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500 text-black flex items-center gap-1 shadow">
                        <Check className="w-3 h-3" /> ACTIVE
                      </span>
                    ) : isDefault ? (
                      <span className="absolute top-2.5 right-2.5 px-1.5 py-0.5 rounded text-[9px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                        DEFAULT
                      </span>
                    ) : null}
                    <div className="w-full h-28 rounded-xl bg-[#0C0D12] border border-white/5 flex items-center justify-center p-3 mb-2.5 group-hover:scale-105 transition-transform duration-200">
                      <OpenAssistLogo style={item.id} size={70} theme="dark" />
                    </div>
                    <div>
                      <span className="inline-block px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider text-indigo-300 bg-indigo-500/15 mb-1">
                        {item.badge}
                      </span>
                      <h4 className="text-xs font-bold text-white tracking-tight leading-snug">
                        {item.name}
                      </h4>
                      <p className="text-[11px] text-zinc-400 mt-0.5 line-clamp-2 leading-relaxed">
                        {item.tagline}
                      </p>
                    </div>
                    <div className="mt-3 pt-2 border-t border-white/5 flex items-center justify-between text-[11px]">
                      <span className="text-zinc-400 font-mono text-[10px]">
                        {item.id}.svg
                      </span>
                      <span
                        className={`font-semibold ${
                          isActive ? 'text-emerald-400' : 'text-zinc-400 group-hover:text-indigo-400'
                        }`}
                      >
                        {isActive ? 'Applied' : 'Select'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="p-4 sm:px-6 border-t border-white/10 bg-[#161822] flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-zinc-400">
            <span>Current Default:</span>
            <strong className="text-white">Ozzy Sentinel (Flagship Owl)</strong>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-medium transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
