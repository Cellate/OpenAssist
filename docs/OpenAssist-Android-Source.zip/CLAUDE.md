# OpenAssist - Instructions for Claude & AI Agents
See `AI_INSTRUCTIONS.txt` for the full comprehensive specification (Single Source of Truth).
Active Version: `v1.58.1` (Iteration 58, Bugfix 1).

## Core Directives & Things NOT to Do:
1. **Never delete `gradle/wrapper/gradle-wrapper.jar`**: It is an essential binary needed by `./gradlew` and GitHub Actions CI.
2. **Never change `Activity` to `ComponentActivity` or `AppCompatActivity`**: The Android app uses native `android.app.Activity` without heavy AndroidX/Jetpack dependencies.
3. **Never remove C++ / NDK Whisper bridge**: Keep `CMakeLists.txt`, `whisper_jni.cpp`, and `ndkVersion = "25.2.9519653"` in `app/build.gradle.kts`.
4. **Never simplify GitHub Actions workflows**: `.github/workflows/main.yml` must retain setup-gradle@v4, setup-java JDK 17, and NDK r25c. (Only `main.yml` is kept; `build.yml` is deleted to prevent duplicate runs).
5. **Keep Mascot name as "Ozzy"**: Default mascot id is `owl-orbital`, name is "Ozzy". All 27 cute mascot vectors live ONLY in `assets/mascots/`.
6. **No duplicate XML attributes**: AAPT2 strictly fails if any vector drawable has duplicate attributes (e.g. `android:fillColor`).
7. **Zero Telemetry**: No telemetry, analytics, or remote tracking pings.
8. **Dual Architecture**: Preserve both the Vite/React web companion and the native Android app.
9. **Never clip top bar pills or remove HorizontalScrollView**: In `activity_web.xml` and `PhoneSimulator.tsx`, top bar pills must scroll horizontally and mascot chips must adapt dynamically without fixed width truncations.
10. **Never block Whisper model deletion**: Allow deleting any imported model with confirmation, unbinding fallback, and physical `.bin` file cleanup.
11. **Allow removing pre-existing standard languages**: In Per-Language Model Binding, users can delete standard (Hinglish/Hindi/English) as well as custom languages, with a "Reset Standard Languages" button to restore them.
12. **Preserve Community Translation UI Context**: Exported `.txt` translations must include `# UI Context:` comments so translators and AI engines have clear context.
13. **Preserve per-menu language preferences**: Keep `appLanguage`, `settingsLanguage`, `overlayLanguage`, `webUiLanguage`, and `mascotLanguage` distinct in `Prefs.kt`.
14. **Synchronize iteration versions**: Always keep version `v1.58.1` in sync across `AI_INSTRUCTIONS.txt`, `.github/workflows/main.yml`, `scripts/build_source_zip.js`, and `TRANSFER_INSTRUCTIONS.md`.

## Commands:
- Build source ZIPs: `node scripts/build_source_zip.js`
- Validate Android XMLs: `python3 -c "import xml.etree.ElementTree as ET, glob; [ET.parse(f) for f in glob.glob('app/src/main/res/**/*.xml', recursive=True)]"`
- Test Web Companion: `npm run build`
- Compile Applet: `compile_applet`
