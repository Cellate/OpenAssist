# OpenAssist GitHub Master README & High-Converting Web Landing Experience

Comprehensive architectural blueprint to transform OpenAssist's GitHub presentation into the definitive open-source assistant showcase, alongside a high-converting web landing page optimized for GitHub Pages with instant 1-tap APK downloads, interactive live simulator demo, mascot lore & emotional feedback system, and complete security verification.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following product decisions were established during Phase 1 interactive clarification:
> - **Primary Objective**: Build a landing experience and GitHub presence that maximizes conversion to app installation, exceeding high aesthetic expectations with immediate 1-tap APK downloads pointing dynamically to the latest release (`v1.65.0`).
> - **Mascot Philosophy & Lore**: Feature a dedicated showcase detailing the companion personalities, why OpenAssist has mascots (humanizing cold AI, visual emotion feedback, privacy guardianship), and real-time audio/visual reactivity.
> - **Visitor Journey Priority**: Anchor visitor attention immediately with 1-tap APK download, security verification badges (Hardware Keystore AES-256-GCM, zero telemetry, local AI routing), and an embedded interactive simulator preview.

- **Confirmed Decision 1 (Dual Experience Architecture)**: The existing Vite React web app already houses a phone simulator, brand studio, mascot lab, code explorer, and download manager. Rather than splitting into a disconnected second codebase, we elevate the web app into a high-converting marketing landing page as its default view (`landing`), with a sticky conversion bar, instant APK download CTA, security guarantee cards, mascot companion interactive explorer, and 1-tap switcher into the interactive phone simulator. This creates an all-in-one GitHub Pages deployment ready to publish directly via GitHub Actions.
- **Confirmed Decision 2 (World-Class GitHub README)**: Revamp `README.md` into an industry-benchmark repository document. It will incorporate high-fidelity mascot badges, a deep philosophical manifesto ("Why Open, Why Private, Why Mascots"), an interactive feature breakdown with technical precision, the 10-layer defense-in-depth security model, architecture diagrams, benchmark comparisons against proprietary walled gardens, and one-command build/install guides.
- **Confirmed Decision 3 (GitHub Pages CI Automation)**: Provide a streamlined GitHub Actions workflow (`.github/workflows/pages.yml`) or integrate GitHub Pages building into the export scripts so any user can host the live web landing page on `<user>.github.io/<repo>` with zero manual server configuration.

---

### 1. Overview & Core Concept

- **What It Does**: OpenAssist is the 100% free, GPL-3.0-licensed digital assistant and "Circle to Search" system for Android (10–15+) that untethers users from proprietary Big Tech silos. It bridges native system-level gestures (`VoiceInteractionService`), offline C++ Whisper transcription, sub-millimeter 8-handle visual crop/zoom, and universal AI routing (Gemini, Claude, ChatGPT, Grok, DeepSeek, local Ollama/LM Studio) protected by hardware-backed Keystore encryption.
- **Target Audience / Persona**:
  1. *Privacy Enthusiasts & ROM Users* (GrapheneOS, CalyxOS, LineageOS) who demand zero telemetry, no Google account requirement, and strict on-device data sovereignty.
  2. *Power Users & Developers* running self-hosted local LLMs (Ollama) seeking zero-lock-in screen search on Android.
  3. *Everyday Android Users* seeking a faster, friendlier, customizable alternative to Google Assistant or Gemini with delightful mascot companions.
- **Key Value**: Delivers the fluid "Circle to Search" gesture and multimodal assistance without surrendering screen privacy, personal telemetry, or choice of AI intelligence.

---

### 2. User Experience & Visual Design

#### Key User Flows

```
  VISITOR ARRIVAL (GitHub / Web)
                │
                ▼
  ┌─────────────────────────────┐
  │ HERO: Value & Instant Action│
  │ • Headline: Freedom & Speed │
  │ • 1-Tap Primary: Direct APK │
  │ • Secondary: Live Web Demo  │
  │ • Trust Badges: GPLv3, 0-Log│
  └──────────────┬──────────────┘
                │
                ├──────────────────────────────────────┐
                ▼                                      ▼
  ┌─────────────────────────────┐       ┌─────────────────────────────┐
  │ THE MASCOT GALAXY (LORE)    │       │ 10-LAYER SECURITY PERIMETER │
  │ • 10 Core Animal Archetypes │       │ • Hardware Keystore AES-256 │
  │ • Emotional States & Audio  │       │ • Zero Telemetry Audits     │
  │ • Why Mascots Humanize AI   │       │ • Local Network Whitelists  │
  └──────────────┬──────────────┘       └──────────────┬──────────────┘
                │                                      │
                ├──────────────────────────────────────┘
                ▼
  ┌─────────────────────────────┐
  │ INTERACTIVE LIVE SIMULATOR  │
  │ • Real-time Circle-to-Search│
  │ • Switch AI Engines & Sound │
  │ • Test Touch Handles & Crop │
  └──────────────┬──────────────┘
                │
                ▼
  ┌─────────────────────────────┐
  │ DUAL EXPORT & RELEASES      │
  │ • Pure Android Build ZIP    │
  │ • GitHub Actions CI Guide   │
  │ • Direct Github Releases APK│
  └─────────────────────────────┘
```

#### Visual Identity & Theme
- **Aesthetic Direction**: Neo-editorial open-source clarity with obsidian canvas (`#090D16`), deep indigo/slate structures (`#0F172A`), and vibrant emerald/cyan accents (`#10B981` / `#06B6D4`) symbolizing security, velocity, and technical excellence.
- **Typographic System**:
  - *Display / Headlines*: `Plus Jakarta Sans`, tight tracking (`tracking-tight`), `text-wrap: balance` for zero single-word orphans.
  - *Body Prose*: `Plus Jakarta Sans` / `DM Sans` with generous line-height (`1.65`) for effortless reading.
  - *Technical Figures*: `tabular-nums` monospace (`JetBrains Mono` / system monospace) for hash digests, version codes, APK sizes, and telemetry audits.
- **Top Bar Contract**:
  - Single-line wordmark: `OpenAssist`
  - 4 single-line nav links: `Mascots & Philosophy`, `Security & Privacy`, `Interactive Demo`, `Releases`
  - 1 high-intent primary CTA button: `Download APK (v1.65.0)`
- **Conversion Discipline**:
  - Zero-pill metadata: badges rendered with clean typographic separators (`·` or `/`) rather than cluttered pill stacks.
  - No decorative status dots: status indicators reserved exclusively for dynamic download status and audio feedback.
  - High-converting hero: clear benefit statement, exact APK file size (~18 MB), architecture (`arm64-v8a` + `x86_64`), and Android compatibility (`Android 10 to 15+`).

---

### 3. Key Product Decisions & Trade-Offs

#### Decision 1: Unified Landing Page View inside the Web App
- *Chosen Approach*: Add a marquee `LandingView` as the premier starting tab (`tab = 'landing'`), while keeping immediate 1-click access to the full `PhoneSimulator`, `BrandStudio`, `MascotPlacementLab`, `ReadmeViewer`, `CodeExplorer`, and `DownloadSection`.
- *Why*: Allows visitors arriving at GitHub Pages to immediately experience a world-class landing page that persuades them to download the APK, while letting them seamlessly dive into the live interactive simulator without navigating away.
- *Alternatives Considered*: A separate multi-page HTML site would fragment maintenance and miss out on sharing reactive state, mascot audio synthesis, and real-time version metadata with the React app.

#### Decision 2: Mascot Companion Galaxy & Philosophical Manifesto
- *Chosen Approach*: Structure the mascot section around their specific philosophical and emotional roles in OpenAssist:
  1. *Ozzy the Owl* (Wisdom, Vision, Visual Search, Flagship)
  2. *Pip the Fox* (Voice, C++ Whisper, Agility)
  3. *Echo the Bat* (Acoustic Precision, Sound Synthesis)
  4. *Lumen the Firefly* (Clarity, Glow Lasso, Pixel Guidance)
  5. *Orion the Otter* (Cosmic Navigation, Fluid Gesture Multitasking)
  6. *Kage the Tanuki* (Pixel Transformation, Multimodal OCR)
  7. *Nyx the Axolotl* (Regeneration, Privacy Sovereignty, Zero-Telemetry)
- *Why*: Mascots in OpenAssist are not mere logos; they are affective feedback agents that communicate emotion (idle, happy, thinking, excited, focused), render sound chirps, and remind the user that AI should be friendly, transparent, and non-intrusive.

#### Decision 3: The 10-Layer Zero-Vulnerability Security Perimeter
- *Chosen Approach*: Detail the exact 10 security invariants implemented in v1.65.0:
  1. *Hardware Keystore AES-256-GCM*: Search history encryption with zero data loss migration.
  2. *Granular WebRTC Permissions*: Whitelisted AI domains + custom interactive mascot prompt for untrusted hosts.
  3. *Strict HTTPS & Private LAN Cleartext*: Global cleartext disabled; local subnets permitted exclusively for self-hosted Ollama.
  4. *Hardened WebView Sandbox*: Zero local file access (`allowFileAccess = false`), safe DOM nodes.
  5. *FileProvider Subdirectory Isolation*: Storage scoped strictly to cache subfolders (`updates/`, `selections/`, `camera/`).
  6. *In-App Updater Domain & ZIP Integrity Verification*: HTTPS + domain whitelisting + APK header parsing before install.
  7. *Native C++ JNI Memory Safety*: Null-guarding and lifetime logging in Whisper JNI bridge.
  8. *Zero Telemetry Architecture*: No analytics SDKs, no trackers, no crash beacons.
  9. *GPL-3.0-or-Later Copyleft Protection*: Freedom to inspect, modify, and fork guaranteed by law.
  10. *Single Canonical Asset Pipeline*: Zero duplicate resource conflicts during CI builds.

---

### 4. Technical Architecture & Implementation Strategy

#### Component Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                        App.tsx (Root Container)                        │
├────────────────────────────────────────────────────────────────────────┤
│ Top Bar: Wordmark ─── [Mascots · Security · Demo · Releases] ─── [APK] │
├────────────────────────────────────────────────────────────────────────┤
│ Active View Router:                                                    │
│                                                                        │
│ ┌────────────────────────────────────────────────────────────────────┐ │
│ │ LandingView.tsx (Premier High-Converting Visitor Showcase)        │ │
│ │  ├─ Hero: Download v1.65.0 APK, Version Meta, Quick Specs          │ │
│ │  ├─ Trust Strip: 0 Telemetry · GPL-3.0 · Hardware Keystore         │ │
│ │  ├─ Interactive Mini-Demo: Circle to Search Simulator Teaser      │ │
│ │  ├─ Mascot Galaxy: 7 Character Cards with Audio & Reaction Demo   │ │
│ │  ├─ Security Whitepaper: 10-Layer Defense-in-Depth Breakdown       │ │
│ │  ├─ Universal AI Routing Matrix: Cloud & Local Models Comparison  │ │
│ │  └─ Final Conversion Footer: One-click download & GitHub links     │ │
│ └────────────────────────────────────────────────────────────────────┘ │
│                                                                        │
│ ┌───────────────────────┐  ┌──────────────────────┐  ┌───────────────┐ │
│ │ PhoneSimulator.tsx    │  │ BrandStudio.tsx      │  │ DownloadSec.. │ │
│ └───────────────────────┘  └──────────────────────┘  └───────────────┘ │
└────────────────────────────────────────────────────────────────────────┘
```

#### GitHub Documentation Strategy (`README.md`)
- Overhaul `README.md` with:
  - Hero banner with Ozzy mascot, release badges (`v1.65.0`, `Android CI: Passing`, `GPL-3.0-or-later`, `Zero Telemetry`).
  - Executive summary and core philosophical pillars ("Why OpenAssist?").
  - The Mascot Companions gallery with SVG visuals, character roles, and audio-visual feedback mechanisms.
  - Interactive Circle to Search breakdown: 8-handle touch math, 0.6x–12.0x pinch-zoom, instant screen capture pipeline.
  - Complete 10-layer security and privacy architecture breakdown with code-level details.
  - Universal AI Connectivity: Step-by-step setup for Ollama, LM Studio, Claude, Gemini, ChatGPT.
  - GitHub Pages link and live web demo instructions.
  - Build-from-source and GitHub Actions CI instructions.

#### GitHub Pages Deployment Workflow (`.github/workflows/pages.yml`)
- Create standard GitHub Actions deployment workflow for GitHub Pages using `actions/deploy-pages@v4` and `actions/upload-pages-artifact@v3` with `npm run build`, ensuring repository owners can enable Pages with 1-click in repo settings (`Settings -> Pages -> GitHub Actions`).

---

### Verification & Testing Plan
1. **Compilation & Linting**: Run `compile_applet` and `lint_applet` to confirm zero TypeScript, React, or build errors.
2. **Dynamic Version Sync**: Confirm that all download links, version tags, file sizes, and release dates point dynamically to `v1.65.0` (`assets/version.json`).
3. **Interactive Audio & Handlers**: Verify that all mascot cards, audio preview buttons, simulator launchers, and copy-command buttons have active, working click handlers.
4. **Export Archive Integrity**: Rebuild source zip packages via `node scripts/build_source_zip.js` so `README.md` is updated in all distribution archives.
