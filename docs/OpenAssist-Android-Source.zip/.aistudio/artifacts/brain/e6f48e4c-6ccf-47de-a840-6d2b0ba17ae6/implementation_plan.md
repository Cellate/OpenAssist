# OpenAssist v1.61.0 - Web Stability Guard, Settings Navigation Redesign & GitHub Update Manager

A comprehensive architectural and engineering blueprint to eliminate cold-start Web UI crashes, restructure Settings navigation with an aesthetic left-aligned hamburger menu, introduce an in-app About & GitHub Update Manager, add informative gesture tooltips to Query History, and synchronize version metadata across all pipelines.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions were confirmed based on your requirements and clarifying interview:
> - **Public Repository Isolation**: The About & Update Manager interacts exclusively with the public repository **`https://github.com/Cellate/OpenAssist`** (`api.github.com/repos/Cellate/OpenAssist/releases/latest`). The development/staging repository `Cellate/OpenAssistDevelopmentv2` will remain 100% private and never exposed to users or code strings.
> - **Live GitHub API Check**: Includes a one-tap "Check for Updates" button that queries GitHub's REST API for latest releases, calculates semantic version differences, and provides a direct `.apk` download link with change notes.
> - **Settings Header Layout**: The Hamburger Menu button (which opens Full Query History) is moved to the far left. The title ("OpenAssist") and version badge are centered/positioned in the middle. The right button is replaced by a circular question mark ("About & Updates") button.
> - **Version Badge Synergy**: The version badge dynamically displays the active version (`v1.60.1` -> `v1.61.0`) and is directly clickable to open the About & Update Manager dialog.
> - **Query History Tooltip**: Displays an informative dismissible card inside the Complete AI Query History dialog highlighting the edge-swipe gesture (`Swipe right from left edge`) and tap-to-reask capability.
> - **WebActivity Crash Defense**: Robust hardening against cold-start Chromium crashes, `onRenderProcessGone` interception, `WebSettings` dynamic race conditions, and guarded data injection.

---

## 1. Overview & Core Concept

OpenAssist is an open-source, private, zero-bloat digital assistant for Android featuring Circle-to-Search, offline Whisper voice transcription, and full-screen web AI integration (Gemini, ChatGPT, Claude, Perplexity, etc.).

This release addresses intermittent cold-start crashes in `WebActivity`, polishes the Settings top-level navigation layout, adds community transparency and self-updating capabilities via public GitHub releases, and ensures the code remains clean, robust, and compliant with all project directives in `AI_INSTRUCTIONS.txt`.

```
┌────────────────────────────────────────────────────────────────────────┐
│                        SETTINGS TOP APP BAR                             │
├─────────────┬────────────────────────────────────────────┬─────────────┤
│  [≡ MENU]   │ OpenAssist  [ v1.61.0 ] (Clickable)        │  [(?) ABOUT]│
│  History    │ AI Voice Assistant & Circle-to-Search      │   & Updates │
└─────────────┴────────────────────────────────────────────┴─────────────┘
       │                                                           │
       ▼                                                           ▼
┌───────────────────────────────┐              ┌─────────────────────────┐
│ COMPLETE AI QUERY HISTORY     │              │ ABOUT & UPDATE MANAGER  │
│ ┌───────────────────────────┐ │              │ • App Summary & Readme  │
│ │ 💡 Pro-Tip Tooltip Banner │ │              │ • Current Version State │
│ │ Edge-swipe & tap to reask │ │              │ • [ Check for Updates ] │
│ └───────────────────────────┘ │              │   GitHub API Release    │
│ • History list items...       │              │   Direct APK Download   │
└───────────────────────────────┘              └─────────────────────────┘
```

---

## 2. Root Cause Analysis: WebActivity Cold-Start Crash & Fix Strategy

### Root Causes Identified
1. **Uncaught Chromium Render Process Termination**:
   On cold process launch or when device memory is constrained (especially when loading heavyweight Single Page Apps like `gemini.google.com`), Android's underlying Chromium engine can drop its render process. In Android 8.0+ (API 26+), if a `WebViewClient` does not implement `onRenderProcessGone(view, detail)` and return `true`, Android terminates the entire host application immediately.
2. **Concurrent `WebSettings` Mutation During `onPageStarted`**:
   `applyWebsiteTheme()` was invoking `webView.settings.forceDark = ...` and `webView.settings.isAlgorithmicDarkeningAllowed = ...` synchronously inside `onPageStarted()`. Dynamic modification of dark mode flags while Chromium is actively preparing a navigation pipeline can trigger native C++ assertion crashes in OEM WebViews (e.g., ColorOS / OxygenOS / HyperOS).
3. **Unguarded `onCreate` Lifecycle**:
   Unlike `SettingsActivity` which possesses a defensive fallback UI, `WebActivity.onCreate` had zero top-level exception handling. Any transient `WebViewFactory$MissingWebViewPackageException` or provider initialization glitch resulted in an unhandled crash.
4. **Main-Thread Image Decoding & Base64 Payload Overhead**:
   If launched with circled screenshots or staged images, uncompressed bitmap decoding without `OutOfMemoryError` guards could exhaust memory before the web view finished initialization.

### Comprehensive Fix Plan
- **Implement `onRenderProcessGone`**: Provide a resilient recovery mechanism in `WebViewClient` that recreates the WebView or reloads gracefully instead of terminating the app process.
- **Isolate WebSettings Configuration**: Set dark mode flags once during initial `setupWebView()`. Ensure `applyWebsiteTheme()` uses only DOM JavaScript mutation and CSS color-scheme tags rather than re-touching native `WebSettings` during active page transitions.
- **Safe Lifecycle Fallback**: Wrap `WebActivity.onCreate` with a protective try-catch that gracefully catches initialization errors and provides a restart/recovery banner.
- **Safe Image Processing**: Wrap bitmap decoding and base64 string injection with strict memory guards and fallback error logging.

---

## 3. Settings Navigation Redesign & About / Update Manager

### A. Settings Top Bar Restructuring
- **Left Button (`ic_menu`)**: 
  - Positioned at the far left of the row.
  - Retains the 38dp rounded button styling (`theme.SURFACE_HI`).
  - Launches the Complete AI Query History dialog.
- **Center Column**:
  - Contains "OpenAssist" title and subtitle "AI Voice Assistant & Circle-to-Search".
  - Houses the version badge displaying current version (`v1.61.0`).
  - The version badge is wrapped in a clickable pill that triggers the About & Update Manager dialog.
- **Right Button (`ic_about` / `ic_help`)**:
  - Replaces the former position of the hamburger menu.
  - Uses an aesthetic question mark inside circle vector drawable (`ic_about.xml`).
  - Opens the About & Update Manager dialog.

### B. About & Update Manager Dialog
- **Header**:
  - Mascot avatar icon with companion greeting.
  - "OpenAssist" name and active version badge.
- **Repository & Project Information**:
  - Clean overview derived from the project README (features, Circle to Search, Whisper offline recognition, zero telemetry, 100% open-source).
  - Public repository link: `https://github.com/Cellate/OpenAssist` (explicitly zero mention of private dev repos).
- **Live Update Checker**:
  - "Check for Updates" button that queries `https://api.github.com/repos/Cellate/OpenAssist/releases/latest` on a background thread.
  - Displays status: "Checking...", "You are on the latest version!", or "Update Available: v1.x.x".
  - If a newer release is found, displays release notes and a direct button: "Download APK (v1.x.x)".
  - Includes a link to view full release notes on GitHub.

### C. Complete AI Query History Tooltip Banner
- In `showFullHistoryDialog()`, add an informative banner card directly beneath the title:
  - Background: `theme.SURFACE_HI` with subtle accent border.
  - Icon: `ic_sparkle` or lightbulb.
  - Message: *"💡 Quick Tip: You can open this history anytime by swiping right from the left edge of the screen in Settings. Tap any past query to re-open and ask your active assistant!"*
  - Clean dismiss / close action or permanent compact helper layout.

---

## 4. Pipeline Synchronization & Invariants (AI_INSTRUCTIONS.txt)

- **Version Bumping**: Increment iteration to **`v1.61.0`** (Iteration 61, Minor 0) in strict synchronization across:
  - `AI_INSTRUCTIONS.txt` (New release record & preference logs)
  - `app/build.gradle.kts` (`versionCode = 62`, `versionName = "1.61.0"`)
  - `.github/workflows/main.yml` (Artifact: `OpenAssist_v.1.61.0`, File: `OpenAssist_v.1.61.0.apk`)
  - `scripts/build_source_zip.js` (`OpenAssist_v.1.61.0.zip`)
  - `TRANSFER_INSTRUCTIONS.md`
  - React Web Companion (`App.tsx`, `ReadmeViewer.tsx`, `PhoneSimulator.tsx`, `DownloadSection.tsx`)
  - Android native UI strings and headers
- **ZIP Packaging**: Re-generate `OpenAssist_v.1.61.0.zip` and `OpenAssist-Full-Project.zip` via `node scripts/build_source_zip.js`.
- **Zero AndroidX Compliance**: All new UI components remain 100% pure standard Android SDK with `Ui.kt` helpers.

---

## 5. Verification & Testing Protocol

1. **Compilation Check**: Run `compile_applet` to ensure both Android project and React web companion build without errors.
2. **Lint & XML Validation**: Validate all XML layouts and drawables (`ic_about.xml`, `activity_web.xml`) for correct attributes and escaped strings.
3. **Simulator & Web Companion Check**: Verify that the web phone simulator reflects the new Settings layout and About dialog.
4. **Source Archive Generation**: Run `node scripts/build_source_zip.js` to create the updated package archives.
