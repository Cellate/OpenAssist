# High-Converting Public Showcase & Unified APK Distribution Plan

A unified, high-converting public landing experience and release packaging architecture for OpenAssist (`github.com/cellate/openassist`). Designed so that everyday Android users on standard mobile data instantly understand the value of sovereign Circle to Search, feel completely confident in its safety, and download the lightweight ~5.6MB APK in seconds.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following requirements have been confirmed through Phase 1 interactive clarification and will govern the build:

- **Confirmed Decision 1 (Public Layout)**: The public website will be a single unified, distraction-free landing page combining the Hero Showcase, an embedded Live Phone Sandbox, and the APK Download Hub in one flowing conversion funnel. Internal developer utilities (Brand Studio, Placement Lab, Code Explorer) are tucked into an unobtrusive Developer Mode toggle to keep public visitors 100% focused on converting.
- **Confirmed Decision 2 (Distribution Packaging)**: `OpenAssist_v.1.65.0.zip` will package both the complete Android APK source for GitHub Actions CI compilation AND the static public web landing bundle, allowing one-step deployment to `github.com/cellate/openassist` and GitHub Pages.
- **Confirmed Decision 3 (Everyday User Conversion Badges)**:
  - **Ultra-lightweight ~5.6MB APK**: Emphasize minimal data usage (Jio/Airtel friendly, downloads in under 3 seconds).
  - **Universal Android 10+ Compatibility**: Works on any phone (Redmi, Realme, Samsung, Vivo, Oppo, OnePlus, Pixel) with zero root and no Google Play Services dependency.
  - **Relatable 3-Step Setup**: Visual, jargon-free guide (Download APK → Set as Default Assistant in Settings → Long-press Home or swipe corner to Circle-to-Search).
  - **100% Free & Zero Telemetry**: Explain in plain language that no photos, voice, or private data ever leave the phone.

---

### 1. Overview & Core Concept

- **What It Delivers**: Transforms the public face of OpenAssist into a compelling, consumer-grade product page that makes flagship AI and Circle to Search accessible to anyone with an Android 10+ phone.
- **Target Audience / Persona**: Everyday smartphone users (including college students and professionals in India and globally using 4G/5G prepaid data) looking for Circle to Search and Voice AI without paying for flagship hardware or sacrificing personal privacy.
- **Key Value**:
  - Circle to search anything on screen with a single finger gesture.
  - Offline voice dictation powered by Whisper that works in airplane mode.
  - Zero surveillance, zero ads, and zero account requirements.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Hero Arrival**: Instant hook explaining Circle to Search on any Android phone, high-impact "Download APK (5.6 MB)" button with latest release link, verified SHA-256 badge, and mascot companion welcome.
2. **Interactive Live Phone Sandbox**: Visitors can test Circle to Search right inside their desktop or mobile browser—drawing a lasso, picking an AI engine (Gemini, Claude, local Ollama), and listening to authentic mascot acoustic feedback.
3. **Mascot Companion Showcase**: Interactive carousel featuring all 12 companion personalities (Ozzy, Pip, Echo, Nova, Pico, Taro, Byte, Lumi, Kiko, Ollie, Iris, Moby) with distinctive audio chirps.
4. **Objection Handling & Trust Badges**: Plain-English comparison matrix comparing OpenAssist to generic cloud assistants (Offline dictation, works on custom ROMs, zero tracking).
5. **3-Step Activation Walkthrough**: Crystal-clear visual steps showing Android Settings navigation and gesture triggering.
6. **Download & Build Hub**: Direct APK download button linking to GitHub Releases, sideload command for developers, and build-from-source instructions.
7. **Developer Mode Switch**: A clean footer / header toggle allowing developers to access the full Brand Studio, Mascot Placement Lab, and Code Explorer without distracting normal visitors.

#### Visual Identity & Theme
- **Canvas Palette**: Deep obsidian `#020617` and slate `#0F172A` neutral canvas with subtle hairline borders (`border-slate-800`), eliminating generic purple AI slop.
- **Accent Hierarchy**: High-visibility Emerald `#10B981` / Teal `#14B8A6` for primary download actions; Indigo `#6366F1` for interactive simulator elements.
- **Typography**: Clean display headline hierarchy with `Plus Jakarta Sans` / `Outfit`, balanced with readable body prose (`text-slate-300`, `leading-relaxed`), and tabular figures (`tabular-nums`) for file sizes and benchmarks.
- **Zero-Pill Discipline**: Metadata displayed as clean, unboxed text separated by typographic middots (`·`).

---

### 3. Key Product Decisions & Trade-Offs

#### Decision 1: Single Unified Landing Funnel vs. Multi-Tab Navigation
- **Chosen Approach**: A single, seamless scrolling page containing the Hero, Live Phone Sandbox, Companion Showcase, Setup Guide, and APK Download Hub. Developer tools (Brand Studio, Placement Lab, Code Explorer) are moved behind an explicit "Developer Tools" toggle.
- **Why**: Eliminates analysis paralysis for public visitors. An average user arriving from GitHub or social media sees exactly what the app does, tries it immediately, and downloads it in one fluid motion.
- **Alternatives Considered**: Keeping all 7 tabs visible in the main header was found to overwhelm casual mobile users with developer-oriented configuration tools.

#### Decision 2: Dual Packaging in `OpenAssist_v.1.65.0.zip`
- **Chosen Approach**: `scripts/build_source_zip.js` will package the complete Android source files (`app/`, `assets/`, `gradle/`, `build.gradle.kts`, `settings.gradle.kts`, `.github/workflows/main.yml`) alongside the compiled static web showcase (`dist/` or static single-page bundle) and README documentation.
- **Why**: Allows the user to extract the zip directly into their public GitHub repository (`github.com/cellate/openassist`) to simultaneously enable GitHub Actions APK compilation and GitHub Pages web deployment.

#### Decision 3: Consumer-Friendly Language & India Mobile Data Localization
- **Chosen Approach**: Emphasize "~5.6 MB APK size", "Works on Jio, Airtel, and all 4G/5G networks", "Zero root required", and "Works on Redmi, Samsung, Realme, OnePlus, Vivo, Pixel".
- **Why**: Directly addresses common concerns of mobile users regarding data quotas, phone compatibility, and malware fears, driving maximum download conversion.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                   PUBLIC GITHUB PAGES WEB SHOWCASE                     │
├────────────────────────────────────────────────────────────────────────┤
│  ┌───────────────────────┐  ┌──────────────────────────────────────┐  │
│  │     Hero Showcase     │  │     Embedded Live Phone Sandbox      │  │
│  │  • Value Prop         │  │  • On-Screen Circle to Search        │  │
│  │  • 5.6 MB Data Badge  │  │  • Multi-AI Switcher (Gemini/Claude) │  │
│  │  • 1-Click APK Button │  │  • Interactive Mascot Chirps         │  │
│  └───────────┬───────────┘  └──────────────────┬───────────────────┘  │
│              │                                 │                      │
│  ┌───────────┴─────────────────────────────────┴───────────────────┐  │
│  │              Interactive Mascot Companion Showcase              │  │
│  │  • Ozzy, Pip, Echo, Nova, Pico, Taro, Byte, Lumi, Kiko, Ollie   │  │
│  └─────────────────────────────────┬───────────────────────────────┘  │
│                                    │                                  │
│  ┌─────────────────────────────────┴───────────────────────────────┐  │
│  │            3-Step Visual Setup & Trust Verification             │  │
│  │  • Step 1: Install APK (~5.6 MB, Direct Link)                   │  │
│  │  • Step 2: Set as Default Digital Assistant in Android Settings │  │
│  │  • Step 3: Long-press Home / Corner Swipe to Circle to Search   │  │
│  │  • SHA-256 Checksum & 100% Zero-Telemetry Verification          │  │
│  └─────────────────────────────────┬───────────────────────────────┘  │
│                                    │                                  │
│  ┌─────────────────────────────────┴───────────────────────────────┐  │
│  │             Unified Direct APK Download & Release Hub           │  │
│  │  • Points directly to github.com/Cellate/OpenAssist/releases    │  │
│  │  • Developer ADB Quick-Sideload Terminal Command                │  │
│  └─────────────────────────────────┬───────────────────────────────┘  │
│                                    │                                  │
│  ┌─────────────────────────────────┴───────────────────────────────┐  │
│  │                 Developer Lab Drawer (Hidden by default)        │  │
│  │  • Brand Studio  • Placement Lab  • Code Explorer  • Full Zips │  │
│  └─────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
```

#### Key Implementation Steps
1. **Refactor `src/App.tsx`**:
   - Provide a clean, unified public layout defaulting to the seamless Hero + Sandbox + Mascot Showcase + Setup Guide + Download Hub.
   - Include a discreet "Developer Lab" toggle button for accessing Brand Studio, Placement Lab, and Code Explorer.
2. **Enhance `LandingHeroShowcase.tsx`**:
   - Update file size copy to **~5.6 MB (5.6 MB to be exact)** instead of 18 MB.
   - Add explicit compatibility callouts for popular devices (Samsung, Redmi, Realme, OnePlus, Vivo, Oppo, Pixel) and mobile data friendliness.
   - Embed the live interactive phone simulation directly into the showcase narrative.
3. **Synchronize `version.json` and `assets/version.json`**:
   - Update version metadata notes to reflect the 5.6MB lightweight APK size.
4. **Update `scripts/build_source_zip.js`**:
   - Ensure `OpenAssist_v.1.65.0.zip` contains both the pure Android build assets and public web files needed for GitHub deployment.
5. **Verification**:
   - Run `node scripts/build_source_zip.js`.
   - Run `compile_applet` and `lint_applet` to verify clean compilation.
