# Instant One-Click In-App APK Updater & Unified Version Synchronization

A streamlined in-app update experience replacing external browser redirects with direct background APK downloads, real-time progress indicators, automatic package installer triggers, an install-ready fallback action banner, and a single source of truth version configuration (`assets/version.json`) that unifies Android and Companion applications.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and user experience decisions were confirmed during the planning clarification phase:

- **Confirmed Decision 1 (In-App Download & Installation)**: The updater will download APK assets directly within the app displaying a determinate progress bar (0–100% with byte counters). Upon completion, it automatically triggers the native Android `PackageInstaller` (`ACTION_VIEW` or `ACTION_INSTALL_PACKAGE` with `FileProvider` URI). If automatic launch encounters restrictions or is dismissed, a persistent "Install Now" action banner remains visible along with a system notification that the update has downloaded and is ready to install.
- **Confirmed Decision 2 (Single Source of Truth Versioning)**: `assets/version.json` will serve as the canonical single source of truth for version number, iteration, and release metadata. Because `assets/` is packaged directly into both the Android pure source ZIP (`OpenAssist_v.1.64.0.zip`) and the companion web app, it ensures 100% synchronization across GitHub releases, the Android runtime, and the web companion without manual code edits across 8+ scattered files.
- **Confirmed Decision 3 (GitHub Release Tag Normalization)**: Version comparison normalizes both local and remote strings by stripping `v`, `v.`, leading dots, and whitespace, then parses semantic integer components (`major`, `iteration`, `bugfix`). If the remote release is less than or equal to the installed version, the app confidently reports "✅ OpenAssist is up to date!" and suppresses update prompts.

---

## 1. Overview & Core Concept

### What It Does
- **One-Click In-App Downloads**: Replaces the frustrating workflow of kicking users out to an external web browser, hunting for the file in the browser's download manager, and manually executing it. Tapping "Update Now" downloads the APK directly to the app's cache directory with a live progress bar.
- **Seamless Package Installation & Fallback**: Automatically invokes Android's package installer upon download completion. If background installation is restricted (e.g., unknown sources permission required), an in-app banner with an "Install Now" button and a system notification provide instantaneous 1-tap installation.
- **Unified Single Source of Truth (`assets/version.json`)**: Consolidates all version displays (Settings top bar, About & Updates card, Setup Wizard modal, Web Companion simulator, and Download Section) to read from a single canonical JSON file packaged in the Android assets folder and shared across the repository.
- **Accurate Tag & Release Comparison**: Accurately parses GitHub release tags (such as `v.1.64.0`, `v1.64.0`, `1.64.0`) against the active version components, eliminating false "Update Available" badges when the user is already on the latest build.

### Target Audience & Persona
- **OpenAssist Users**: Expect an effortless, Google Play-like seamless update flow without having to navigate external browser file trees.
- **Repository Maintainers & Developers**: Can release new versions simply by updating `assets/version.json` and pushing tags to `Cellate/OpenAssist`, knowing all UI surfaces, scripts, and Android binaries will stay in lockstep.

### Key Value
Eliminates manual file handling for updates, cuts update friction from 6 steps down to 1 click, and guarantees version integrity across the entire dual-target ecosystem.

---

## 2. User Experience & Visual Design

### Key User Flows

#### Flow A: Checking for Updates
1. User opens Settings in OpenAssist and scrolls to the **App Updates & Releases** card (or taps the version badge in the top bar).
2. The card immediately displays the installed version dynamically resolved from `assets/version.json` (e.g., `Installed version: v1.64.0`).
3. User taps **"Check for Updates"**.
4. The system queries `https://api.github.com/repos/Cellate/OpenAssist/releases/latest`, strips prefixes, and compares semantic numbers.
5. If up-to-date, a calm emerald badge displays: `✅ OpenAssist is up to date! (v1.64.0)`.
6. If a newer build is released, a vibrant card reveals release notes, APK file size, and a prominent **"Download & Update (v1.65.0)"** button.

#### Flow B: One-Click Download & Automatic Install
1. Tapping **"Download & Update"** transforms the action row into an active progress container:
   - Determinate progress bar showing percent (`45%`) and downloaded size (`14.2 MB / 31.5 MB`).
   - Subtle pulse animation with an immediate "Cancel" option.
2. The APK streams securely to `context.cacheDir/updates/OpenAssist_latest.apk`.
3. When 100% is reached:
   - The native Android installer intent is automatically fired via `FileProvider`.
   - A system notification ("OpenAssist Update Ready: Tap to install v1.65.0") is posted.
   - An in-app floating banner appears: **"Download Complete! [Install Now]"** if the user returns to the app before finishing installation.

#### Flow C: Companion Simulator Synchronization
1. In the Web Companion simulator (`PhoneSimulator.tsx`) and Download Section (`DownloadSection.tsx`), all top and bottom version tags pull directly from `version.json`.
2. Simulating an update check uses the exact same semantic comparison logic, demonstrating the live progress bar and install banner.

### Visual Identity & Theme
- **Theme posturing**: Seamless adherence to OpenAssist's Dark Slate (`#0F172A` / `#1E293B`) and Light Canvas (`#F8FAFC` / `#FFFFFF`).
- **Progress Bar**: Sleek 6px rounded progress track with a smooth emerald/cyan gradient fill (`#10B981` to `#06B6D4`).
- **Action Buttons**: 48px minimum touch height with high-contrast font weight, clear icons, and tactile press states.
- **Zero-Pill Metadata**: Version strings and dates rendered as clean unboxed text with typographic separators (`v1.64.0 · 31.5 MB · Released Today`).

---

## 3. Key Product Decisions & Trade-Offs

### Decision 1: Direct In-App Streaming vs. System DownloadManager
- **Chosen Approach**: Stream the APK via Kotlin `HttpURLConnection` / coroutine background thread directly into internal cache storage, driving a live in-app progress bar, followed by `FileProvider` package installation.
- **Why**: Android's system `DownloadManager` frequently gets blocked by OEM battery managers, lacks granular in-app UI callbacks, requires redundant external storage permissions, and leaves files scattered in public Downloads. In-app streaming gives 100% UI control, instant feedback, and zero leftover junk.
- **Fallback**: If package install intent fails or permission `REQUEST_INSTALL_PACKAGES` is pending, OpenAssist guides the user to the app settings or provides an immediate "Install Now" action button.

### Decision 2: Location of Canonical Version Specification
- **Chosen Approach**: `assets/version.json` at repository root, packaged directly into `assets/` in `OpenAssist_v.1.64.0.zip` and linked into Android `assets.srcDirs`.
- **Why**: The user specifically requested a location that is included in the pure Android build ZIP and copied over to `Cellate/OpenAssist`. Placing `version.json` inside `assets/` ensures it is bundled identically to mascot SVGs, accessible at runtime via `context.assets.open("version.json")` in Android and imported in TypeScript for web views.

### Decision 3: Semantic Version Comparison Algorithm
- **Chosen Approach**: Split version strings into integer arrays `[major, iteration, bugfix]` after stripping any `v`, `v.`, or release labels. Compare element-by-element (`remote[0] > local[0]`, then `remote[1] > local[1]`, then `remote[2] > local[2]`).
- **Why**: String equality checks like `releaseTag != currentVer` failed whenever tags used `v.1.63.0` while current version was `v1.63.0` or `1.63.0`, causing the app to erroneously claim an update was available even when identical or ahead.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        assets/version.json                             │
│       { "version": "1.64.0", "major": 1, "iteration": 64, ... }        │
└───────────────────┬────────────────────────────────┬───────────────────┘
                    │                                │
                    ▼                                ▼
       ┌────────────────────────┐       ┌────────────────────────┐
       │   Android Native App   │       │  React Web Companion   │
       │   (OpenAssist APK)     │       │     (Vite + React)     │
       └────────────┬───────────┘       └────────────┬───────────┘
                    │                                │
    ┌───────────────┴───────────────┐                │
    ▼                               ▼                ▼
┌────────────────────────┐ ┌────────────────┐ ┌────────────────────────┐
│   AppVersion.kt        │ │ SettingsActivity│ │ DownloadSection.tsx   │
│ - Reads assets/version │ │ - Progress Bar │ │ PhoneSimulator.tsx     │
│ - Semantic Tag Parser  │ │ - Auto-Install │ │ SetupWizardModal.tsx   │
│ - Clean Prefix Normal  │ │ - Fallback CTA │ │ - Unified version      │
└────────────────────────┘ └────────────────┘ └────────────────────────┘
                    │
                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│               GitHub API: repos/Cellate/OpenAssist/releases            │
│         Compare release.tag_name vs AppVersion.current()               │
└────────────────────────────────────────────────────────────────────────┘
```

### Core Implementation Modules

1. **`assets/version.json`**:
   - Contains version code, iteration number, semantic version string, display name, and release notes title.

2. **Android Native (`AppVersion.kt` & `SettingsActivity.kt`)**:
   - `AppVersion.kt`: Central utility that reads `assets/version.json` (with fallback to BuildConfig), provides `getFormattedVersion()`, and implements `isRemoteNewer(remoteTag, localVersion)`.
   - `SettingsActivity.kt`:
     - Dynamic version rendering across top bar badge and About card.
     - GitHub release fetching and asset parsing.
     - Background HTTP stream download with progress listener (`onProgress(bytesRead, totalBytes, percent)`).
     - Automated `ACTION_VIEW` intent with `application/vnd.android.package-archive` via `FileProvider`.
     - In-app "Install Now" banner and system notification on completion.

3. **Android Build Configuration (`app/build.gradle.kts` & `scripts/build_source_zip.js`)**:
   - Configure `sourceSets { getByName("main") { assets.srcDirs("../assets") } }` in Gradle.
   - Update `build_source_zip.js` to ensure `assets/version.json` is packaged in `OpenAssist_v.1.64.0.zip`.
   - Bump version to `v1.64.0` across `.github/workflows/main.yml`, `AI_INSTRUCTIONS.txt`, and export archives.

4. **Web Companion & Simulator (`PhoneSimulator.tsx`, `SetupWizardModal.tsx`, `DownloadSection.tsx`, `App.tsx`)**:
   - Import `version.json` dynamically.
   - Synchronize all simulator version displays, update check simulations, and zip download buttons.
   - Add simulated in-app download progress bar and "Install Now" action banner to the simulator's About & Updates dialog.
