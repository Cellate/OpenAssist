# OpenAssist v1.58.0: Adaptive Mascot Chip, Whisper Model Management & Community Translation System

A comprehensive upgrade to OpenAssist (Android native APK + Web companion) delivering adaptive UI borders, Whisper model deletion and dynamic per-language binding, an extensible community text-based translation system with in-app UI editors, expanded per-mascot dialogue management, and an adaptive floating speech bubble pill in the overlay.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> **Summary of Design Decisions**:
> 1. **Extensible Translation Format**: A clean, human-readable plain text format matching your exact specification:
>    ```text
>    # OpenAssist Translation File
>    # Line 1: English source string
>    # Line 2: Translated string (leave empty to fallback to English)
>    # Line 3: Empty separator line
>    
>    Digital assistant
>    डिजिटल सहायक
>    
>    Local Offline Whisper Models
>    लोकल ऑफलाइन व्हिस्पर मॉडल्स
>    ```
> 2. **Per-Menu & Mascot Language Routing**: Users can configure an App Default Language, plus individual overrides for Settings, Overlay, Web UI, and Mascot Dialogue.
> 3. **In-App Quick Editor**: A native modal UI to quickly edit translations and mascot phrases directly on the phone without manual file uploading.
> 4. **Adaptive Speech Bubble Pill**: Replacing the cramped top banner in `OverlayActivity` with a floating, adaptive rounded pill with themed borders matching the web simulator.
> 5. **Token Efficiency & 15-Minute Budget**: Reusable, lightweight architecture without adding heavy external dependencies, preserving existing Gradle and NDK setups.

---

### 1. Overview & Core Concept

OpenAssist v1.58.0 addresses key usability and extensibility requests across the Android native app and the web companion:
- **Adaptive Mascot Chip**: Eliminates tight border clipping on the Web Assistant top bar by applying dynamic auto-sizing layout parameters and protective horizontal padding.
- **Whisper Model Deletion & Re-binding**: Adds one-tap deletion for imported `.bin` models (with confirmation) and an interactive model picker for every configured language.
- **Dynamic Language Bindings**: Allows adding new custom languages and removing existing ones, binding each to any active or imported Whisper model.
- **Community Translation Extension Engine**: Enables exporting a template text file, translating it with any AI or human translator, importing it back into the app, or editing phrases in real-time via an in-app visual editor.
- **Mascot Speech Expansion & Translation**: Allows users to customize what all mascots say generally, as well as mascot-specific dialogue for Ozzy, Pip, Echo, etc., in multiple languages.
- **Adaptive Floating Speech Bubble Pill**: Porting the sleek floating dialogue bubble from the web companion to the native Android overlay.

---

### 2. User Experience & Visual Design

#### A. Web Assistant Top Bar (Fixed Mascot Chip)
- Dynamic `wrap_content` horizontal pill with `10dp` inner padding (`Ui.dp(context, 10)`), 4dp margin, and auto-adjusted bounds.
- When mascot changes (e.g., from Ozzy to Pip or custom names), the pill animates and adapts its width smoothly without text touching the border.

#### B. Whisper Models & Language Binding Card
- **Model Row**:
  - Displays model name and size in MB.
  - Action buttons: `[ACTIVE]` (blue pill), `[SELECT]` (gray button), and `[REMOVE ✕]` (red/muted button with confirmation dialog for non-active models).
- **Per-Language Binding**:
  - Tapping a language row opens a bottom sheet / themed dialog with radio options for all imported models.
  - Includes a `[+ Add Language]` button (enter language name + code) and a delete icon on custom/secondary languages.

#### C. Language Switcher & Community Translation Hub
- Located under a dedicated **"Language & Community Translations"** card in Settings:
  - **App Default Language**: Dropdown / picker (English, Hinglish, Hindi, Spanish, + imported extensions).
  - **Menu Specific Overrides**:
    - Settings Menu Language: Default or specific pack.
    - Overlay Menu Language: Default or specific pack.
    - Web Assistant Language: Default or specific pack.
    - Mascot Dialogue Language: Default or specific pack.
  - **Translation Extension Manager**:
    - `[Export Translation Template (.txt)]`: Generates the exact line-by-line format with prefilled UI strings and blank translation lines.
    - `[Import Translation (.txt)]`: Imports custom translated files into local app storage.
    - `[In-App Translation Editor]`: Opens a search-and-edit list of all UI strings with inline translation fields and instant save.

#### D. Mascot Phrase Studio & In-App Dialogue Editor
- Interactive tab/dialog allowing users to:
  - Select target: **All Mascots (General)** or a specific mascot (Ozzy, Pip, Echo, Kiko, etc.).
  - View current wholesome phrases.
  - Add new phrases, delete existing ones, and provide multi-language translations.

#### E. Overlay Adaptive Speech Bubble Pill
- Replaces the plain top black strip with a floating pill:
  - Soft rounded corners (`20dp`), themed dark/light surface background (`#1E293B` or `#FFFFFF`), subtle hairline border (`#334155`), and inner padding (`12dp` horizontal, `6dp` vertical).
  - Centered below the top controls or anchor-aligned with the mascot chip, rendering clear text that never clips.

---

### 3. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        OpenAssist Application                          │
├────────────────────────────────┬───────────────────────────────────────┤
│          Android Native App    │            Web Companion              │
│  (Kotlin + JNI + XML Layouts)  │         (React + Vite + TS)           │
├────────────────────────────────┴───────────────────────────────────────┤
│                     Language & Translation Core                        │
│  ┌──────────────────────────────┐    ┌──────────────────────────────┐  │
│  │   TranslationStore / Prefs   │    │    MascotDialogueStore       │  │
│  │  - App Default Language      │    │  - General Mascot Phrases    │  │
│  │  - Per-Menu Overrides        │    │  - Per-Mascot Custom Phrases │  │
│  │  - Line-by-Line File Parser  │    │  - Translated Dialogue Map   │  │
│  │  - In-App String Overrides   │    │  - Speech Bubble Formatter   │  │
│  └──────────────────────────────┘    └──────────────────────────────┘  │
├────────────────────────────────────────────────────────────────────────┤
│                           UI Layer Upgrades                            │
│  ┌───────────────────────┐  ┌────────────────────┐  ┌────────────────┐ │
│  │ WebActivity Top Bar   │  │ SettingsActivity   │  │ OverlayActivity│ │
│  │ - Adaptive Chip Width │  │ - Model Delete Btn │  │ - Floating     │ │
│  │ - Re-applied Paddings │  │ - Lang-Model Bind  │  │   Speech Pill  │ │
│  │ - Safe Bounds         │  │ - Trans. Hub & Ed. │  │   (Web-like)   │ │
│  └───────────────────────┘  └────────────────────┘  └────────────────┘ │
└────────────────────────────────────────────────────────────────────────┘
```

#### Core Components to Create & Update:

1. **`TranslationStore.kt`**:
   - Manages language packs (English default, Hinglish preloaded, plus custom imported packs).
   - Line-by-line parser and serializer matching user specification.
   - Methods: `exportTemplate()`, `importFile(text)`, `getTranslation(key, menuContext)`, `saveOverride(key, translated)`.

2. **`MascotDialogueStore.kt`**:
   - Stores and retrieves wholesome greetings and reaction phrases per mascot and globally.
   - Allows users to add, edit, and delete phrases, with multi-language lookup based on active mascot dialogue language.

3. **`ModelStore.kt`**:
   - Dynamic per-language binding: `getBoundModelId(langCode)`, `setBoundModelId(langCode, modelId)`.
   - Supports custom language additions and removals: `addLanguage(code, name)`, `removeLanguage(code)`.
   - File deletion for removed `.bin` files to free device storage.

4. **`WebActivity.kt` & `activity_web.xml`**:
   - Fixes `btn_web_mascot_chip` to dynamically recalculate padding after background drawables are applied, preventing text clipping.
   - Connects menu items and labels to `TranslationStore`.

5. **`SettingsActivity.kt`**:
   - Adds "Remove Model" button with confirmation alert.
   - Interactive dialog on language rows to pick a Whisper model.
   - Adds `+ Add Language` and `Delete Language` buttons.
   - Adds the new **Language & Community Translation Hub** and **Mascot Speech Editor** dialogs.

6. **`OverlayActivity.kt` & `Ui.kt`**:
   - Upgrades `showSpeechBubble` to render a modern floating pill layout matching the web demo (`Ui.pill` with subtle border and adaptive text padding).

7. **`scripts/build_source_zip.js` & `AI_INSTRUCTIONS.txt`**:
   - Increment version to `v1.58.0` (Iteration 58, Bugfix 0).
   - Log all user directives in Section 4 of `AI_INSTRUCTIONS.txt`.
   - Re-run zip build to package the new Android and full-project zips.

---

### 4. Verification & Testing Plan

1. **Codebase Validation**:
   - Run Python XML validation on all Android layouts and drawables.
   - Verify no unescaped single quotes in `strings.xml`.
2. **Web Companion Build**:
   - Run `compile_applet` to ensure full Vite/TypeScript compilation succeeds.
3. **ZIP Generation**:
   - Execute `node scripts/build_source_zip.js` and verify `OpenAssist_v.1.58.0.zip` and `OpenAssist-Full-Project.zip` are successfully generated in `public/`.
