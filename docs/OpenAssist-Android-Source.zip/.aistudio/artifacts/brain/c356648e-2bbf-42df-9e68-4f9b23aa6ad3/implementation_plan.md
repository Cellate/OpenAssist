# Auto-Read Aloud Chatbot Responses with Minimizable Audio Controller

A seamless, intelligent voice readout system for OpenAssist that automatically speaks chatbot answers aloud as soon as generation finishes—just like the native Gemini and ChatGPT apps. Features a hybrid engine that triggers website native high-fidelity audio buttons with instant on-device Android Text-To-Speech (TTS) fallback, paired with a minimizable floating audio controller.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following design and behavioral choices were confirmed during Phase 1 clarification:
> - **Hybrid Speech Execution**: Priority is given to triggering the chatbot's built-in web audio (e.g. Gemini's "Listen" or ChatGPT's "Read aloud" button). If a service lacks native audio or fails to start, OpenAssist automatically falls back to on-device Android `TextToSpeech`.
> - **Default Posture**: Auto-speak is **enabled by default** with an immediate 1-tap quick mute toggle in the top bar and a preference in Settings.
> - **Floating Audio Bar**: Includes Play/Pause, Stop, and Speed controls (1.0x, 1.25x, 1.5x), with an instant **Minimize / Hide** button to prevent visual distraction when users are reading, copying, or composing responses.

---

## 1. Overview & Core Concept

When users submit queries via OpenAssist (Circle to Search, voice dictation, or quick text), they expect hands-free conversational continuity:
1. The AI chatbot (Gemini, ChatGPT, Claude, Perplexity, DeepSeek, etc.) streams its answer in `WebActivity`.
2. A lightweight DOM completion observer detects when generation finishes.
3. OpenAssist automatically initiates audio playback so the user can listen without manually hunting for small speaker buttons.
4. A sleek, floating audio controller appears with play/pause, stop, and speed toggles, but can be minimized into an edge badge or hidden completely at any time.

---

## 2. User Experience & Visual Design

### User Flows & Interactions
1. **Query Submission & Streaming**:
   - The user triggers Circle to Search or voice query.
   - The query enters `WebActivity`. The top bar displays an active **Auto-Speak** indicator (Speaker icon, active by default).
   - A DOM observer monitors message generation.
2. **Auto-Trigger on Completion**:
   - As soon as the AI completes its response (stop-button disappears and DOM mutates to final state):
     - **Attempt 1 (Native Web Audio)**: Locates and clicks the service's native "Listen / Read Aloud" button (`button[aria-label*="Listen" i]`, `[aria-label*="Read aloud" i]`, etc.).
     - **Attempt 2 (Android TTS Fallback)**: If no native audio button is found after 1.2s, the bridge extracts the latest assistant text and speaks via Android `TextToSpeech` (or Web Speech API in the simulator).
3. **Floating Audio Controller**:
   - Placed in the ergonomic Natural Reach zone (bottom right / bottom center) above the system navigation bar.
   - **Controls**:
     - **Play / Pause**: Toggle speech playback.
     - **Stop**: Immediately halts speech and dismisses/resets player.
     - **Speed**: Cycles between `1.0x` -> `1.25x` -> `1.5x` -> `0.8x`.
     - **Minimize / Hide Button**: Collapses the bar into a discreet, 36px floating mascot orb or edge tab (`chevron-down` or `minimize`), freeing up 100% of the screen for reading or note-taking.
4. **Settings & Quick Mute**:
   - **Top Bar**: Tapping the speaker icon instantly toggles Auto-Speak ON/OFF for the current session.
   - **SettingsActivity & SetupWizard**: Master toggle for "Auto-Read Aloud Responses", default speech rate slider, and fallback voice selection.

### Aesthetic Direction & Ergonomics (Mobile Touch Discipline)
- **Geometry & Depth**: Floating pill with `rounded-2xl` surface, subtle shadow, and hairline border (`border border-slate-700/50 bg-slate-900/90 backdrop-blur-md`).
- **Touch Target Compliance**: All buttons (`Play`, `Stop`, `Speed`, `Minimize`) maintain $\ge 44 \times 44\text{px}$ touch target bounds.
- **Surface Elevation**: Pinned cleanly above the web content without obscuring input fields or text. When minimized, collapses to a quiet edge badge taking $< 5\%$ of viewport width.

---

## 3. Key Product Decisions & Trade-Offs

| Decision | Chosen Approach | Rationale & Trade-offs |
| :--- | :--- | :--- |
| **Speech Generation Engine** | **Hybrid (Native Web Audio + On-Device Android TTS)** | Native web audio sounds most natural for Gemini/ChatGPT; Android TTS ensures 100% reliability for Claude, DeepSeek, and custom LLMs without network latency. |
| **Response Completion Detection** | **DOM MutationObserver + Streaming Inactivity Debounce (1.2s)** | Chatbots stream tokens dynamically without standardized webhooks. Monitoring stop-button lifecycle and token stabilization provides robust completion triggers across all major AI interfaces. |
| **Audio Bar Minimization** | **Dual State: Expanded Floating Pill & Collapsed Edge Orb** | Prevents UI distraction when users want to read tables, copy code, or export documents to Google Docs. |
| **User Privacy & Permissions** | **100% Local TTS & Standard Web Audio** | Requires no cloud audio API keys, no server proxy routes, and zero user telemetry. |

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                          WebActivity (WebView)                         │
├────────────────────────────────────────────────────────────────────────┤
│  DOM Mutation Observer (Injected JavaScript)                           │
│  ├── Detects: Generation Start (stop button present / active stream)   │
│  └── Detects: Generation Complete (stop button removed / text stable)  │
│         │                                                              │
│         ├── [Step 1: Check Native Audio]                               │
│         │   Found button[aria-label*="Listen" / "Read aloud"]?         │
│         │   ├── YES ──> trigger click() ──> Web Native Audio Plays     │
│         │   └── NO  ──> Extract assistant text                         │
│         │                     │                                        │
│         │                     ▼                                        │
│         │           [Step 2: Fallback TTS]                             │
│         │           window.AndroidAudioBridge.speakText(cleanText)     │
└─────────┼─────────────────────┼────────────────────────────────────────┘
          │                     │
          ▼                     ▼
┌────────────────────────────────────────────────────────────────────────┐
│                  Android Native Audio & UI Layer                       │
├────────────────────────────────────────────────────────────────────────┤
│  AndroidAudioBridge (@JavascriptInterface)                             │
│  ├── onPlaybackStateChanged(isPlaying, speed)                          │
│  └── speakText(text) ──> Android TextToSpeech Engine                   │
│                                                                        │
│  Floating Audio Controller View (activity_web.xml)                     │
│  ├── [Play/Pause] [Stop] [Speed: 1.0x-1.5x] [Minimize]                │
│  └── Minimizes to Quiet Edge Orb (tap to expand)                       │
│                                                                        │
│  Top Bar Quick Mute Toggle (Speaker Icon: Active / Muted)              │
│  Settings & Prefs (isAutoSpeakEnabled, speechRate)                     │
└────────────────────────────────────────────────────────────────────────┘
```

### Component & State Mapping

1. **`Prefs.kt` & `Prefs.ts`**:
   - `isAutoSpeakEnabled: Boolean` (default: `true`)
   - `speechRate: Float` (default: `1.0f`)
   - `isAudioControllerMinimized: Boolean` (default: `false`)

2. **`AndroidAudioBridge.kt`**:
   - `@JavascriptInterface fun onNativeAudioTriggered()`
   - `@JavascriptInterface fun speakText(text: String, lang: String?)`
   - `@JavascriptInterface fun stopSpeech()`
   - `@JavascriptInterface fun setPlaybackSpeed(speed: Float)`

3. **`WebActivity.kt`**:
   - Initializes `android.speech.tts.TextToSpeech`.
   - Injects `AutoSpeakObserver.js` upon page load.
   - Manages floating audio controller layout: Play/Pause, Stop, Speed, and Minimize/Expand states.
   - Adds quick-mute speaker button to `web_top_bar`.

4. **`PhoneSimulator.tsx` & `SetupWizardModal.tsx`**:
   - Mirrors auto-read aloud with Web Speech Synthesis API (`window.speechSynthesis`).
   - Renders floating audio bar with expand/minimize toggle, play/pause, stop, and speed toggles.
   - Adds auto-speak setting to onboarding wizard and settings drawer.

5. **`AI_INSTRUCTIONS.txt` & Documentation**:
   - Records User Preference 45 ("Auto-Read Aloud Hybrid Speech & Minimizable Audio Bar") and updates release version to v1.63.0.
