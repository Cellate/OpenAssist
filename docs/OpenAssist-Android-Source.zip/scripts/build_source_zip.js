import fs from 'node:fs';
import path from 'node:path';
import JSZip from 'jszip';

const rootDir = process.cwd();
const publicDir = path.join(rootDir, 'public');

if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

function addDirectoryToZip(zip, folderPath, zipBasePath, filterFn) {
  if (!fs.existsSync(folderPath)) return;
  const entries = fs.readdirSync(folderPath, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(folderPath, entry.name);
    const zipPath = zipBasePath ? `${zipBasePath}/${entry.name}` : entry.name;

    if (filterFn && !filterFn(fullPath, entry.name)) {
      continue;
    }

    if (entry.isDirectory()) {
      addDirectoryToZip(zip, fullPath, zipPath, filterFn);
    } else if (entry.isFile()) {
      const content = fs.readFileSync(fullPath);
      zip.file(zipPath, content);
    }
  }
}

const versionFile = path.join(rootDir, 'assets', 'version.json');
let versionConfig = {
  version: '1.63.0',
  buildPackage: 'OpenAssist_v.1.63.0.zip'
};
if (fs.existsSync(versionFile)) {
  try {
    versionConfig = JSON.parse(fs.readFileSync(versionFile, 'utf8'));
  } catch (e) {
    console.warn('Could not parse version.json', e);
  }
}
const pureAndroidZipName = versionConfig.buildPackage || `OpenAssist_v.${versionConfig.version}.zip`;

function copyDirSync(src, dest) {
  if (!fs.existsSync(src)) return;
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDirSync(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

async function syncDocsDirectory() {
  const distDir = path.join(rootDir, 'dist');
  const docsDir = path.join(rootDir, 'docs');
  if (fs.existsSync(distDir)) {
    console.log('Syncing dist/ build to docs/ for GitHub Pages deployment...');
    copyDirSync(distDir, docsDir);
    // Write .nojekyll so GitHub Pages doesn't ignore assets
    fs.writeFileSync(path.join(docsDir, '.nojekyll'), '');
    console.log('✓ Synced docs/ successfully with .nojekyll');
  }
}

async function buildPureAndroidZip() {
  console.log(`Building Package 1: ${pureAndroidZipName} (Android Source + Public Web Showcase)...`);
  await syncDocsDirectory();
  const zip = new JSZip();

  // Root files
  const rootFiles = [
    'settings.gradle.kts',
    'build.gradle.kts',
    'gradle.properties',
    'gradlew',
    'gradlew.bat',
    'README.md',
    'LICENSE',
  ];

  for (const f of rootFiles) {
    const fullPath = path.join(rootDir, f);
    if (fs.existsSync(fullPath)) {
      zip.file(f, fs.readFileSync(fullPath));
    }
  }

  // .github directory (APK build workflow + GitHub Pages deployment workflow)
  addDirectoryToZip(zip, path.join(rootDir, '.github'), '.github');

  // gradle directory (including wrapper binary jar)
  addDirectoryToZip(zip, path.join(rootDir, 'gradle'), 'gradle');

  // app directory (Android source code, NDK whisper cpp, layouts, manifests)
  addDirectoryToZip(zip, path.join(rootDir, 'app'), 'app');

  // assets directory (mascots, version.json, etc.)
  addDirectoryToZip(zip, path.join(rootDir, 'assets'), 'assets');

  // docs directory (compiled static public showcase for GitHub Pages)
  const docsDir = path.join(rootDir, 'docs');
  if (fs.existsSync(docsDir)) {
    addDirectoryToZip(zip, docsDir, 'docs');
  }

  const content = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  const targetPath = path.join(publicDir, pureAndroidZipName);
  fs.writeFileSync(targetPath, content);
  console.log(`✓ Generated ${targetPath} (${Math.round(content.length / 1024)} KB)`);

  // Mirror pureAndroidZipName to public for universal download compatibility
  const canonicalName = `OpenAssist_v.${versionConfig.version}.zip`;
  if (pureAndroidZipName !== canonicalName) {
    fs.writeFileSync(path.join(publicDir, canonicalName), content);
  }

  // Also mirror to dist/ if dist exists
  const distDir = path.join(rootDir, 'dist');
  if (fs.existsSync(distDir)) {
    fs.writeFileSync(path.join(distDir, pureAndroidZipName), content);
    if (pureAndroidZipName !== canonicalName) {
      fs.writeFileSync(path.join(distDir, canonicalName), content);
    }
  }
}

async function buildFullProjectZip() {
  console.log('Building Package 2: OpenAssist-Full-Project.zip (Entire Repo)...');
  const zip = new JSZip();

  const ignoreList = new Set([
    'node_modules',
    'dist',
    '.git',
    '.DS_Store',
    'OpenAssist_v.1.63.0.zip',
    'OpenAssist_v.1.62.0.zip',
    'OpenAssist_v.1.61.0.zip',
    'OpenAssist_v.1.60.1.zip',
    'OpenAssist_v.1.60.0.zip',
    'OpenAssist_v.1.59.0.zip',
    'OpenAssist_v.1.58.1.zip',
    'OpenAssist_v.1.58.0.zip',
    'OpenAssist_v.1.57.0.zip',
    'OpenAssist_v.1.55.0.zip',
    'OpenAssist_v.1.54.0.zip',
    'OpenAssist-Full-Project.zip',
    'OpenAssist-Android-Source.zip',
  ]);

  function filter(fullPath, name) {
    if (ignoreList.has(name)) return false;
    if (fullPath.includes('/node_modules/') || fullPath.includes('/dist/')) return false;
    if (name.endsWith('.zip')) return false;
    return true;
  }

  addDirectoryToZip(zip, rootDir, '', filter);

  const content = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  const fullPath = path.join(publicDir, 'OpenAssist-Full-Project.zip');
  const legacyPath = path.join(publicDir, 'OpenAssist-Android-Source.zip');

  fs.writeFileSync(fullPath, content);
  fs.writeFileSync(legacyPath, content);

  console.log(`✓ Generated ${fullPath} (${Math.round(content.length / 1024)} KB)`);
  console.log(`✓ Generated ${legacyPath} (${Math.round(content.length / 1024)} KB)`);
}

async function main() {
  await buildPureAndroidZip();
  await buildFullProjectZip();
  console.log('All source zips successfully generated in /public!');
}

main().catch((err) => {
  console.error('Error generating zips:', err);
  process.exit(1);
});
