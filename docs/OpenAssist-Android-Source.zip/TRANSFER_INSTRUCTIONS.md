# OpenAssist - Instant AI Studio Transfer & Export Guide

When transferring OpenAssist to a new Google AI Studio Build session, **do not copy-paste raw zip files or terminal dumps into the chat**. Pasting raw binary data forces the AI to consume tens of thousands of tokens trying to decipher fragmented headers.

Instead, use one of the two ultra-fast, zero-token methods below.

---

## 📦 The Two Export ZIP Packages

OpenAssist provides two distinct zip downloads depending on your workflow:

### 1. Pure Android Build Package (`OpenAssist_v.1.65.0.zip`)
- **Purpose**: Upload directly to your GitHub repository to build the Android APK via GitHub Actions.
- **Naming Scheme**: `OpenAssist_v.1.<iteration>.<bugfix>.zip`
  - `1` = Major version
  - `65` = Iteration count (increments whenever source code or features are generated/updated)
  - `0` = Bug fix count (e.g. `1.65.0`)
- **Contents**: Purely the Android project files needed for compilation (`app/`, `assets/`, `gradle/`, `gradlew`, `gradlew.bat`, `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `.github/workflows/main.yml`, `README.md`, `LICENSE`).
- **Excludes**: React/Vite web companion files, `node_modules`, `src/`, `package.json`, etc.
- **How it works**: You download this zip, unzip it, and push all files to GitHub. GitHub Actions automatically builds the APK using JDK 17 and NDK r25c in ~2 minutes with zero token usage.

### 2. Full Project Migration Package (`OpenAssist-Full-Project.zip` / `OpenAssist-Android-Source.zip`)
- **Purpose**: Complete project backup and migration to another AI Studio session.
- **Contents**: Everything in the workspace (Android native app, C++ Whisper bridge, 26 mascot drawables, plus the React/Vite web companion app, phone simulator, and documentation).

---

## ⚡ Method 1: The 10-Second AI Studio Transfer (Recommended - Consumes < 50 Tokens)

### Step 1: Download the Migration ZIP
Download `OpenAssist-Full-Project.zip` (or `OpenAssist-Android-Source.zip`) from the web companion UI or directly from `/public/OpenAssist-Full-Project.zip`.

### Step 2: Upload to New AI Studio Session
In your new AI Studio session, upload or attach `OpenAssist-Full-Project.zip`.

### Step 3: Copy-Paste this Exact Prompt (Turn 1):
```text
I have uploaded OpenAssist-Full-Project.zip. Please run `unzip -o OpenAssist-Full-Project.zip`, run `install_applet_package` for `jszip` and `@types/jszip`, run `chmod +x gradlew`, and run `compile_applet`. Keep all dual Android and web companion code intact without changing any lines.
```

### Why this works:
1. The AI immediately runs `unzip -o OpenAssist-Full-Project.zip`.
2. All files are extracted in 0.5 seconds.
3. Consumes practically **zero reasoning tokens**.

---

## 🌐 Method 2: One-Line Online Restore Command (No File Upload Needed)

If you cannot upload a `.zip` file in your browser, paste this prompt in Turn 1:

```text
Please download and unpack the latest OpenAssist source directly into the current directory by running:
python3 -c "import urllib.request, zipfile; urllib.request.urlretrieve('https://raw.githubusercontent.com/Cellate/OpenAssist/main/public/OpenAssist-Android-Source.zip', 'src.zip'); zipfile.ZipFile('src.zip').extractall('.'); print('Extracted!')"
Then install 'jszip' and '@types/jszip', ensure chmod +x gradlew, and verify with compile_applet. Do not change any code.
```

---

## 📋 Guardrails for Future AI Engines
- **Never delete or stub out `gradle/wrapper/gradle-wrapper.jar`**: It is an authentic 43 KB binary required for `./gradlew` and GitHub Actions CI.
- **Never strip C++ Whisper JNI**: Keep `CMakeLists.txt`, `whisper_jni.cpp`, and `ndkVersion = "25.2.9519653"` in `app/build.gradle.kts`.
- **Never replace `.github/workflows/main.yml`**: It contains the self-healing build pipeline with Temurin JDK 17, NDK r25c, and auto-signing.
- **Keep default mascot as "Ozzy" (`owl-orbital`)**.
- **No duplicate XML attributes** in `app/src/main/res/drawable/`.
- **Zero telemetry, zero ads, 100% open-source**.
